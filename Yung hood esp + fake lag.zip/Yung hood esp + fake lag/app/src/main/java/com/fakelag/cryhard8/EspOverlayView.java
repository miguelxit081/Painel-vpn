package com.fakelag.cryhard8;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class EspOverlayView extends View {

    private Paint boxPaint;
    private Paint linePaint;
    private Paint textPaint;

    // Dummy test target positions
    private float enemyX = 400;
    private float enemyY = 300;
    private float enemyWidth = 150;
    private float enemyHeight = 300;

    public EspOverlayView(Context context) {
        super(context);
        initPaints();
    }

    private void initPaints() {
        boxPaint = new Paint();
        boxPaint.setColor(Color.GREEN);
        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setStrokeWidth(4.0f);
        boxPaint.setAntiAlias(true);

        linePaint = new Paint();
        linePaint.setColor(Color.RED);
        linePaint.setStrokeWidth(3.0f);
        linePaint.setAntiAlias(true);

        textPaint = new Paint();
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(32.0f);
        textPaint.setAntiAlias(true);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawRect(enemyX, enemyY, enemyX + enemyWidth, enemyY + enemyHeight, boxPaint);

        float screenCenterX = getWidth() / 2.0f;
        canvas.drawLine(screenCenterX, 0, enemyX + (enemyWidth / 2.0f), enemyY, linePaint);

        canvas.drawText("Enemy [10m]", enemyX, enemyY - 10, textPaint);

        postInvalidateDelayed(16);
    }

    public void updateTarget(float x, float y, float w, float h) {
        this.enemyX = x;
        this.enemyY = y;
        this.enemyWidth = w;
        this.enemyHeight = h;
        invalidate();
    }
}
