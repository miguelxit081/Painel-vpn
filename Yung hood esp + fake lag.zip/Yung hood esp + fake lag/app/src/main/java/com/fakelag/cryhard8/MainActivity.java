package com.fakelag.cryhard8;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int REQ_VPN = 0x3e9;
    private static final int REQ_OVERLAY = 0x3ea;
    private static final int REQ_NOTIF = 0x3eb;

    private static final String PREFS = "xevpn_prefs";
    private static final String KEY_GHOST = "show_ghost";
    private static final String KEY_GHOST_V2 = "show_ghost_v2";
    private static final String KEY_FREEZE = "show_freeze";
    private static final String KEY_TELE = "show_tele";

    private List<android.content.pm.ApplicationInfo> apps = new ArrayList<>();
    private Button btnEngine;
    private boolean engineOn = false;
    private boolean loaded = false;
    private String[] names;
    private String selPkg = null;

    private TextView tvApp, tvStatus;
    private View dotEngine, dotApp;

    private View dotVpn, dotDisplay, dotNotif;
    private TextView tvVpnStatus, tvDisplayStatus, tvNotifStatus;
    private TextView cbVpn, cbDisplay, cbNotif;

    private View cbFloatGhost, cbFloatGhostV2, cbFloatFreeze, cbFloatTele;
    private TextView tvFloatGhostStatus, tvFloatGhostV2Status, tvFloatFreezeStatus, tvFloatTeleStatus;

    private boolean waiting = false;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable engineBlinkRunnable;

    private ImageView logoImageView;
    private boolean isRotating = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(true);
        scrollView.setScrollbarFadingEnabled(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            GradientDrawable thumb = new GradientDrawable();
            thumb.setShape(GradientDrawable.RECTANGLE);
            thumb.setColor(Color.parseColor("#00F0FF"));
            thumb.setCornerRadius(dp(8));
            thumb.setSize(dp(5), 0);
            scrollView.setVerticalScrollbarThumbDrawable(thumb);
        }

        GradientDrawable bg = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{Color.parseColor("#05050D"), Color.parseColor("#0F1123"), Color.parseColor("#180E29")}
        );
        bg.setGradientType(GradientDrawable.LINEAR_GRADIENT);
        scrollView.setBackground(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int padding = dp(20);
        root.setPadding(padding, padding + dp(8), padding, padding + dp(8));
        scrollView.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = createHeaderWithButtons();
        root.addView(header);
        animateEntrance(header, 0);

        LinearLayout logo = createLogoAura();
        root.addView(logo);
        animateEntrance(logo, 40);

        LinearLayout title = createTitle();
        root.addView(title);
        animateEntrance(title, 80);

        LinearLayout gameRow = createGameButtons();
        root.addView(gameRow);
        animateEntrance(gameRow, 120);

        LinearLayout statusContainer = createStatusContainer();
        root.addView(statusContainer);
        animateEntrance(statusContainer, 160);

        LinearLayout floatCard = createCard("✨  MOSTRAR/OCULTAR BOTÕES FLUTUANTES");
        addFloatCardContent(floatCard);
        root.addView(floatCard);
        animateEntrance(floatCard, 200);

        LinearLayout permCard = createCard("🔐 PERMISSÕES DO SISTEMA");
        addPermissionCardContent(permCard);
        root.addView(permCard);
        animateEntrance(permCard, 240);

        LinearLayout engineCard = createCard("🚀 STATUS DO ENGINE");
        addEngineCardContent(engineCard);
        root.addView(engineCard);
        animateEntrance(engineCard, 280);

        LinearLayout appCard = createCard("🎮 APLICATIVO ALVO");
        addAppCardContent(appCard);
        root.addView(appCard);
        animateEntrance(appCard, 320);

        btnEngine = createGradientButton("▶ ATIVAR ENGINE", "#00F0FF", "#7000FF");
        root.addView(btnEngine);
        animateEntrance(btnEngine, 360);

        LinearLayout instructions = createInstructions();
        root.addView(instructions);
        animateEntrance(instructions, 400);

        setContentView(scrollView);

        setupFloatingToggles();
        setupPermissionToggle();
        setUI(false);
        loadApps();

        startLogoRotation();

        btnEngine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (waiting) return;
                if (!engineOn) {
                    if (selPkg == null) {
                        toast("Selecione um aplicativo primeiro!");
                        return;
                    }
                    checkOverlay();
                } else {
                    stopEngine();
                }
            }
        });
    }

    private void animateEntrance(final View view, int delayMs) {
        view.setAlpha(0f);
        view.setTranslationY(dp(40));
        view.postDelayed(new Runnable() {
            @Override
            public void run() {
                view.animate()
                        .alpha(1f)
                        .translationY(0f)
                        .setDuration(400)
                        .setInterpolator(new DecelerateInterpolator())
                        .start();
            }
        }, delayMs);
    }

    private LinearLayout createHeaderWithButtons() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.END);
        header.setPadding(dp(8), dp(8), dp(8), dp(8));

        Button btnVpnOff = createSimpleButton("VPN DESLIGADA", "#FF007F", "#121420", "#FF007F", dp(110), dp(42));
        btnVpnOff.setTextSize(12);
        btnVpnOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (engineOn) stopEngine();
                else toast("A VPN já está desligada");
            }
        });

        Button btnMenu = createSimpleButton("...", "#FFFFFF20", "#121420", "#FFFFFF", dp(44), dp(44));
        btnMenu.setTextSize(22);
        btnMenu.setTypeface(Typeface.DEFAULT_BOLD);
        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast("Menu");
            }
        });

        header.addView(btnVpnOff);
        header.addView(btnMenu);
        return header;
    }

    private LinearLayout createLogoAura() {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setGravity(Gravity.CENTER);
        container.setPadding(0, dp(16), 0, dp(8));

        LinearLayout logoContainer = new LinearLayout(this);
        int logoSize = dp(100);
        LinearLayout.LayoutParams containerParams = new LinearLayout.LayoutParams(logoSize, logoSize);
        containerParams.gravity = Gravity.CENTER;
        logoContainer.setLayoutParams(containerParams);
        logoContainer.setGravity(Gravity.CENTER);

        View auraView = new View(this);
        LinearLayout.LayoutParams auraParams = new LinearLayout.LayoutParams(logoSize + dp(20), logoSize + dp(20));
        auraParams.gravity = Gravity.CENTER;
        auraView.setLayoutParams(auraParams);

        GradientDrawable auraBg = new GradientDrawable();
        auraBg.setShape(GradientDrawable.OVAL);
        auraBg.setColor(Color.parseColor("#2000F0FF"));
        auraBg.setStroke(dp(2), Color.parseColor("#8000F0FF"));
        auraView.setBackground(auraBg);

        logoImageView = new ImageView(this);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(logoSize, logoSize);
        logoParams.gravity = Gravity.CENTER;
        logoImageView.setLayoutParams(logoParams);
        logoImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);

        try {
            int resId = getResources().getIdentifier("logo", "drawable", getPackageName());
            if (resId != 0) {
                Bitmap originalBitmap = BitmapFactory.decodeResource(getResources(), resId);
                if (originalBitmap != null) {
                    Bitmap roundedBitmap = getRoundedBitmap(originalBitmap);
                    logoImageView.setImageBitmap(roundedBitmap);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        GradientDrawable borderBg = new GradientDrawable();
        borderBg.setShape(GradientDrawable.OVAL);
        borderBg.setStroke(dp(3), Color.parseColor("#00F0FF"));
        logoImageView.setBackground(borderBg);
        logoImageView.setClipToOutline(true);

        logoContainer.addView(auraView);
        logoContainer.addView(logoImageView);
        container.addView(logoContainer);

        return container;
    }

    private Bitmap getRoundedBitmap(Bitmap bitmap) {
        int size = Math.min(bitmap.getWidth(), bitmap.getHeight());
        Bitmap output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);

        RectF rectF = new RectF(0, 0, size, size);
        canvas.drawRoundRect(rectF, size / 2f, size / 2f, paint);
        paint.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SRC_IN));

        float scale = (float) size / Math.min(bitmap.getWidth(), bitmap.getHeight());
        float dx = (size - bitmap.getWidth() * scale) / 2;
        float dy = (size - bitmap.getHeight() * scale) / 2;

        canvas.translate(dx, dy);
        canvas.scale(scale, scale);
        canvas.drawBitmap(bitmap, 0, 0, paint);

        return output;
    }

    private void startLogoRotation() {
        if (logoImageView != null && !isRotating) {
            isRotating = true;
            RotateAnimation rotate = new RotateAnimation(
                0, 360,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
            );
            rotate.setDuration(8000);
            rotate.setRepeatCount(Animation.INFINITE);
            rotate.setInterpolator(new android.view.animation.LinearInterpolator());
            logoImageView.startAnimation(rotate);
        }
    }

    private void stopLogoRotation() {
        if (logoImageView != null && isRotating) {
            logoImageView.clearAnimation();
            isRotating = false;
        }
    }

    private LinearLayout createTitle() {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setGravity(Gravity.CENTER);
        container.setPadding(0, dp(8), 0, dp(16));

        TextView title = new TextView(this);
        title.setText("OS-21 FAKE PING");
        title.setTextColor(Color.parseColor("#00F0FF"));
        title.setTextSize(24);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        title.setGravity(Gravity.CENTER);
        title.setShadowLayer(18f, 0f, 0f, Color.parseColor("#00F0FF"));
        title.setLetterSpacing(0.08f);

        TextView subtitle = new TextView(this);
        subtitle.setText("EDIÇÃO CYBER");
        subtitle.setTextColor(Color.parseColor("#FF007F"));
        subtitle.setTextSize(11);
        subtitle.setTypeface(Typeface.create("sans-serif-condensed", Typeface.NORMAL));
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setLetterSpacing(0.1f);

        container.addView(title);
        container.addView(subtitle);
        return container;
    }

    private LinearLayout createGameButtons() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, dp(4), 0, dp(16));

        final Button btnFFNormal = createSelectableButton("FF NORMAL", true);
        final Button btnFFMax = createSelectableButton("FF MAX", false);
        final Button btnRetry = createSelectableButton("TENTAR NOVAMENTE", false);

        btnFFNormal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateButtonStyle(btnFFNormal, true);
                updateButtonStyle(btnFFMax, false);
                updateButtonStyle(btnRetry, false);
                selectGame("com.dts.freefireth", "Free Fire Normal");
            }
        });

        btnFFMax.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateButtonStyle(btnFFNormal, false);
                updateButtonStyle(btnFFMax, true);
                updateButtonStyle(btnRetry, false);
                selectGame("com.dts.freefireth", "Free Fire MAX");
            }
        });

        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (engineOn) stopEngine();
                startEngine();
            }
        });

        row.addView(btnFFNormal);
        row.addView(btnFFMax);
        row.addView(btnRetry);
        return row;
    }

    private LinearLayout createStatusContainer() {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(24), dp(20), dp(24), dp(20));

        GradientDrawable statusBg = new GradientDrawable();
        statusBg.setColor(Color.parseColor("#121420"));
        statusBg.setCornerRadius(dp(20));
        statusBg.setStroke(dp(1), Color.parseColor("#1E2640"));
        container.setBackground(statusBg);

        tvStatus = new TextView(this);
        tvStatus.setText("STATUS DA VPN: DESLIGADA");
        tvStatus.setTextSize(18);
        tvStatus.setTextColor(Color.parseColor("#FF007F"));
        tvStatus.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        tvStatus.setGravity(Gravity.CENTER);
        container.addView(tvStatus);

        tvApp = new TextView(this);
        tvApp.setText("Nenhum aplicativo selecionado");
        tvApp.setTextSize(14);
        tvApp.setTextColor(Color.parseColor("#CCCCCC"));
        tvApp.setTypeface(Typeface.create("sans-serif-condensed", Typeface.NORMAL));
        tvApp.setGravity(Gravity.CENTER);
        container.addView(tvApp);

        return container;
    }

    private LinearLayout createInstructions() {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(16), dp(20), dp(16), dp(20));

        TextView tvHD = new TextView(this);
        tvHD.setText("INSTRUÇÕES:");
        tvHD.setTextSize(14);
        tvHD.setTextColor(Color.parseColor("#00F0FF"));
        tvHD.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        tvHD.setPadding(0, 0, 0, dp(8));
        container.addView(tvHD);

        TextView tvStep = new TextView(this);
        tvStep.setText(
            "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n" +
            "📌 COMO USAR:\n" +
            "1️⃣ Selecione o jogo ou use o botão SELECIONAR APLICATIVO\n" +
            "2️⃣ Toque em ATIVAR ENGINE → conceda a permissão da VPN\n" +
            "3️⃣ Entre no jogo e comece a partida\n" +
            "4️⃣ Ao terminar a partida, toque em DESATIVAR ENGINE\n" +
            "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n" +
            "🔞 AVISO:\n" +
            "Ferramenta gratuita, sem suporte contra banimentos\n" +
            "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n" +
            "🔥 Atualizado por Arise.\n" +
            "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
        );
        tvStep.setTextSize(12);
        tvStep.setTextColor(Color.parseColor("#AAAAAA"));
        tvStep.setTypeface(Typeface.create("sans-serif-condensed", Typeface.NORMAL));
        tvStep.setLineSpacing(dp(8), 1f);
        tvStep.setPadding(dp(16), dp(16), dp(16), dp(16));

        GradientDrawable stepBg = new GradientDrawable();
        stepBg.setColor(Color.parseColor("#0A0B12"));
        stepBg.setCornerRadius(dp(16));
        stepBg.setStroke(dp(1), Color.parseColor("#1E2640"));
        tvStep.setBackground(stepBg);

        container.addView(tvStep);
        return container;
    }

    private Button createSelectableButton(String text, boolean isSelected) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(isSelected ? Color.WHITE : Color.parseColor("#00F0FF"));
        btn.setTextSize(14);
        btn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        btn.setAllCaps(false);

        GradientDrawable gd = new GradientDrawable();
        if (isSelected) {
            gd.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
            gd.setColors(new int[]{Color.parseColor("#00F0FF"), Color.parseColor("#7000FF")});
            gd.setStroke(0, Color.TRANSPARENT);
        } else {
            gd.setColor(Color.TRANSPARENT);
            gd.setStroke(dp(2), Color.parseColor("#00F0FF"));
        }
        gd.setCornerRadius(dp(40));
        btn.setBackground(gd);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(48));
        lp.setMargins(dp(6), 0, dp(6), 0);
        btn.setLayoutParams(lp);
        btn.setPadding(dp(24), dp(10), dp(24), dp(10));
        return btn;
    }

    private void updateButtonStyle(Button btn, boolean selected) {
        GradientDrawable gd = (GradientDrawable) btn.getBackground();
        if (selected) {
            gd.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
            gd.setColors(new int[]{Color.parseColor("#00F0FF"), Color.parseColor("#7000FF")});
            gd.setStroke(0, Color.TRANSPARENT);
            btn.setTextColor(Color.WHITE);
        } else {
            gd.setColor(Color.TRANSPARENT);
            gd.setStroke(dp(2), Color.parseColor("#00F0FF"));
            btn.setTextColor(Color.parseColor("#00F0FF"));
        }
        btn.invalidate();
    }

    private Button createSimpleButton(String text, String borderColor, String bgColor, String textColor, int width, int height) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(Color.parseColor(textColor));
        btn.setTextSize(14);
        btn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        btn.setAllCaps(false);

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(bgColor));
        if (borderColor != null) gd.setStroke(dp(2), Color.parseColor(borderColor));
        gd.setCornerRadius(dp(24));
        btn.setBackground(gd);
        btn.setLayoutParams(new LinearLayout.LayoutParams(width, height));
        return btn;
    }

    private LinearLayout createCard(String titleText) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(24));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(16));
        card.setLayoutParams(lp);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(20));
        bg.setColor(Color.parseColor("#121420"));
        bg.setStroke(dp(2), Color.parseColor("#00F0FF"));
        card.setBackground(bg);
        card.setElevation(dp(8));
        card.setClipToOutline(true);

        card.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(80).start();
                } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                }
                return false;
            }
        });

        final TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextColor(Color.parseColor("#E6FFFF"));
        title.setTextSize(16);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        title.setPadding(0, 0, 0, dp(12));

        title.post(new Runnable() {
            @Override
            public void run() {
                int w = title.getWidth();
                if (w > 0) {
                    Shader shader = new LinearGradient(0, 0, w, title.getTextSize(),
                            new int[]{Color.parseColor("#00F0FF"), Color.parseColor("#7000FF")},
                            null, Shader.TileMode.CLAMP);
                    title.getPaint().setShader(shader);
                }
            }
        });

        card.addView(title);
        return card;
    }

    private void addEngineCardContent(LinearLayout card) {
        LinearLayout row = createStatusRow();
        TextView icon = new TextView(this);
        icon.setText("🚀");
        icon.setTextSize(20);
        icon.setPadding(0, 0, dp(12), 0);
        icon.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        row.addView(icon);

        dotEngine = createNeonDot(false);
        row.addView(dotEngine);
        card.addView(row);
    }

    private void addAppCardContent(LinearLayout card) {
        LinearLayout row = createStatusRow();
        TextView icon = new TextView(this);
        icon.setText("📱");
        icon.setTextSize(20);
        icon.setPadding(0, 0, dp(12), 0);
        icon.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        row.addView(icon);

        dotApp = createNeonDot(false);
        row.addView(dotApp);

        tvApp = new TextView(this);
        tvApp.setText("Nenhum aplicativo selecionado");
        tvApp.setTextColor(Color.parseColor("#C084FC"));
        tvApp.setTextSize(15);
        tvApp.setTypeface(Typeface.create("sans-serif-condensed", Typeface.NORMAL));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        lp.setMarginStart(dp(16));
        tvApp.setLayoutParams(lp);
        row.addView(tvApp);
        card.addView(row);

        Button btn = createGradientButton("SELECIONAR APLICATIVO", "#00F0FF", "#7000FF");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!loaded) {
                    toast("Carregando lista de aplicativos...");
                    return;
                }
                showPicker();
            }
        });
        card.addView(btn);
    }

    private void addPermissionCardContent(LinearLayout card) {
        LinearLayout vpnRow = createPermRow();
        TextView vpnIcon = new TextView(this);
        vpnIcon.setText("🔐");
        vpnIcon.setTextSize(20);
        vpnIcon.setPadding(0, 0, dp(12), 0);
        vpnIcon.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        vpnRow.addView(vpnIcon);

        dotVpn = createNeonDot(false);
        tvVpnStatus = createStatusText("VPN: NÃO AUTORIZADA", "#94A3B8");
        cbVpn = createChipToggle("DESLIGADA");
        setupPermRow(vpnRow, dotVpn, tvVpnStatus, cbVpn);
        card.addView(vpnRow);

        LinearLayout displayRow = createPermRow();
        TextView displayIcon = new TextView(this);
        displayIcon.setText("👁️");
        displayIcon.setTextSize(20);
        displayIcon.setPadding(0, 0, dp(12), 0);
        displayIcon.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        displayRow.addView(displayIcon);

        dotDisplay = createNeonDot(false);
        tvDisplayStatus = createStatusText("EXIBIÇÃO: NÃO AUTORIZADA", "#94A3B8");
        cbDisplay = createChipToggle("DESLIGADA");
        setupPermRow(displayRow, dotDisplay, tvDisplayStatus, cbDisplay);
        card.addView(displayRow);

        LinearLayout notifRow = createPermRow();
        TextView notifIcon = new TextView(this);
        notifIcon.setText("🔔");
        notifIcon.setTextSize(20);
        notifIcon.setPadding(0, 0, dp(12), 0);
        notifIcon.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        notifRow.addView(notifIcon);

        dotNotif = createNeonDot(false);
        tvNotifStatus = createStatusText("NOTIFICAÇÕES: NÃO AUTORIZADAS", "#94A3B8");
        cbNotif = createChipToggle("DESLIGADA");
        setupPermRow(notifRow, dotNotif, tvNotifStatus, cbNotif);
        card.addView(notifRow);
    }

    private void addFloatCardContent(LinearLayout card) {
        tvFloatGhostStatus = createStatusText("GHOST: ATIVADO", "#00FF9D");
        cbFloatGhost = createSlidingToggle(true);
        addFloatRow(card, "👻", tvFloatGhostStatus, cbFloatGhost);

        tvFloatGhostV2Status = createStatusText("VPN: ATIVADA", "#00FF9D");
        cbFloatGhostV2 = createSlidingToggle(true);
        addFloatRow(card, "🔐", tvFloatGhostV2Status, cbFloatGhostV2);

        tvFloatFreezeStatus = createStatusText("FREEZE: ATIVADO", "#00FF9D");
        cbFloatFreeze = createSlidingToggle(true);
        addFloatRow(card, "❄️", tvFloatFreezeStatus, cbFloatFreeze);

        tvFloatTeleStatus = createStatusText("TELEPORTE: ATIVADO", "#00FF9D");
        cbFloatTele = createSlidingToggle(true);
        addFloatRow(card, "🌀", tvFloatTeleStatus, cbFloatTele);
    }

    private void addFloatRow(LinearLayout card, String emoji, TextView status, View toggle) {
        LinearLayout row = createPermRow();
        TextView icon = new TextView(this);
        icon.setText(emoji);
        icon.setTextSize(20);
        icon.setPadding(0, 0, dp(12), 0);
        icon.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        row.addView(icon);
        setupPermRow(row, null, status, toggle);
        card.addView(row);
    }

    private LinearLayout createStatusRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));
        return row;
    }

    private LinearLayout createPermRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(12), 0, dp(12));
        return row;
    }

    private View createNeonDot(boolean isOn) {
        View dot = new View(this);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setSize(dp(20), dp(20));
        gd.setColor(isOn ? Color.parseColor("#00FF9D") : Color.parseColor("#FF2D55"));
        gd.setStroke(dp(4), isOn ? Color.parseColor("#8000F0FF") : Color.parseColor("#80FF2D55"));
        dot.setBackground(gd);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(20), dp(20));
        lp.rightMargin = dp(14);
        dot.setLayoutParams(lp);
        return dot;
    }

    private TextView createStatusText(String text, String colorHex) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor(colorHex));
        tv.setTextSize(15);
        tv.setTypeface(Typeface.create("sans-serif-condensed", Typeface.NORMAL));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        tv.setLayoutParams(lp);
        return tv;
    }

    private Button createGradientButton(String text, String startColorHex, String endColorHex) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(Color.WHITE);
        btn.setAllCaps(false);
        btn.setTextSize(16);
        btn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));

        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.parseColor(startColorHex), Color.parseColor(endColorHex)});
        bg.setCornerRadius(dp(30));
        bg.setGradientType(GradientDrawable.LINEAR_GRADIENT);

        RippleDrawable ripple = new RippleDrawable(
            android.content.res.ColorStateList.valueOf(Color.parseColor("#40FFFFFF")), bg, null);
        btn.setBackground(ripple);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        lp.setMargins(0, dp(12), 0, dp(12));
        btn.setLayoutParams(lp);

        btn.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                    ScaleAnimation scale = new ScaleAnimation(1f, 0.95f, 1f, 0.95f,
                            ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
                            ScaleAnimation.RELATIVE_TO_SELF, 0.5f);
                    scale.setDuration(90);
                    scale.setFillAfter(true);
                    v.startAnimation(scale);
                } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                    ScaleAnimation scaleBack = new ScaleAnimation(0.95f, 1f, 0.95f, 1f,
                            ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
                            ScaleAnimation.RELATIVE_TO_SELF, 0.5f);
                    scaleBack.setDuration(120);
                    scaleBack.setFillAfter(true);
                    v.startAnimation(scaleBack);
                }
                return false;
            }
        });

        return btn;
    }

    private TextView createChipToggle(String initial) {
        final TextView tv = new TextView(this);
        tv.setText(initial);
        tv.setTextColor(Color.parseColor("#00F0FF"));
        tv.setTextSize(13);
        tv.setGravity(Gravity.CENTER);
        tv.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        tv.setPadding(dp(20), dp(10), dp(20), dp(10));

        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(dp(30));
        gd.setColor(Color.parseColor("#000000"));
        gd.setStroke(dp(2), Color.parseColor("#00F0FF"));
        tv.setBackground(gd);

        tv.setClickable(true);
        tv.setFocusable(true);

        final boolean[] state = {initial.equalsIgnoreCase("BẬT") || initial.equalsIgnoreCase("ON")};

        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int from = state[0] ? Color.parseColor("#000000") : Color.parseColor("#001A1A");
                int to = state[0] ? Color.parseColor("#001A1A") : Color.parseColor("#0033FF");
                ValueAnimator colorAnim = ValueAnimator.ofObject(new ArgbEvaluator(), from, to);
                colorAnim.setDuration(220);
                colorAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator animation) {
                        int val = (int) animation.getAnimatedValue();
                        ((GradientDrawable) tv.getBackground()).setColor(val);
                    }
                });
                colorAnim.start();

                state[0] = !state[0];
                tv.setText(state[0] ? "ATIVADA" : "DESATIVADA");
                tv.setTextColor(state[0] ? Color.parseColor("#00FF9D") : Color.parseColor("#00F0FF"));
            }
        });

        return tv;
    }

    private View createSlidingToggle(final boolean initialOn) {
        final FrameLayout container = new FrameLayout(this);
        final int height = dp(42);
        final int width = dp(88);

        final View track = new View(this);
        GradientDrawable trackBg = new GradientDrawable();
        trackBg.setCornerRadius(height / 2f);
        trackBg.setColor(Color.parseColor("#121420"));
        track.setBackground(trackBg);
        FrameLayout.LayoutParams trackParams = new FrameLayout.LayoutParams(width, height);
        track.setLayoutParams(trackParams);
        container.addView(track);

        final int thumbSize = height - dp(6);
        final View thumb = new View(this);
        GradientDrawable thumbBg = new GradientDrawable();
        thumbBg.setShape(GradientDrawable.OVAL);
        thumbBg.setColor(Color.parseColor("#00F0FF"));
        thumb.setBackground(thumbBg);
        FrameLayout.LayoutParams thumbParams = new FrameLayout.LayoutParams(thumbSize, thumbSize);
        thumbParams.gravity = Gravity.CENTER_VERTICAL;
        thumbParams.leftMargin = dp(3);
        thumb.setLayoutParams(thumbParams);
        container.addView(thumb);

        container.setTag(initialOn);

        container.post(new Runnable() {
            @Override
            public void run() {
                if (container.getWidth() > 0) {
                    float targetX = initialOn ? (width - thumbSize - dp(3)) : dp(3);
                    thumb.setTranslationX(targetX);
                    updateSwitchVisual(track, thumb, initialOn);
                }
            }
        });

        return container;
    }

    private void updateSwitchVisual(View track, View thumb, boolean isOn) {
        ((GradientDrawable) track.getBackground()).setColor(isOn ? Color.parseColor("#121420") : Color.parseColor("#331111"));
        ((GradientDrawable) thumb.getBackground()).setColor(isOn ? Color.parseColor("#00F0FF") : Color.parseColor("#FF007F"));
    }

    private void animateSwitchSlide(final View container, final boolean toOn) {
        if (!(container instanceof FrameLayout)) return;
        FrameLayout fl = (FrameLayout) container;
        if (fl.getChildCount() < 2) return;
        View track = fl.getChildAt(0);
        View thumb = fl.getChildAt(1);
        int width = fl.getWidth();
        if (width == 0) {
            fl.post(new Runnable() {
                @Override
                public void run() {
                    animateSwitchSlide(container, toOn);
                }
            });
            return;
        }
        int thumbSize = thumb.getWidth();
        float targetX = toOn ? (width - thumbSize - dp(3)) : dp(3);
        thumb.animate().translationX(targetX).setDuration(280).setInterpolator(new DecelerateInterpolator()).start();
        updateSwitchVisual(track, thumb, toOn);
    }

    private void setupPermRow(LinearLayout row, View dot, TextView label, View toggle) {
        if (dot != null) row.addView(dot);
        if (label != null) row.addView(label);
        if (toggle != null) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginStart(dp(12));
            row.addView(toggle, lp);
        }
    }

    private void setupFloatingToggles() {
        setupFloatingToggle(cbFloatGhost, tvFloatGhostStatus, KEY_GHOST);
        setupFloatingToggle(cbFloatGhostV2, tvFloatGhostV2Status, KEY_GHOST_V2);
        setupFloatingToggle(cbFloatFreeze, tvFloatFreezeStatus, KEY_FREEZE);
        setupFloatingToggle(cbFloatTele, tvFloatTeleStatus, KEY_TELE);
    }

    private void setupFloatingToggle(final View toggle, final TextView status, final String key) {
        if (toggle == null) return;
        boolean isOn = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(key, true);
        applyFloatingState(toggle, status, isOn);

        toggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean current = toggle.getTag() != null && (Boolean) toggle.getTag();
                boolean next = !current;
                animateSwitchSlide(toggle, next);
                applyFloatingState(toggle, status, next);
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(key, next).apply();
            }
        });
    }

    private void applyFloatingState(View toggle, TextView status, boolean isOn) {
        toggle.setTag(isOn);
        if (status != null) {
            String base = status.getText().toString().split(":")[0].trim();
            status.setText(base + ": " + (isOn ? "ATIVADO" : "DESATIVADO"));
            status.setTextColor(isOn ? Color.parseColor("#00FF9D") : Color.parseColor("#FF5555"));
        }
    }

    private void setupPermissionToggle() {
        cbVpn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = VpnService.prepare(MainActivity.this);
                if (i != null) startActivityForResult(i, REQ_VPN);
                else refreshPermissionStates();
            }
        });

        cbDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(MainActivity.this)) {
                    startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, null), REQ_OVERLAY);
                }
            }
        });

        if (Build.VERSION.SDK_INT >= 33) {
            cbNotif.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIF);
                }
            });
        }
    }

    private void refreshPermissionStates() {
        boolean vpnOk = VpnService.prepare(this) == null;
        setPermissionState(dotVpn, tvVpnStatus, cbVpn, "VPN", vpnOk);

        boolean displayOk = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        setPermissionState(dotDisplay, tvDisplayStatus, cbDisplay, "EXIBIÇÃO", displayOk);

        boolean notifOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED;
        setPermissionState(dotNotif, tvNotifStatus, cbNotif, "NOTIFICAÇÕES", notifOk);
    }

    private void setPermissionState(View dot, TextView label, TextView toggle, String name, boolean granted) {
        if (dot != null) {
            GradientDrawable gd = (GradientDrawable) dot.getBackground();
            gd.setColor(granted ? Color.parseColor("#00FF9D") : Color.parseColor("#FF2D55"));
        }
        if (label != null) {
            label.setText(name + ": " + (granted ? "AUTORIZADA" : "NÃO AUTORIZADA"));
            label.setTextColor(granted ? Color.parseColor("#00FF9D") : Color.parseColor("#FF8888"));
        }
        if (toggle != null) {
            toggle.setText(granted ? "ATIVADA" : "DESATIVADA");
            toggle.setTextColor(granted ? Color.parseColor("#00FF9D") : Color.parseColor("#FF5555"));
            toggle.setTag(granted);
            ((GradientDrawable) toggle.getBackground()).setStroke(dp(2), granted ? Color.parseColor("#00FF9D") : Color.parseColor("#00F0FF"));
        }
    }

    private void setUI(boolean on) {
        engineOn = on;
        if (dotEngine != null) {
            GradientDrawable gd = (GradientDrawable) dotEngine.getBackground();
            gd.setColor(on ? Color.parseColor("#00FF9D") : Color.parseColor("#FF2D55"));
        }
        if (on) {
            btnEngine.setText("⏹ DESATIVAR ENGINE");
            tvStatus.setText("STATUS DA VPN: ATIVA");
            tvStatus.setTextColor(Color.parseColor("#00FF9D"));
            startEngineBlink(dotEngine);
        } else {
            btnEngine.setText("▶ ATIVAR ENGINE");
            tvStatus.setText("STATUS DA VPN: DESLIGADA");
            tvStatus.setTextColor(Color.parseColor("#FF007F"));
            stopEngineBlink();
        }
    }

    private void loadApps() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    android.content.pm.PackageManager pm = getPackageManager();
                    List<android.content.pm.PackageInfo> pkgs = pm.getInstalledPackages(0x80);
                    final List<android.content.pm.ApplicationInfo> resList = new ArrayList<>();
                    final List<String> nameList = new ArrayList<>();

                    for (android.content.pm.PackageInfo pi : pkgs) {
                        if (pi == null || pi.applicationInfo == null) continue;
                        if (pi.packageName.equals(getPackageName())) continue;
                        if (pm.getLaunchIntentForPackage(pi.packageName) == null) continue;
                        String label = pm.getApplicationLabel(pi.applicationInfo).toString();
                        resList.add(pi.applicationInfo);
                        nameList.add(label);
                    }

                    for (int i = 1; i < resList.size(); i++) {
                        android.content.pm.ApplicationInfo appVal = resList.get(i);
                        String nameVal = nameList.get(i);
                        int j = i - 1;
                        while (j >= 0 && nameList.get(j).compareToIgnoreCase(nameVal) > 0) {
                            resList.set(j + 1, resList.get(j));
                            nameList.set(j + 1, nameList.get(j));
                            j--;
                        }
                        resList.set(j + 1, appVal);
                        nameList.set(j + 1, nameVal);
                    }

                    final String[] arr = nameList.toArray(new String[0]);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            apps = resList;
                            names = arr;
                            loaded = true;
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void checkOverlay() {
        waiting = true;
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, null), REQ_OVERLAY);
        } else {
            checkVpn();
        }
    }

    private void checkVpn() {
        try {
            Intent vpnIntent = VpnService.prepare(this);
            if (vpnIntent != null) {
                startActivityForResult(vpnIntent, REQ_VPN);
            } else {
                startEngine();
            }
        } catch (Exception e) {
            waiting = false;
            setUI(false);
            toast("Erro na VPN: " + e.getMessage());
        }
    }

    private boolean isFloatEnabled(String key) {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(key, true);
    }

    private void startEngine() {
        waiting = false;
        try {
            Intent i = new Intent(this, Class.forName("com.fakelag.cryhard8.FakelagOpus1"));
            i.setAction("com.fakelag.cryhard8.SET_APP");
            i.putExtra("PACKAGE", selPkg);
            i.putExtra("SHOW_GHOST", isFloatEnabled(KEY_GHOST));
            i.putExtra("SHOW_GHOST_V2", isFloatEnabled(KEY_GHOST_V2));
            i.putExtra("SHOW_FREEZE", isFloatEnabled(KEY_FREEZE));
            i.putExtra("SHOW_TELE", isFloatEnabled(KEY_TELE));
            startService(i);

            final boolean g = isFloatEnabled(KEY_GHOST);
            final boolean g2 = isFloatEnabled(KEY_GHOST_V2);
            final boolean f = isFloatEnabled(KEY_FREEZE);
            final boolean t = isFloatEnabled(KEY_TELE);

            btnEngine.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent si = new Intent(MainActivity.this, Class.forName("com.fakelag.cryhard8.FakelagOpus2"));
                        si.putExtra("SHOW_GHOST", g);
                        si.putExtra("SHOW_GHOST_V2", g2);
                        si.putExtra("SHOW_FREEZE", f);
                        si.putExtra("SHOW_TELE", t);
                        startService(si);

                        Intent espIntent = new Intent(MainActivity.this, EspService.class);
                        startService(espIntent);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }, 500L);

            setUI(true);
            toast("Engine e ESP ativados!");
        } catch (Exception e) {
            waiting = false;
            setUI(false);
            toast("Erro: " + e.getMessage());
        }
    }

    private void stopEngine() {
        waiting = false;
        try {
            stopService(new Intent(this, Class.forName("com.fakelag.cryhard8.FakelagOpus2")));
            stopService(new Intent(this, EspService.class));

            Intent i = new Intent(this, Class.forName("com.fakelag.cryhard8.FakelagOpus1"));
            i.setAction("com.fakelag.cryhard8.STOP");
            startService(i);

            setUI(false);
            toast("Engine desativado");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void selectGame(String pkg, String name) {
        selPkg = pkg;
        tvApp.setText("SELECIONADO: " + name);
        toast("Selecionado: " + name);
    }

    private void showPicker() {
        if (apps.isEmpty()) {
            toast("Nenhum aplicativo encontrado!");
            return;
        }

        final String[] appNames = names;
        final List<android.content.pm.ApplicationInfo> appList = apps;

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("SELECIONE O APLICATIVO ALVO");
        builder.setItems(appNames, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                android.content.pm.ApplicationInfo ai = appList.get(which);
                selPkg = ai.packageName;
                tvApp.setText("SELECIONADO: " + appNames[which]);
                if (dotApp != null) {
                    GradientDrawable gd = (GradientDrawable) dotApp.getBackground();
                    gd.setColor(Color.parseColor("#00FF9D"));
                }
                tvApp.setScaleX(0.96f);
                tvApp.setScaleY(0.96f);
                tvApp.animate().scaleX(1f).scaleY(1f).setDuration(220).start();
                toast("Selecionado: " + appNames[which]);
            }
        });
        builder.setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY) {
            refreshPermissionStates();
            checkVpn();
        } else if (requestCode == REQ_VPN) {
            refreshPermissionStates();
            if (resultCode == RESULT_OK) {
                startEngine();
            } else {
                waiting = false;
                setUI(false);
                toast("A permissão da VPN foi negada!");
            }
        } else {
            refreshPermissionStates();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIF) {
            refreshPermissionStates();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissionStates();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopLogoRotation();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopLogoRotation();
    }

    private int dp(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void startEngineBlink(final View dot) {
        stopEngineBlink();
        engineBlinkRunnable = new Runnable() {
            boolean bright = true;

            @Override
            public void run() {
                if (dot == null || !engineOn) return;
                GradientDrawable gd = (GradientDrawable) dot.getBackground();
                gd.setColor(bright ? Color.parseColor("#00FF9D") : Color.parseColor("#33FF9D"));
                bright = !bright;
                mainHandler.postDelayed(this, 180);
            }
        };
        mainHandler.post(engineBlinkRunnable);
    }

    private void stopEngineBlink() {
        if (engineBlinkRunnable != null) {
            mainHandler.removeCallbacks(engineBlinkRunnable);
            engineBlinkRunnable = null;
        }
    }
}
