package com.fakelag.cryhard8;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class FloatingService extends Service {

    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams params;

    private TextView txtTimer;
    private TextView txtSliderVal;
    private SeekBar seekTimer;
    private Button btnStartFreeze;

    private CountDownTimer freezeTimer;
    private int selectedSeconds = 5;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_menu_layout, null);

        int layoutType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O 
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY 
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 100;
        params.y = 100;

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        windowManager.addView(floatingView, params);

        final ImageView icon = (ImageView) floatingView.findViewById(R.id.img_float_icon);
        final LinearLayout menuContainer = (LinearLayout) floatingView.findViewById(R.id.menu_container);

        txtTimer = (TextView) floatingView.findViewById(R.id.txt_timer);
        txtSliderVal = (TextView) floatingView.findViewById(R.id.txt_slider_val);
        seekTimer = (SeekBar) floatingView.findViewById(R.id.seek_timer);
        btnStartFreeze = (Button) floatingView.findViewById(R.id.btn_start_freeze);

        icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (menuContainer.getVisibility() == View.GONE) {
                    menuContainer.setVisibility(View.VISIBLE);
                } else {
                    menuContainer.setVisibility(View.GONE);
                }
            }
        });

        seekTimer.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress < 1) progress = 1;
                selectedSeconds = progress;
                txtSliderVal.setText("Set Time: " + selectedSeconds + " Sec");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnStartFreeze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long durationMillis = selectedSeconds * 1000L;
                
                Intent intent = new Intent(FloatingService.this, FakelagOpus1.class);
                intent.setAction(FakelagOpus1.ACTION_FREEZE);
                intent.putExtra(FakelagOpus1.EXTRA_FREEZE_DURATION, durationMillis);
                startService(intent);

                startFreezeTimer(durationMillis);
            }
        });

        icon.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return false;

                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params);
                        return true;
                }
                return false;
            }
        });
    }

    public void startFreezeTimer(long millisInFuture) {
        if (freezeTimer != null) {
            freezeTimer.cancel();
        }

        txtTimer.setVisibility(View.VISIBLE);

        freezeTimer = new CountDownTimer(millisInFuture, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                long secondsLeft = (millisUntilFinished / 1000) + 1;
                txtTimer.setText("Freeze Off: " + secondsLeft + "s");
            }

            @Override
            public void onFinish() {
                txtTimer.setText("Freeze Off");
                txtTimer.setVisibility(View.GONE);
            }
        }.start();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (freezeTimer != null) freezeTimer.cancel();
        if (floatingView != null && windowManager != null) {
            windowManager.removeView(floatingView);
        }
    }
}
