package com.fakelag.cryhard8.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp

// Use Roboto Flex / Inter fallback
val AppFontFamily = FontFamily.Default

val Typography = Typography(
    displayLarge = androidx.compose.ui.text.TextStyle(fontFamily = AppFontFamily, fontSize = 57.sp),
    headlineMedium = androidx.compose.ui.text.TextStyle(fontFamily = AppFontFamily, fontSize = 28.sp),
    titleLarge = androidx.compose.ui.text.TextStyle(fontFamily = AppFontFamily, fontSize = 20.sp),
    bodyLarge = androidx.compose.ui.text.TextStyle(fontFamily = AppFontFamily, fontSize = 16.sp),
    labelLarge = androidx.compose.ui.text.TextStyle(fontFamily = AppFontFamily, fontSize = 14.sp)
)

