package com.fakelag.cryhard8;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.graphics.drawable.shapes.RoundRectShape;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

public class FakelagOpus2 extends Service {

    private static final String CH_ID = "gbf";
    private static final int NOTIF_ID = 2;

    private boolean isMenuExpanded = false;

    private boolean onStandby = false;
    private boolean onFreeze = false;
    private boolean onGhost = false;
    private boolean onJitter = false;
    private boolean onEsp = false;

    private boolean addedS = false;
    private boolean addedF = false;
    private boolean addedG = false;
    private boolean addedJ = false;
    private boolean addedE = false;
    private boolean addedT = false;
    private boolean addedM = false;

    private TextView btnMenuToggle;
    private TextView btnStandby;
    private TextView btnFreeze;
    private TextView btnGhost;
    private TextView btnJitter;
    private TextView btnEsp;
    private TextView txtStats;

    private WindowManager wm;
    private BroadcastReceiver rcv;

    private boolean showGhostV2 = true;
    private boolean showGhost = true;
    private boolean showFreeze = true;
    private boolean showTele = true;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        doForeground();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        android.content.SharedPreferences prefs = getSharedPreferences("xevpn_prefs", Context.MODE_PRIVATE);
        showGhostV2 = prefs.getBoolean("show_ghost_v2", true);
        showGhost = prefs.getBoolean("show_ghost", true);
        showFreeze = prefs.getBoolean("show_freeze", true);
        showTele = prefs.getBoolean("show_tele", true);

        btnMenuToggle = makeBtn("MENU\nOFF", 20, 80, 99);
        paintMenuButton(false);

        if (showGhostV2) btnStandby = makeBtn("PING OFF", 20, 200, 0);
        if (showFreeze) btnFreeze = makeBtn("FREEZE", 20, 320, 2);
        if (showGhost) btnGhost = makeBtn("GHOST", 20, 440, 3);
        if (showTele) btnJitter = makeBtn("TELE", 20, 560, 4);
        
        // Floating Menu ESP Toggle Button (ID: 5)
        btnEsp = makeBtn("ESP", 20, 680, 5);

        makeStat();
        doRegister();

        if (btnStandby != null) paintStandby(false);
        if (btnFreeze != null) paintBtn(btnFreeze, "FREEZE", false);
        if (btnGhost != null) paintBtn(btnGhost, "GHOST", false);
        if (btnJitter != null) paintBtn(btnJitter, "TELE", false);
        if (btnEsp != null) paintBtn(btnEsp, "ESP", false);

        updateMenuVisibility(false);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            if (rcv != null) unregisterReceiver(rcv);
        } catch (Exception e) { }
        rm(btnMenuToggle, addedM);
        rm(btnStandby, addedS);
        rm(btnFreeze, addedF);
        rm(btnGhost, addedG);
        rm(btnJitter, addedJ);
        rm(btnEsp, addedE);
        rm(txtStats, addedT);
    }

    private void updateMenuVisibility(boolean visible) {
        int visibility = visible ? View.VISIBLE : View.GONE;
        if (btnStandby != null) btnStandby.setVisibility(visibility);
        if (btnFreeze != null) btnFreeze.setVisibility(visibility);
        if (btnGhost != null) btnGhost.setVisibility(visibility);
        if (btnJitter != null) btnJitter.setVisibility(visibility);
        if (btnEsp != null) btnEsp.setVisibility(visibility);
        if (txtStats != null) txtStats.setVisibility(visibility);
    }

    private void paintMenuButton(boolean expanded) {
        if (btnMenuToggle == null) return;
        btnMenuToggle.setBackground(createLiquidGlassBackground(expanded, true));
        if (expanded) {
            btnMenuToggle.setTextColor(Color.argb(255, 3, 218, 197));
            btnMenuToggle.setText("MENU\nON");
        } else {
            btnMenuToggle.setTextColor(Color.WHITE);
            btnMenuToggle.setText("MENU\nOFF");
        }
    }

    private void doForeground() {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (nm != null) {
                    NotificationChannel ch = new NotificationChannel(CH_ID, "GB", NotificationManager.IMPORTANCE_MIN);
                    ch.setSound(null, null);
                    nm.createNotificationChannel(ch);
                }
                Notification n = new Notification.Builder(this, CH_ID)
                        .setContentTitle("Play Game - Low Ping")
                        .setContentText("Low Latency Server Activated")
                        .setSmallIcon(0x1080039)
                        .build();
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception e) { }
    }

    private void doRegister() {
        rcv = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !FakelagOpus1.ACTION_STATS.equals(intent.getAction())) return;
                if (txtStats == null || !addedT) return;

                int ping = intent.getIntExtra("ping", 0);
                int loss = intent.getIntExtra("loss", 0);
                long bin = intent.getLongExtra(FakelagOpus1.EXTRA_BYTES_IN, 0L);
                long bout = intent.getLongExtra(FakelagOpus1.EXTRA_BYTES_OUT, 0L);
                String mode = intent.getStringExtra("mode");
                if (mode == null) mode = "STANDBY";

                String color = (ping < 80) ? "#00E676" : (ping < 150) ? "#FFD600" : "#FF1744";

                try {
                    txtStats.setText(mode + "\n" + ping + "ms L:" + loss + "%\n" + fmt(bin) + "/" + fmt(bout));
                    txtStats.setTextColor(Color.parseColor(color));
                } catch (Exception e) { }

                boolean isActive = "ACTIVE".equals(mode);
                if (isActive != onStandby) {
                    onStandby = isActive;
                    paintStandby(isActive);
                }
            }
        };
        try {
            registerReceiver(rcv, new IntentFilter("com.fakelag.cryhard8.STATS"));
        } catch (Exception e) { }
    }

    private TextView makeBtn(String label, int x, int y, int id) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(0xFFFFFFFF);
        int sizePx = (id == 99 || id == 0) ? 110 : 160;

        tv.setTextSize((id == 99 || id == 0) ? 7f : 9f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setSingleLine(false);

        int type = (Build.VERSION.SDK_INT >= 26) ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                sizePx, sizePx, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = x;
        p.y = y;
        wm.addView(tv, p);

        if (id == 99) addedM = true;
        else if (id == 0) addedS = true;
        else if (id == 2) addedF = true;
        else if (id == 3) addedG = true;
        else if (id == 4) addedJ = true;
        else if (id == 5) addedE = true;

        tv.setOnTouchListener(new BtnTouchListener(p, tv, id));
        return tv;
    }

    private Drawable createLiquidGlassBackground(boolean isActive, boolean isVpn) {
        ShapeDrawable baseLayer = new ShapeDrawable(new OvalShape());
        baseLayer.getPaint().setColor(Color.argb(isActive ? 180 : 120, 20, 20, 20));

        GradientDrawable borderLayer = new GradientDrawable();
        borderLayer.setShape(GradientDrawable.OVAL);
        borderLayer.setColor(Color.TRANSPARENT);
        borderLayer.setStroke(
                isActive ? 3 : 2,
                isActive ? Color.argb(200, 0, 230, 118) : Color.argb(100, 255, 255, 255)
        );

        Drawable[] layers = new Drawable[]{baseLayer, borderLayer};
        return new LayerDrawable(layers);
    }

    private Drawable createStatsBackground(boolean isActive) {
        float[] radii = new float[8];
        for (int i = 0; i < 8; i++) radii[i] = 24f;
        ShapeDrawable bg = new ShapeDrawable(new RoundRectShape(radii, null, null));
        bg.getPaint().setColor(Color.argb(204, 0, 0, 0));
        return bg;
    }

    private void makeStat() {
        try {
            txtStats = new TextView(this);
            txtStats.setText("PING OFF\n0ms L:0%\n0K/0K");
            txtStats.setTextColor(Color.argb(255, 0, 230, 118));
            txtStats.setTextSize(10f);
            txtStats.setTypeface(Typeface.MONOSPACE);
            txtStats.setPadding(12, 8, 12, 8);
            txtStats.setBackground(createStatsBackground(false));

            int type = (Build.VERSION.SDK_INT >= 26) ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    android.graphics.PixelFormat.TRANSLUCENT);
            p.gravity = Gravity.TOP | Gravity.START;
            p.x = 8;
            p.y = 50;
            wm.addView(txtStats, p);
            addedT = true;
        } catch (Exception e) { }
    }

    private void paintBtn(TextView tv, String label, boolean on) {
        if (tv == null) return;
        tv.setBackground(createLiquidGlassBackground(on, false));
        tv.setTextColor(on ? Color.argb(255, 0, 230, 118) : Color.WHITE);
        tv.setText(label);
        tv.setGravity(Gravity.CENTER);
    }

    private void paintStandby(boolean on) {
        if (btnStandby == null) return;
        btnStandby.setBackground(createLiquidGlassBackground(on, true));
        btnStandby.setTextColor(on ? Color.argb(255, 0, 255, 0) : Color.WHITE);
        btnStandby.setText(on ? "PING\nON" : "PING\nOFF");
        btnStandby.setGravity(Gravity.CENTER);
    }

    private void click(int id) {
        if (id == 99) {
            isMenuExpanded = !isMenuExpanded;
            paintMenuButton(isMenuExpanded);
            updateMenuVisibility(isMenuExpanded);
        } else if (id == 0) {
            onStandby = !onStandby;
            paintStandby(onStandby);
            send(onStandby ? FakelagOpus1.ACTION_ACTIVATE : FakelagOpus1.ACTION_DEACTIVATE);
        } else if (id == 2) {
            onFreeze = !onFreeze;
            paintBtn(btnFreeze, "FREEZE", onFreeze);
            send(FakelagOpus1.ACTION_FREEZE);
        } else if (id == 3) {
            onGhost = !onGhost;
            paintBtn(btnGhost, "GHOST", onGhost);
            send(FakelagOpus1.ACTION_GHOST);
        } else if (id == 4) {
            onJitter = !onJitter;
            paintBtn(btnJitter, "TELE", onJitter);
            send(FakelagOpus1.ACTION_JITTER);
        } else if (id == 5) {
            onEsp = !onEsp;
            paintBtn(btnEsp, "ESP", onEsp);
            Intent espIntent = new Intent(this, EspService.class);
            if (onEsp) {
                startService(espIntent);
            } else {
                stopService(espIntent);
            }
        }
    }

    private void send(String action) {
        try {
            Intent i = new Intent(this, FakelagOpus1.class);
            i.setAction(action);
            startService(i);
        } catch (Exception e) { }
    }

    private void rm(View v, boolean added) {
        if (!added || v == null) return;
        try { wm.removeView(v); } catch (Exception e) { }
    }

    private String fmt(long bytes) {
        if (bytes < 1024) return bytes + "B";
        if (bytes < 1048576) return (bytes / 1024) + "K";
        return (bytes / 1048576) + "M";
    }

    private class BtnTouchListener implements View.OnTouchListener {
        private final WindowManager.LayoutParams p;
        private final TextView tv;
        private final int id;
        private int ox, oy;
        private float rx, ry;
        private boolean drag = false;

        BtnTouchListener(WindowManager.LayoutParams p, TextView tv, int id) {
            this.p = p; this.tv = tv; this.id = id;
        }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    ox = p.x; oy = p.y;
                    rx = e.getRawX(); ry = e.getRawY();
                    drag = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - rx;
                    float dy = e.getRawY() - ry;
                    if (Math.abs(dx) > 8f || Math.abs(dy) > 8f) {
                        drag = true;
                        p.x = ox + (int) dx;
                        p.y = oy + (int) dy;
                        try { wm.updateViewLayout(tv, p); } catch (Exception ex) { }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!drag) click(id);
                    return true;
            }
            return false;
        }
    }
}
