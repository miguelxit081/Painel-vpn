package com.mg.panel.ui.settings;

import android.app.Activity;
import android.view.View;
import android.widget.TextView;

import com.mg.panel.R;
import com.mg.panel.diag.Diag;
import com.mg.panel.diag.Slot;

public final class Pager {

    public static final int PAGE_HOME = 0;
    public static final int PAGE_OVERLAY = 1;
    public static final int PAGE_AIM = 2;
    public static final int PAGE_SYSTEM = 3;
    private static final int COUNT = 4;

    private final Activity activity;
    private final View[] pages = new View[COUNT];
    private final TextView[] tabs = new TextView[COUNT];
    private final android.graphics.Typeface[] baseFace =
            new android.graphics.Typeface[COUNT];
    private final View scroll;
    private final View[] indicators = new View[COUNT];
    private final View strip;

    private int current = -1;

    private static int getResId(Activity act, String name) {
        return act.getResources().getIdentifier(name, "id", act.getPackageName());
    }

    public Pager(Activity activity) {
        this.activity = activity;
        scroll = activity.findViewById(getResId(activity, "nv_scroll"));
        strip  = activity.findViewById(getResId(activity, "engine_strip"));

        pages[PAGE_HOME]    = activity.findViewById(getResId(activity, "page_home"));
        pages[PAGE_OVERLAY] = activity.findViewById(getResId(activity, "page_overlay"));
        pages[PAGE_AIM]     = activity.findViewById(getResId(activity, "page_aim"));
        pages[PAGE_SYSTEM]  = activity.findViewById(getResId(activity, "page_system"));

        tabs[PAGE_HOME]    = (TextView) activity.findViewById(getResId(activity, "tab_home"));
        tabs[PAGE_OVERLAY] = (TextView) activity.findViewById(getResId(activity, "tab_overlay"));
        tabs[PAGE_AIM]     = (TextView) activity.findViewById(getResId(activity, "tab_aim"));
        tabs[PAGE_SYSTEM]  = (TextView) activity.findViewById(getResId(activity, "tab_system"));

        indicators[PAGE_HOME]    = activity.findViewById(getResId(activity, "ind_home"));
        indicators[PAGE_OVERLAY] = activity.findViewById(getResId(activity, "ind_overlay"));
        indicators[PAGE_AIM]     = activity.findViewById(getResId(activity, "ind_aim"));
        indicators[PAGE_SYSTEM]  = activity.findViewById(getResId(activity, "ind_system"));

        for (int i = 0; i < COUNT; i++) {
            final int idx = i;
            if (tabs[i] == null) continue;
            baseFace[i] = tabs[i].getTypeface();
            tabs[i].setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { show(idx); }
            });
        }
    }

    public void show(int page) {
        if (page < 0 || page >= COUNT) return;
        if (page == current) {
            if (scroll != null) scroll.scrollTo(0, 0);
            return;
        }
        current = page;
        for (int i = 0; i < COUNT; i++) {
            if (pages[i] != null) {
                pages[i].setVisibility(i == page ? View.VISIBLE : View.GONE);
            }
            paintTab(i, i == page);
        }
        if (scroll != null) scroll.scrollTo(0, 0);
        if (strip != null) {
            strip.setVisibility(page == PAGE_HOME ? View.GONE : View.VISIBLE);
        }
        Diag.hit(Slot.UI_PAGE_SHOWN);
    }

    public int current() { return current; }

    private void paintTab(int i, boolean on) {
        TextView t = tabs[i];
        if (t == null) return;
        int colour = activity.getResources().getColor(
                on ? R.color.nv_teal : R.color.nv_text_3);
        t.setTextColor(colour);
        android.graphics.drawable.Drawable[] d = t.getCompoundDrawables();
        if (d != null && d[1] != null) {
            d[1].mutate().setColorFilter(colour, android.graphics.PorterDuff.Mode.SRC_IN);
        }
        t.setTypeface(android.graphics.Typeface.create(
                baseFace[i], on ? android.graphics.Typeface.BOLD
                                : android.graphics.Typeface.NORMAL));
        t.setAlpha(1f);
        View ind = indicators[i];
        if (ind != null) ind.setVisibility(on ? View.VISIBLE : View.INVISIBLE);
    }
}
