package com.mg.panel.ui.panel;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.mg.panel.R;
import com.mg.panel.config.EspTuning;
import com.mg.panel.config.Prefs;
import com.mg.panel.ui.aim.AimConfig;
import com.mg.panel.ui.aim.AimController;
import com.mg.panel.freeze.FreezeController;
import com.mg.panel.ui.settings.AppearanceBroadcaster;

/**
 * One compact in-game control surface. It intentionally owns the controls that
 * used to be split between the Aim tab and Overlay tab, so the user can change
 * them without leaving the game. Width, height and drag bounds are calculated
 * from the real display every time the panel is shown.
 */
public final class FloatingControlPanel {
    private static final int BLACK = Color.rgb(7, 12, 10);
    private static final int SURFACE = Color.rgb(21, 25, 28);
    private static final int SURFACE_2 = Color.rgb(27, 39, 33);
    private static final int GREEN = Color.rgb(53, 208, 127);
    private static final int GREEN_BRIGHT = Color.rgb(99, 230, 161);
    private static final int WHITE = Color.WHITE;
    private static final int MUTED = Color.rgb(190, 190, 195);
    private static final int RED = Color.rgb(255, 107, 122);

    private final Context context;
    private final WindowManager wm;
    private final AppearanceBroadcaster broadcaster;
    private final SharedPreferences prefs;
    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
    private WindowManager.LayoutParams params;
    private LinearLayout root;
    private LinearLayout header;
    private ImageButton logoView;
    private TextView titleView;
    private TextView minimizeView;
    private TextView closeView;
    private LinearLayout content;
    private ScrollView scroll;
    private boolean added;
    private boolean minimized;
    private int panelWidth;
    private int maxPanelHeight;
    private int downX;
    private int downY;
    private float rawDownX;
    private float rawDownY;
    private boolean dragMoved;

    public FloatingControlPanel(Context context, WindowManager wm) {
        this.context = context;
        this.wm = wm;
        this.broadcaster = new AppearanceBroadcaster(context);
        this.prefs = Prefs.get(context);
    }

    public void show() {
        if (added) return;
        final int[] size = displaySize();
        // Keep the expanded surface short enough for one-handed phone use. The
        // settings remain scrollable, but the panel no longer dominates the
        // gameplay viewport on small displays.
        panelWidth = clamp(Math.round(size[0] * 0.72f), dp(200), dp(300));
        maxPanelHeight = clamp(Math.round(size[1] * 0.44f), dp(220), dp(380));

        root = new LinearLayout(context);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(4), dp(4), dp(4), dp(4));
        root.setBackground(panelBackground());

        // The mark belongs to the minimized floating bubble only. Keeping it
        // outside the expanded header avoids repeating the logo in the panel.
        logoView = new ImageButton(context);
        logoView.setImageResource(R.drawable.nepdon_logo_floating);
        logoView.setContentDescription("Open HyperS controls");
        logoView.setScaleType(android.widget.ImageView.ScaleType.CENTER_INSIDE);
        logoView.setBackground(round(Color.rgb(11, 28, 20), dp(26), GREEN_BRIGHT));
        logoView.setPadding(0, 0, 0, 0);
        logoView.setVisibility(View.GONE);
        root.addView(logoView, new LinearLayout.LayoutParams(dp(52), dp(52)));

        header = new LinearLayout(context);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(4), dp(2), dp(2), dp(2));
        header.setBackground(round(SURFACE_2, dp(10), GREEN));

        titleView = new TextView(context);
        titleView.setText("HyperS : v3");
        titleView.setTextColor(WHITE);
        titleView.setTextSize(13f);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setGravity(Gravity.CENTER_VERTICAL);
        titleView.setSingleLine(true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        titleLp.leftMargin = dp(6);
        header.addView(titleView, titleLp);

        minimizeView = headerButton("−", "Minimize HyperS controls", GREEN_BRIGHT);
        closeView = headerButton("×", "Close HyperS controls", RED);
        header.addView(minimizeView, new LinearLayout.LayoutParams(dp(34), dp(36)));
        header.addView(closeView, new LinearLayout.LayoutParams(dp(34), dp(36)));
        root.addView(header, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(40)));

        content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(2), dp(4), dp(2), dp(8));
        scroll = new ScrollView(context);
        scroll.setFillViewport(true);
        scroll.addView(content, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, maxPanelHeight - dp(54));
        root.addView(scroll, scrollLp);

        section("AIM CONTROLS");
        liveToggle("Aim Assist",
                "Fire / drag → snaps to head via touch injection (Shizuku)",
                AimController::isActive,
                b -> {
                    AimConfig.AIM_ENABLED = b;
                    if (b) {
                        AimController.arm();
                        AimController.setActive(true);
                    } else {
                        AimController.setActive(false);
                        AimController.disarm();
                    }
                });
        toggle("Aim Lag", Prefs.KEY_AIM_LAG, false,
                "Master gate for aim-lag tracking");
        liveToggle("Auto Freeze",
                "Master switch — freeze pos packets on fire/scope/both",
                () -> FreezeController.isAutoFreeze() || FreezeController.isScopeFreeze(),
                b -> {
                    String mode = prefs.getString(com.mg.panel.config.Prefs.KEY_FREEZE_MODE, "fire");
                    if (b) {
                        if ("scope".equals(mode)) {
                            FreezeController.setAutoFreeze(false);
                            FreezeController.setScopeFreeze(true);
                        } else if ("both".equals(mode)) {
                            FreezeController.setAutoFreeze(true);
                            FreezeController.setScopeFreeze(true);
                        } else {
                            FreezeController.setAutoFreeze(true);
                            FreezeController.setScopeFreeze(false);
                        }
                    } else {
                        FreezeController.setAutoFreeze(false);
                        FreezeController.setScopeFreeze(false);
                    }
                    prefs.edit().putBoolean(com.mg.panel.config.Prefs.KEY_AUTO_FREEZE,
                            FreezeController.isAutoFreeze())
                            .putBoolean(com.mg.panel.config.Prefs.KEY_SCOPE_FREEZE,
                            FreezeController.isScopeFreeze()).apply();
                });
        freezeModeSelector();

        section("OVERLAY CONTROLS");
        toggle("Freeze button", Prefs.KEY_FREEZE, true,
                "Show or hide the in-game Freeze button");
        toggle("Ghost button", Prefs.KEY_GHOST, true,
                "Show or hide the in-game Ghost button");
        toggle("Tele button", Prefs.KEY_TELE, false,
                "Show or hide the in-game Tele button");
        toggle("ESP boxes", Prefs.KEY_ESP_BOXES, true,
                "Draw enemy boxes");
        toggle("Radar", Prefs.KEY_ESP_RADAR, true,
                "Draw the radar");
        toggle("ESP line", Prefs.KEY_ESP_LINE, false,
                "Draw a line from the bottom of the screen");
        toggle("Skeleton", Prefs.KEY_ESP_SKELETON, true,
                "Draw enemy skeletons");
        toggle("Distance", Prefs.KEY_ESP_DIST_TEXT, true,
                "Show distance labels");
        toggle("Name", Prefs.KEY_ESP_NAME_TEXT, true,
                "Show enemy name labels");
        toggle("HP number", Prefs.KEY_ESP_HP_TEXT, true,
                "Show enemy HP values");

        View.OnTouchListener drag = new HeaderDragListener();
        header.setOnTouchListener(drag);
        titleView.setOnTouchListener(drag);
        logoView.setOnTouchListener(drag);
        minimizeView.setOnClickListener(v -> setMinimized(true));
        closeView.setOnClickListener(v -> exitEverything());

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_SPLIT_TOUCH;
        params = new WindowManager.LayoutParams(panelWidth,
                WindowManager.LayoutParams.WRAP_CONTENT, type, flags, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = clamp(dp(12), 0, Math.max(0, size[0] - panelWidth));
        params.y = clamp(dp(72), 0, Math.max(0, size[1] - maxPanelHeight));
        try {
            wm.addView(root, params);
            added = true;
        } catch (Throwable ignored) {
            added = false;
            root = null;
            params = null;
        }
    }

    public void hide() {
        if (root != null && added) {
            try { wm.removeView(root); } catch (Throwable ignored) { }
        }
        added = false;
        root = null;
        params = null;
        content = null;
        scroll = null;
    }

    public boolean isShown() { return added; }

    /** Stop the overlay, stop the VPN engine, then close the app task. */
    private void exitEverything() {
        hide();
        try {
            context.stopService(new android.content.Intent(context,
                    com.mg.panel.FloatingOverlayService.class));
            android.content.Intent stop = new android.content.Intent(context,
                    com.mg.panel.PacketVpnService.class);
            stop.setAction(com.mg.panel.config.VpnActions.ACTION_STOP);
            try {
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(stop);
                else context.startService(stop);
            } catch (Throwable ignored) { }
            android.content.Intent close = new android.content.Intent(context,
                    com.mg.panel.MainActivity.class);
            close.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                    | android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP);
            close.putExtra("nepdon_exit_app", true);
            context.startActivity(close);
        } catch (Throwable ignored) { }
    }

    private void setMinimized(boolean value) {
        minimized = value;
        if (scroll != null) scroll.setVisibility(value ? View.GONE : View.VISIBLE);
        if (header != null) header.setVisibility(value ? View.GONE : View.VISIBLE);
        if (logoView != null) logoView.setVisibility(value ? View.VISIBLE : View.GONE);
        if (titleView != null) titleView.setVisibility(value ? View.GONE : View.VISIBLE);
        if (minimizeView != null) minimizeView.setVisibility(value ? View.GONE : View.VISIBLE);
        if (closeView != null) closeView.setVisibility(value ? View.GONE : View.VISIBLE);
        if (header != null) {
            header.setPadding(value ? 0 : dp(4), value ? 0 : dp(2), value ? 0 : dp(2), value ? 0 : dp(2));
            header.setBackground(value ? round(Color.TRANSPARENT, dp(24), Color.TRANSPARENT)
                    : round(SURFACE_2, dp(10), GREEN));
        }
        if (logoView != null) logoView.requestLayout();
        if (root != null) {
            root.setPadding(value ? 0 : dp(4), value ? 0 : dp(4), value ? 0 : dp(4), value ? 0 : dp(4));
            root.setBackground(value ? round(Color.TRANSPARENT, dp(26), Color.TRANSPARENT)
                    : panelBackground());
        }
        if (root != null) {
            WindowManager.LayoutParams p = params;
            if (p != null) {
                p.width = value ? dp(52) : panelWidth;
                p.height = WindowManager.LayoutParams.WRAP_CONTENT;
                try { wm.updateViewLayout(root, p); } catch (Throwable ignored) { }
            }
        }
    }

    private void section(String text) {
        TextView t = new TextView(context);
        t.setText(text);
        t.setTextColor(GREEN_BRIGHT);
        t.setTextSize(11f);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLetterSpacing(0.12f);
        t.setPadding(dp(8), dp(7), dp(8), dp(3));
        content.addView(t, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private void toggle(String label, final String key, final boolean defaultOn, String hint) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), dp(4), dp(6), dp(4));
        row.setBackground(round(SURFACE, dp(8), Color.rgb(36, 64, 45)));
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        rowLp.topMargin = dp(3);
        content.addView(row, rowLp);

        LinearLayout labels = new LinearLayout(context);
        labels.setOrientation(LinearLayout.VERTICAL);
        TextView name = new TextView(context);
        name.setText(label);
        name.setTextColor(WHITE);
        name.setTextSize(13f);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        TextView sub = new TextView(context);
        sub.setText(hint);
        sub.setTextColor(MUTED);
        sub.setTextSize(9f);
        sub.setSingleLine(true);
        labels.addView(name);
        labels.addView(sub);
        row.addView(labels, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        final TextView state = new TextView(context);
        state.setGravity(Gravity.CENTER);
        state.setTextSize(11f);
        state.setTypeface(Typeface.DEFAULT_BOLD);
        state.setTextColor(BLACK);
        state.setMinWidth(dp(58));
        state.setMinHeight(dp(34));
        row.addView(state, new LinearLayout.LayoutParams(dp(60), dp(34)));

        final Runnable paint = () -> {
            boolean on = prefs.getBoolean(key, defaultOn);
            state.setText(on ? "ON" : "OFF");
            state.setTextColor(on ? BLACK : WHITE);
            state.setBackground(round(on ? GREEN : Color.rgb(50, 65, 56), dp(8),
                    on ? GREEN_BRIGHT : Color.rgb(86, 110, 94)));
        };
        paint.run();
        View.OnClickListener flip = v -> {
            boolean next = !prefs.getBoolean(key, defaultOn);
            prefs.edit().putBoolean(key, next).apply();
            paint.run();
            broadcaster.send();
            v.animate().cancel();
            v.setScaleX(0.97f); v.setScaleY(0.97f);
            v.animate().scaleX(1f).scaleY(1f).setDuration(110L).start();
        };
        row.setOnClickListener(flip);
        state.setOnClickListener(flip);
    }

    /** Toggle that reads/writes a live volatile static (via lambdas) instead of a prefs key. */
    private void liveToggle(String label, String hint,
            java.util.function.BooleanSupplier getter,
            java.util.function.Consumer<Boolean> setter) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), dp(4), dp(6), dp(4));
        row.setBackground(round(SURFACE, dp(8), Color.rgb(80, 30, 30)));
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        rowLp.topMargin = dp(3);
        content.addView(row, rowLp);

        LinearLayout labels = new LinearLayout(context);
        labels.setOrientation(LinearLayout.VERTICAL);
        TextView name = new TextView(context);
        name.setText(label);
        name.setTextColor(WHITE);
        name.setTextSize(13f);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        TextView sub = new TextView(context);
        sub.setText(hint);
        sub.setTextColor(MUTED);
        sub.setTextSize(9f);
        sub.setSingleLine(true);
        labels.addView(name);
        labels.addView(sub);
        row.addView(labels, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        final TextView state = new TextView(context);
        state.setGravity(Gravity.CENTER);
        state.setTextSize(11f);
        state.setTypeface(Typeface.DEFAULT_BOLD);
        state.setTextColor(BLACK);
        state.setMinWidth(dp(58));
        state.setMinHeight(dp(34));
        row.addView(state, new LinearLayout.LayoutParams(dp(60), dp(34)));

        final Runnable paint = () -> {
            boolean on = getter.getAsBoolean();
            state.setText(on ? "ON" : "OFF");
            state.setTextColor(on ? BLACK : WHITE);
            state.setBackground(round(on ? GREEN : Color.rgb(50, 65, 56), dp(8),
                    on ? GREEN_BRIGHT : Color.rgb(86, 110, 94)));
        };
        paint.run();

        View.OnClickListener flip = v -> {
            setter.accept(!getter.getAsBoolean());
            paint.run();
            broadcaster.send();
            v.animate().cancel();
            v.setScaleX(0.97f); v.setScaleY(0.97f);
            v.animate().scaleX(1f).scaleY(1f).setDuration(110L).start();
        };
        row.setOnClickListener(flip);
        state.setOnClickListener(flip);
    }

    private void freezeModeSelector() {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(10), dp(6), dp(6), dp(6));
        row.setBackground(round(SURFACE, dp(8), Color.rgb(64, 36, 36)));
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(62));
        rowLp.topMargin = dp(3);
        content.addView(row, rowLp);

        TextView label = new TextView(context);
        label.setText("Auto Freeze trigger");
        label.setTextColor(WHITE);
        label.setTextSize(11f);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        row.addView(label, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(19)));

        LinearLayout choices = new LinearLayout(context);
        choices.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(choices, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(32)));
        final String[] modes = {"fire", "scope", "both"};
        final TextView[] buttons = new TextView[3];
        for (int i = 0; i < modes.length; i++) {
            final String mode = modes[i];
            TextView b = new TextView(context);
            b.setText(mode.toUpperCase(java.util.Locale.US));
            b.setTextSize(9f);
            b.setTypeface(Typeface.DEFAULT_BOLD);
            b.setGravity(Gravity.CENTER);
            b.setTextColor(WHITE);
            buttons[i] = b;
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(28), 1f);
            if (i > 0) bp.leftMargin = dp(4);
            choices.addView(b, bp);
            b.setOnClickListener(v -> {
                prefs.edit().putString(Prefs.KEY_FREEZE_MODE, mode).apply();
                paintFreezeMode(buttons, modes);
                broadcaster.send();
            });
        }
        paintFreezeMode(buttons, modes);
    }

    private void paintFreezeMode(TextView[] buttons, String[] modes) {
        String current = prefs.getString(Prefs.KEY_FREEZE_MODE, "fire");
        for (int i = 0; i < buttons.length; i++) {
            boolean selected = modes[i].equals(current);
            buttons[i].setTextColor(selected ? BLACK : WHITE);
            buttons[i].setBackground(round(selected ? GREEN_BRIGHT : Color.rgb(55, 55, 60),
                    dp(7), selected ? GREEN_BRIGHT : Color.rgb(120, 120, 125)));
        }
    }

    private TextView headerButton(String text, String description, int color) {
        TextView b = new TextView(context);
        b.setText(text);
        b.setContentDescription(description);
        b.setTextColor(color);
        b.setTextSize(24f);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(Color.TRANSPARENT, dp(8), Color.TRANSPARENT));
        return b;
    }

    private GradientDrawable panelBackground() {
        return round(BLACK, dp(14), GREEN);
    }

    private GradientDrawable round(int fill, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(radius);
        if (stroke != Color.TRANSPARENT) d.setStroke(Math.max(1, dp(1)), stroke);
        return d;
    }

    private final class HeaderDragListener implements View.OnTouchListener {
        @Override public boolean onTouch(View v, MotionEvent e) {
            if (params == null || root == null) return false;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = params.x; downY = params.y;
                    rawDownX = e.getRawX(); rawDownY = e.getRawY();
                    dragMoved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int[] size = displaySize();
                    if (Math.abs(e.getRawX() - rawDownX) > dp(5)
                            || Math.abs(e.getRawY() - rawDownY) > dp(5)) {
                        dragMoved = true;
                    }
                    params.x = clamp(downX + Math.round(e.getRawX() - rawDownX),
                            0, Math.max(0, size[0] - panelWidth));
                    params.y = clamp(downY + Math.round(e.getRawY() - rawDownY),
                            0, Math.max(0, size[1] - dp(54)));
                    try { wm.updateViewLayout(root, params); } catch (Throwable ignored) { }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (e.getActionMasked() == MotionEvent.ACTION_UP
                            && v == logoView && !dragMoved) {
                        setMinimized(!minimized);
                    }
                    return true;
                default: return true;
            }
        }
    }

    private int[] displaySize() {
        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        try { wm.getDefaultDisplay().getRealMetrics(dm); }
        catch (Throwable ignored) { context.getResources().getDisplayMetrics().setTo(dm); }
        return new int[]{Math.max(1, dm.widthPixels), Math.max(1, dm.heightPixels)};
    }

    private int dp(int value) {
        return Math.max(1, Math.round(value * context.getResources().getDisplayMetrics().density));
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
