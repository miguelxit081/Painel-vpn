package com.mg.panel;

import com.mg.panel.config.Prefs;
import com.mg.panel.config.VpnActions;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.net.VpnService;
import android.os.Build;

import com.mg.panel.tunnel.UdpSessionManager;
import com.mg.panel.tunnel.VpnEngine;
import com.mg.panel.tunnel.VpnEngineState;
import com.mg.panel.dev.DevLoggerImpl;
import com.mg.panel.filter.DefaultFilterEngine;
import com.mg.panel.filter.FilterEngine;
import com.mg.panel.filter.FilterKind;

import java.util.ArrayDeque;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PacketVpnService extends VpnService {

    private static final String CH_ID = "vpn_svc";
    private static final boolean VIP_HYBRID = false;
    private static final int MAX_PENDING_TOGGLES = 4;

    private static volatile PacketVpnService instance;

    public static VpnEngineState snapshot() {
        PacketVpnService s = instance;
        return s == null ? null : s.engine.snapshotState();
    }

    public static com.mg.panel.esp.EspEngine espEngine() {
        PacketVpnService s = instance;
        return s == null ? null : s.engine.esp();
    }

    public static FilterEngine filterEngineOrNull() {
        PacketVpnService s = instance;
        return s == null ? null : s.filterEngine;
    }

    public static boolean applyFilterTap(FilterKind kind) {
        if (VIP_HYBRID) return false;
        PacketVpnService s = instance;
        if (s == null || kind == null) return false;
        s.enqueueOrApplyFilterToggle(kind);
        s.engine.broadcastState();
        return true;
    }

    public static boolean engineAcceptsTaps() {
        if (VIP_HYBRID) return true;
        PacketVpnService s = instance;
        return s != null && !s.engineStopped();
    }

    private ExecutorService threadPool;
    private DevLoggerImpl devLogger;
    private UdpSessionManager sessions;
    private FilterEngine filterEngine;
    private VpnEngine engine;
    private BroadcastReceiver devReceiver;

    private final ArrayDeque<PendingToggle> pendingToggles = new ArrayDeque<>();
    private final java.util.concurrent.atomic.AtomicBoolean draining =
            new java.util.concurrent.atomic.AtomicBoolean(false);
    private volatile boolean pendingCaptureStart = false;
    private volatile int pendingCaptureHexLimit = 32;

    @Override
    public void onCreate() {
        super.onCreate();
        threadPool = Executors.newCachedThreadPool();
        devLogger = new DevLoggerImpl(this);
        sessions = new UdpSessionManager(this, devLogger, threadPool);
        filterEngine = new DefaultFilterEngine(sessions, devLogger, this);
        engine = new VpnEngine(this, filterEngine, sessions, devLogger, this);
        engine.setStateListener(new VpnEngine.StateListener() {
            @Override
            public void onEngineStateChanged(VpnEngineState state) {
                if (state.isRunnable()) drainPendingToggles();
            }
        });
        setupForeground();
        setupDevReceiver();
        devLogger.setEnabled(false);
        engine.loadTeleReplayDelay();
        engine.loadLobbyRouteSetting(false);
        instance = this;
        startHeartbeat();
    }

    private java.util.concurrent.ScheduledExecutorService heartbeatPool;

    private void startHeartbeat() {
        if (!com.mg.panel.auth.AuthConfig.HEARTBEAT_ENABLED
                || !com.mg.panel.auth.AuthConfig.ENFORCE) {
            return;
        }
        heartbeatPool = java.util.concurrent.Executors.newSingleThreadScheduledExecutor();
        scheduleBeat(0);
    }

    private void scheduleBeat(long delaySec) {
        final java.util.concurrent.ScheduledExecutorService pool = heartbeatPool;
        if (pool == null || pool.isShutdown()) return;
        try {
            pool.schedule(new Runnable() {
                @Override public void run() {
                    long nextSec = com.mg.panel.auth.AuthConfig.HEARTBEAT_FALLBACK_SEC;
                    try {
                        nextSec = com.mg.panel.auth.SessionManager.heartbeat(PacketVpnService.this);
                    } catch (com.mg.panel.auth.LicenseClient.AuthException e) {
                        if ("unauthorized".equals(e.code) || "invalid".equals(e.code)) {
                            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.AUTH_HB_TERMINAL);
                            return;
                        }
                        com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.AUTH_HB_FAIL);
                        nextSec = 30;
                    } catch (Throwable t) {
                        com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.AUTH_HB_FAIL);
                        nextSec = 30;
                    }
                    scheduleBeat(nextSec);
                }
            }, delaySec, java.util.concurrent.TimeUnit.SECONDS);
        } catch (Exception ignored) {}
    }

    private void stopHeartbeat() {
        java.util.concurrent.ScheduledExecutorService pool = heartbeatPool;
        heartbeatPool = null;
        if (pool != null) pool.shutdownNow();
    }

    private void setupForeground() {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                NotificationChannel ch = new NotificationChannel(
                        CH_ID, "VPN Service", NotificationManager.IMPORTANCE_LOW);
                if (nm != null) nm.createNotificationChannel(ch);
            }
            Notification n = (Build.VERSION.SDK_INT >= 26)
                    ? new Notification.Builder(this, CH_ID)
                            .setContentTitle("HyperS : v3")
                            .setContentText("VPN tunnel active")
                            .setSmallIcon(android.R.drawable.ic_dialog_info)
                            .build()
                    : buildLegacyNotification();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(1, n);
            }
        } catch (Throwable t) {
            if (devLogger != null) {
                devLogger.logControl("MODE_VPN_FOREGROUND_FAILED",
                        "cls=" + t.getClass().getSimpleName() + " msg=" + t.getMessage());
            }
        }
    }

    @SuppressWarnings("deprecation")
    private Notification buildLegacyNotification() {
        return new Notification.Builder(this)
                .setContentTitle("HyperS : v3")
                .setContentText("VPN tunnel active")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build();
    }

    @Override
    public void onRevoke() {
        if (devLogger != null) {
            devLogger.logControl("MODE_VPN_REVOKED", "tunnel revoked by system or another VPN app");
        }
        com.mg.panel.diag.Diag.event(com.mg.panel.diag.Slot.TUNNEL_REVOKED, "tunnel revoked");
        try {
            if (engine != null) {
                engine.stop();
                engine.broadcastState();
            }
        } catch (Throwable ignored) {}
        stopHeartbeat();
        super.onRevoke();
    }

    private void setupDevReceiver() {
        devReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null) return;
                if (!VpnActions.ACTION_APPLY_FLOAT_APPEARANCE.equals(intent.getAction())) return;
                boolean enabled = intent.getBooleanExtra(VpnActions.EXTRA_DEV_MODE, devLogger.isEnabled());
                devLogger.setEnabled(enabled);
                engine.setTeleReplayDelayMs(intent.getIntExtra(
                        VpnActions.EXTRA_TELE_REPLAY_DELAY, engine.getTeleReplayDelayMs()));
                engine.setLobbyRouteEnabled(intent.getBooleanExtra(VpnActions.EXTRA_LOBBY_ROUTE, true), true);
            }
        };

        try {
            IntentFilter filter = new IntentFilter(VpnActions.ACTION_APPLY_FLOAT_APPEARANCE);
            registerReceiverCompat(devReceiver, filter);
        } catch (Exception e) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.UI_RECEIVER_REGISTER_FAILED);
        }
    }

    private static final String PERM_INTERNAL_BROADCAST = "com.mg.panel.permission.INTERNAL_BROADCAST";

    private void registerReceiverCompat(BroadcastReceiver receiver, IntentFilter filter) {
        if (receiver == null || filter == null) return;
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                java.lang.reflect.Method method = Context.class.getMethod(
                        "registerReceiver", BroadcastReceiver.class, IntentFilter.class, Integer.TYPE);
                method.invoke(this, receiver, filter, Integer.valueOf(4));
                return;
            } catch (Exception ignored) {
                com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.SEC_RECEIVER_EXPORTED);
            }
        }
        try {
            registerReceiver(receiver, filter, PERM_INTERNAL_BROADCAST, null);
        } catch (Exception e) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_STICKY;
        String action = intent.getAction();

        if (VIP_HYBRID && isVipAction(action)) {
            Intent vip = new Intent(this, VipVpnService.class);
            vip.setAction(action);
            if (intent.hasExtra(VpnActions.EXTRA_PACKAGE)) {
                vip.putExtra(VpnActions.EXTRA_PACKAGE, intent.getStringExtra(VpnActions.EXTRA_PACKAGE));
            } else if (VpnActions.ACTION_SET_APP.equals(action)) {
                Set<String> targets = Prefs.getTargetPackages(this);
                if (targets != null && !targets.isEmpty()) {
                    vip.putExtra(VpnActions.EXTRA_PACKAGE, targets.iterator().next());
                }
            }
            if (VpnActions.ACTION_STOP.equals(action)) {
                stopService(vip);
                stopSelf();
                return START_NOT_STICKY;
            }
            try {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(vip);
                else startService(vip);
            } catch (Exception ignored) {}
            return START_STICKY;
        }

        if (VpnActions.ACTION_SET_APP.equals(action)) {
            Set<String> packages = Prefs.getTargetPackages(this);
            String single = intent.getStringExtra(VpnActions.EXTRA_PACKAGE);
            if (single == null) single = intent.getStringExtra(VpnActions.EXTRA_PACKAGE_ALT);
            if (single != null && !single.isEmpty()) {
                packages = new LinkedHashSet<>();
                packages.add(single);
                Prefs.setTargetPackages(this, packages);
            }
            engine.setTargetPackages(packages);
            engine.disableFilters();
            clearPendingToggles();
            engine.setActive(true);
            engine.setFilterEnabled(true);
            if (engine.isRun()) {
                engine.restartTunnel(true);
            }
        } else if (VpnActions.ACTION_STOP.equals(action)) {
            clearPendingToggles();
            stop();
            return START_NOT_STICKY;
        } else if (VpnActions.ACTION_ACTIVATE.equals(action)) {
            engine.setFilterEnabled(true);
            if (!engine.isRun()) {
                engine.setActive(true);
            } else if (!engine.isActive()) {
                engine.toggle(true);
            } else {
                engine.setActive(true);
            }
        } else if (VpnActions.ACTION_DEACTIVATE.equals(action)) {
            engine.disableFilters();
            if (engine.isActive()) engine.toggle(false);
            return START_NOT_STICKY;
        } else {
            FilterKind kind = FilterKind.fromAction(action);
            if (kind != null) {
                enqueueOrApplyFilterToggle(kind);
            } else if (VpnActions.ACTION_CAPTURE_START.equals(action)) {
                int hexLimit = intent.getIntExtra(
                        VpnActions.EXTRA_CAPTURE_HEX_LIMIT,
                        com.mg.panel.dev.capture.PacketCapture.MAX_PAYLOAD_BYTES);
                int mode = com.mg.panel.dev.capture.PacketCapture.modeFromName(
                        intent.getStringExtra(VpnActions.EXTRA_CAPTURE_MODE),
                        com.mg.panel.dev.capture.PacketCapture.modeFromName(
                                Prefs.get(this).getString(Prefs.KEY_CAPTURE_MODE, "full"),
                                com.mg.panel.dev.capture.PacketCapture.MODE_FULL));
                int retro = Prefs.get(this).getInt(Prefs.KEY_CAPTURE_RETRO_SEC, 0);
                if (engine.isRun()) {
                    engine.startCapture(hexLimit, mode, retro);
                } else if (!engineStopped()) {
                    pendingCaptureStart = true;
                    pendingCaptureHexLimit = hexLimit;
                }
            } else if (VpnActions.ACTION_CAPTURE_STOP.equals(action)
                    || VpnActions.ACTION_CAPTURE_DUMP.equals(action)) {
                pendingCaptureStart = false;
                engine.stopCapture();
            } else if (VpnActions.ACTION_TELEMETRY_DUMP.equals(action)) {
                engine.dumpTelemetry();
            }
        }

        if (!engine.isRun() && (VpnActions.ACTION_SET_APP.equals(action) || VpnActions.ACTION_ACTIVATE.equals(action))) {
            engine.start();
        }
        engine.broadcastState();
        return START_STICKY;
    }

    private static boolean isVipAction(String action) {
        return VpnActions.ACTION_SET_APP.equals(action)
                || VpnActions.ACTION_ACTIVATE.equals(action)
                || VpnActions.ACTION_DEACTIVATE.equals(action)
                || VpnActions.ACTION_FREEZE.equals(action)
                || VpnActions.ACTION_GHOST.equals(action)
                || VpnActions.ACTION_JITTER.equals(action)
                || VpnActions.ACTION_STOP.equals(action);
    }

    private boolean engineStopped() {
        return !engine.isRun() && !engine.isFilterEnabled() && !engine.isActive();
    }

    private static final long PENDING_TOGGLE_TTL_MS = 3000L;

    private void enqueueOrApplyFilterToggle(FilterKind kind) {
        if (engine.isRun() && engine.isFilterEnabled()) {
            applyFilterToggle(kind);
            return;
        }
        if (engineStopped()) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.UI_TAP_DISCARDED_ENGINE_OFF);
            return;
        }
        synchronized (pendingToggles) {
            if (kind != FilterKind.JITTER) {
                for (java.util.Iterator<PendingToggle> it = pendingToggles.iterator();
                        it.hasNext(); ) {
                    if (it.next().kind == kind) {
                        it.remove();
                        com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.UI_TAP_COALESCED);
                        return;
                    }
                }
            }
            while (pendingToggles.size() >= MAX_PENDING_TOGGLES) {
                pendingToggles.pollFirst();
            }
            pendingToggles.addLast(new PendingToggle(kind, System.currentTimeMillis()));
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.UI_TAP_QUEUED);
        }
    }

    private void applyFilterToggle(FilterKind kind) {
        filterEngine.toggle(kind);
        engine.noteFilterToggled();
        engine.scheduleLobbyRouteFallbackIfNoUdp(triggerFor(kind));
    }

    private void drainPendingToggles() {
        if (!draining.compareAndSet(false, true)) return;
        try {
            boolean appliedAny = false;
            long now = System.currentTimeMillis();
            while (true) {
                PendingToggle t;
                synchronized (pendingToggles) {
                    t = pendingToggles.pollFirst();
                }
                if (t == null) break;
                if (now - t.atMs > PENDING_TOGGLE_TTL_MS) {
                    com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.UI_TAP_STALE_DROPPED);
                    devLogger.logControl("DROP_STALE_TOGGLE", "kind=" + t.kind + " age_ms=" + (now - t.atMs));
                    continue;
                }
                applyFilterToggle(t.kind);
                appliedAny = true;
            }
            if (pendingCaptureStart) {
                pendingCaptureStart = false;
                engine.startCapture(pendingCaptureHexLimit);
                appliedAny = true;
            }
            if (appliedAny) engine.broadcastState();
        } finally {
            draining.set(false);
        }
    }

    private void clearPendingToggles() {
        synchronized (pendingToggles) {
            pendingToggles.clear();
        }
        pendingCaptureStart = false;
    }

    private static final class PendingToggle {
        final FilterKind kind;
        final long atMs;

        PendingToggle(FilterKind kind, long atMs) {
            this.kind = kind;
            this.atMs = atMs;
        }
    }

    private static String triggerFor(FilterKind kind) {
        switch (kind) {
            case FREEZE: return "freeze";
            case GHOST:  return "ghost";
            case JITTER: return "tele";
            case AIM:    return "aim";
            default: return "unknown";
        }
    }

    @Override
    public android.os.IBinder onBind(Intent intent) {
        if (intent != null && SERVICE_INTERFACE.equals(intent.getAction())) {
            return super.onBind(intent);
        }
        return null;
    }

    @Override
    public void onDestroy() {
        instance = null;
        try {
            if (devReceiver != null) unregisterReceiver(devReceiver);
        } catch (Exception e) {}
        stop();
        super.onDestroy();
    }

    private void stop() {
        stopHeartbeat();
        devLogger.setEnabled(false);
        engine.stop();
    }
}
