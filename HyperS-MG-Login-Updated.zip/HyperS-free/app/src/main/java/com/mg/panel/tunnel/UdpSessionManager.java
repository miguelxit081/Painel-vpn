package com.mg.panel.tunnel;

import android.net.VpnService;
import android.os.Process;

import com.mg.panel.dev.DevLogger;
import com.mg.panel.filter.FilterDecision;
import com.mg.panel.filter.FilterEngine;
import com.mg.panel.filter.PacketContext;
import com.mg.panel.protocol.PacketIntegrity;
import com.mg.panel.filter.PacketSender;
import com.mg.panel.filter.TelePacket;
import com.mg.panel.decode.frame.Direction;
import com.mg.panel.protocol.PacketPipeline;
import com.mg.panel.decode.frame.UdpPacket;
import com.mg.panel.freeze.FreezeController;

import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;

public class UdpSessionManager implements PacketSender {

    private static final long IDLE = 0xafc8L;
    private static final int SO_TO = 0x7530;

    static final class SE {
        final DatagramSocket s;
        volatile long t;

        SE(DatagramSocket socket) {
            s = socket;
            t = System.currentTimeMillis();
        }

        void touch() {
            t = System.currentTimeMillis();
        }
    }

    private final VpnService vpnService;
    private final DevLogger logger;
    private final ExecutorService threadPool;
    private final ConcurrentHashMap<Long, SE> udpMap = new ConcurrentHashMap<>();

    private VpnEngine engine;
    private FilterEngine filterEngine;

    public UdpSessionManager(VpnService vpnService, DevLogger logger, ExecutorService pool) {
        this.vpnService = vpnService;
        this.logger = logger;
        this.threadPool = pool;
    }

    void setEngine(VpnEngine engine) {
        this.engine = engine;
    }

    void setFilterEngine(FilterEngine filterEngine) {
        this.filterEngine = filterEngine;
    }

    ExecutorService getThreadPool() {
        return threadPool;
    }

    @Override
    public boolean send(TelePacket tp) {
        PacketIntegrity.seal(tp.data);
        com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.TUNNEL_PKT_OUT);
        if (engine != null && engine.capture() != null) {
            engine.capture().recordOutbound(tp.data.length, tp.dip, tp.sp, tp.dp,
                    tp.type, com.mg.panel.dev.capture.CaptureEvent.PASS,
                    tp.data, 0);
        }
        long key = ((long) (tp.sp & 0xffff) << 48) | ((long) (tp.dp & 0xffff) << 32) | (tp.dip & 0xFFFFFFFFL);
        SE se = udpMap.get(key);
        if (se != null) {
            try {
                DatagramPacket p = new DatagramPacket(tp.data, 0, tp.data.length,
                        InetAddress.getByAddress(PacketBuilder.tb(tp.dip)), tp.dp);
                se.s.send(p);
                se.touch();
                return true;
            } catch (Exception e) {}
        }
        DatagramSocket fallback = null;
        try {
            fallback = new DatagramSocket();
            vpnService.protect(fallback);
            DatagramPacket p = new DatagramPacket(tp.data, 0, tp.data.length,
                    InetAddress.getByAddress(PacketBuilder.tb(tp.dip)), tp.dp);
            fallback.send(p);
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            if (fallback != null) {
                try { fallback.close(); } catch (Exception e) {}
            }
        }
    }

    void send(PacketContext ctx, FileOutputStream out) {
        long key = ((long) (ctx.sp & 0xffff) << 48) | ((long) (ctx.dp & 0xffff) << 32) | (ctx.dip & 0xFFFFFFFFL);
        SE se = getOrCreate(key, ctx.sp, ctx.dip, ctx.dp, out);
        if (se == null) return;
        try {
            int sendLen = ctx.outLength();
            if (sendLen <= 0 || ctx.off + sendLen > ctx.buf.length) sendLen = ctx.plen;
            DatagramPacket pkt = new DatagramPacket(ctx.buf, ctx.off, sendLen,
                    InetAddress.getByAddress(PacketBuilder.tb(ctx.dip)), ctx.dp);
            se.s.send(pkt);
            se.touch();
            engine.pSent.incrementAndGet();
            engine.bOut.addAndGet(sendLen);
        } catch (Exception e) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.TUNNEL_SEND_FAILED);
        }
    }

    private SE getOrCreate(long key, int sp, int dip, int dp, FileOutputStream out) {
        SE existing = udpMap.get(key);
        if (existing != null) return existing;
        try {
            DatagramSocket sock = new DatagramSocket();
            vpnService.protect(sock);
            try { sock.setSoTimeout(SO_TO); } catch (Exception e) {}
            SE se = new SE(sock);
            SE prev = udpMap.putIfAbsent(key, se);
            if (prev != null) {
                sock.close();
                return prev;
            }
            try {
                threadPool.execute(new RecvRunnable(se, sp, dip, dp, out, key));
            } catch (Throwable t) {
                udpMap.remove(key, se);
                try { sock.close(); } catch (Exception ignored) {}
                com.mg.panel.diag.Diag.event(
                        com.mg.panel.diag.Slot.TUNNEL_SESSION_NO_READER,
                        "recv thread rejected: " + t.getClass().getSimpleName());
                return null;
            }
            com.mg.panel.diag.Diag.hit(
                    com.mg.panel.diag.Slot.TUNNEL_SESSION_CREATED);
            return se;
        } catch (Exception e) {
            return null;
        }
    }

    private void observeForceSync(byte[] b, int off, int len) {
        if (filterEngine == null) return;
        com.mg.panel.esp.EspEngine esp = engine.esp();
        int own = esp == null ? -1 : esp.ownEntityId();
        if (own < 0) return;

        int p = off;
        int end = off + len;
        long[] v = new long[5];
        for (int i = 0; i < 5; i++) {
            long val = 0;
            int shift = 0;
            boolean ok = false;
            while (p < end && shift <= 63) {
                int c = b[p++] & 0xff;
                val |= ((long) (c & 0x7f)) << shift;
                if ((c & 0x80) == 0) { ok = true; break; }
                shift += 7;
            }
            if (!ok) return;
            v[i] = val;
        }
        if ((int) (v[0] & 0xFF) != own) return;
        filterEngine.onOwnForceSync(zigzag(v[2]), zigzag(v[3]), zigzag(v[4]));
    }

    private static long zigzag(long n) {
        return com.mg.panel.util.ZigZag.decode(n);
    }

    private class RecvRunnable implements Runnable {
        private final SE fe;
        private final int sip, dp, sp;
        private final FileOutputStream out;
        private final long key;

        RecvRunnable(SE fe, int origSip, int origDip, int origDp, FileOutputStream out, long key) {
            this.fe = fe;
            this.sip = origDip;
            this.dp = origDp;
            this.sp = origSip;
            this.out = out;
            this.key = key;
        }

        @Override
        public void run() {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
            byte[] rbuf = new byte[0x8000];
            while (engine.isRun && engine.isActive) {
                try {
                    DatagramPacket pkt = new DatagramPacket(rbuf, rbuf.length);
                    long t0 = System.nanoTime();
                    fe.s.receive(pkt);

                    engine.rtt = (engine.rtt * 3 + (System.nanoTime() - t0) / 1000000L) / 4;
                    int rlen = pkt.getLength();
                    engine.bIn.addAndGet(rlen);
                    com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.TUNNEL_PKT_IN);
                    fe.touch();

                    int cmd = PacketContext.CMD_UNRESOLVED;
                    PacketPipeline pipeline = engine.pipeline();
                    UdpPacket parsed = pipeline.observeAndParse(
                            pkt.getData(), pkt.getOffset(), rlen, Direction.INBOUND);
                    if (parsed != null) {
                        if (parsed.isCrcValid()) {
                            cmd = parsed.cmd();
                            FreezeController.observeCommand(cmd, null, true);
                            com.mg.panel.protocol.VisibilityMask.observe(parsed);
                            if (cmd == 144 || cmd == 1900 || cmd == 121 || cmd == 118
                                    || cmd == 101 || cmd == 107 || cmd == 139
                                    || cmd == 102) {
                                int bOff = parsed.payloadOffset();
                                int bLen = parsed.payloadLength();
                                byte[] body = parsed.buffer();
                                if (parsed.isEncrypted()) {
                                    int plain = com.mg.panel.decode.crypt.BodyCrypt
                                            .decrypt(body, bOff, bLen);
                                    if (plain > 0) {
                                        com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.PROTO_DECRYPT_OK);
                                        body = com.mg.panel.decode.crypt.BodyCrypt.plain();
                                        bOff = 0;
                                        bLen = plain;
                                    } else {
                                        if (com.mg.panel.decode.crypt.BodyCrypt.schedule() == null) {
                                            com.mg.panel.diag.Diag.hit(
                                                    com.mg.panel.diag.Slot.PROTO_NO_KEY);
                                        } else {
                                            com.mg.panel.diag.Diag.hit(
                                                    com.mg.panel.diag.Slot.PROTO_DECRYPT_FAILED);
                                        }
                                        bLen = 0;
                                    }
                                }
                                if (bLen > 0) {
                                    com.mg.panel.esp.EspEngine esp = engine.esp();
                                    switch (cmd) {
                                        case 144:  observeForceSync(body, bOff, bLen); break;
                                        case 1900: esp.observePriSync(body, bOff, bLen); break;
                                        case 121:  esp.observeEquipment(body, bOff, bLen); break;
                                        case 118:  esp.observeBindPri(body, bOff, bLen); break;
                                        case 101:  esp.roster().observeJoin(body, bOff, bLen); break;
                                        case 107:
                                        case 139:  esp.roster().observeKill(body, bOff, bLen); break;
                                        case 102:  esp.roster().observeQuit(body, bOff, bLen); break;
                                        case 125:  esp.observeMount(body, bOff, bLen, true); break;
                                        case 126:  esp.observeMount(body, bOff, bLen, false); break;
                                        case 2002: esp.observeVehicleList(body, bOff, bLen); break;
                                        default: break;
                                    }
                                }
                            }
                        }
                        com.mg.panel.protocol.SessionTimeline.observeUdp(parsed, false);
                    }

                    PacketContext ctx = new PacketContext(
                            pkt.getData(), rlen, 0, 17, sip, dp, sp, rlen, pkt.getOffset(),
                            TelePacket.TYPE_NONE, cmd);
                    if (parsed != null && parsed.isCrcValid()) {
                        ctx.setReliable(parsed.isReliable());
                    }
                    FilterDecision d = filterEngine.onInbound(ctx);
                    if (rlen >= 22 && rlen <= 26
                            && com.mg.panel.protocol.GamePacketTaxonomy.isHitConfirmation(
                                    pkt.getData(), pkt.getOffset(), rlen)) {
                        engine.telemetry().event(
                                com.mg.panel.dev.capture.TelemetryCollector.EV_HIT_CONFIRM,
                                com.mg.panel.protocol.GamePacketTaxonomy.hitDamage(
                                        pkt.getData(), pkt.getOffset(), rlen),
                                com.mg.panel.protocol.GamePacketTaxonomy.hitZone(
                                        pkt.getData(), pkt.getOffset(), rlen));
                    }
                    if (rlen >= 20 && rlen <= 1024) {
                        engine.esp().observeChainPacket(pkt.getData(), pkt.getOffset(), rlen);
                    }
                    if (rlen >= 20 && rlen <= 40) {
                        engine.esp().observeDamage(pkt.getData(), pkt.getOffset(), rlen);
                    }
                    if (rlen >= 14 && rlen <= 20) {
                        engine.esp().observeHandleEvent(pkt.getData(), pkt.getOffset(), rlen);
                    }
                    engine.capture().recordInbound(rlen, sip, dp, sp,
                            d == FilterDecision.DROP
                                    ? com.mg.panel.dev.capture.CaptureRecord.Decision.DROP
                                    : com.mg.panel.dev.capture.CaptureRecord.Decision.PASS,
                            pkt.getData(), pkt.getOffset());
                    if (d == FilterDecision.DROP) {
                        engine.pDrop.incrementAndGet();
                        continue;
                    }

                    byte[] ip = PacketBuilder.buildPkt(pkt, sip, dp, sp, engine.tunIP);
                    synchronized (out) {
                        out.write(ip);
                    }
                } catch (java.net.SocketTimeoutException e) {
                    if (!engine.isRun || !engine.isActive) break;
                    if (System.currentTimeMillis() - fe.t > IDLE) break;
                } catch (RuntimeException e) {
                    engine.pDrop.incrementAndGet();
                    com.mg.panel.diag.Diag.event(com.mg.panel.diag.Slot.TUNNEL_DECODE_THREW,
                            e.getClass().getSimpleName() + ": " + e.getMessage());
                } catch (Exception e) {
                    com.mg.panel.diag.Diag.hit(
                            com.mg.panel.diag.Slot.TUNNEL_SESSION_CLOSED_IO);
                    break;
                }
            }
            udpMap.remove(key, fe);
            try { fe.s.close(); } catch (Exception e) {}
        }
    }

    void closeAll() {
        for (SE se : udpMap.values()) {
            try { se.s.close(); } catch (Exception e) {}
        }
        udpMap.clear();
    }
}
