package com.mg.panel.esp;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.mg.panel.auth.ConfigStore;
import com.mg.panel.net.NativeBridge;
import com.mg.panel.net.NativeLoader;

public final class EspEngine {

    // ---- Session Mask ----
    private final int[] maskCounts = new int[6 * 256];
    private int maskSamples = 0;
    private volatile int k2, k3, k4, k5, k6, k7;
    private volatile boolean maskValid = false;
    private volatile boolean maskLocked = false;

    // ---- Own State ----
    private volatile double posX, posZ, posY;          
    private volatile float dirX, dirY, dirZ;           
    private volatile boolean airborne;                 
    private volatile int stateEnum;                    
    private volatile long tickMs;                      
    private volatile int rttMs = 0;

    private static final long OWN_STALE_MS = 400L;
    private volatile boolean mountedWire = false;
    private final Map<Integer, Integer> riderOfVehicle = new ConcurrentHashMap<>();
    private final Map<Integer, Integer> vehicleOfRider = new ConcurrentHashMap<>();

    public long ownAgeMs() {
        return ownLastUpdateMs > 0L ? System.currentTimeMillis() - ownLastUpdateMs : -1L;
    }

    public boolean mountedWire() { return mountedWire; }

    public boolean mounted() {
        if (mountedWire) return true;
        return ownLastUpdateMs > 0L && System.currentTimeMillis() - ownLastUpdateMs > OWN_STALE_MS;
    }

    public int riderOfVehicle(int vehicleId) {
        Integer s = riderOfVehicle.get(Integer.valueOf(vehicleId));
        return s == null ? 0 : s.intValue();
    }

    public void observeVehicleList(byte[] body, int off, int len) {
        if (NativeBridge.DECODE_LEASH && !ConfigStore.decodeArmed(System.currentTimeMillis() / 1000L)) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_LEASH_CLOSED);
            return;
        }
        if (body == null || off < 0 || len <= 0 || off + len > body.length) return;
        final int end = off + len;
        int[] p = new int[] { off };

        long hdr = vi(body, p, end);
        if (hdr <= 0 || (hdr & 1L) != 0L) return;      
        int count = (int) (hdr >> 1);
        if (count < 1 || count > 64) return;

        final long[] vx = new long[count];
        final long[] vy = new long[count];
        final long[] vz = new long[count];
        final int[] vid = new int[count];
        final boolean[] vocc = new boolean[count];

        for (int i = 0; i < count; i++) {
            long veh = vi(body, p, end);
            long x = zz(vi(body, p, end));
            long up = zz(vi(body, p, end));
            long z = zz(vi(body, p, end));
            long qx = zz(vi(body, p, end));
            long qy = zz(vi(body, p, end));
            long qz = zz(vi(body, p, end));
            long qw = zz(vi(body, p, end));
            if (p[0] >= end) return;
            int op = body[p[0]] & 0xFF;                
            p[0]++;
            vi(body, p, end);                          
            vi(body, p, end);                          
            vi(body, p, end);                          
            if (p[0] > end || veh <= 0) return;

            long norm = qx * qx + qy * qy + qz * qz + qw * qw;
            if (norm < 900000L || norm > 1100000L) return;

            vid[i] = (int) veh;
            vx[i] = x; vy[i] = up; vz[i] = z;
            vocc[i] = (op & 0x80) != 0;
        }

        if (vi(body, p, end) < 0) return;              
        if (vi(body, p, end) < 0) return;              
        if (p[0] != end) return;

        long now = System.currentTimeMillis();
        int applied = 0;
        for (int i = 0; i < count; i++) {
            int rider = riderOfVehicle(vid[i]);
            if (rider <= 0) continue;                  
            if (ownEntityId > 0 && rider == ownEntityId) continue;  
            Track t = entities.get(Integer.valueOf(rider));
            if (t == null) continue;                   

            updateTrack(rider, vx[i], vy[i], vz[i], now);
            t.inVehicle = true;
            t.vehicleId = vid[i];
            t.vehicleOccupied = vocc[i];
            applied++;
        }
        if (applied > 0) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_VEHICLE_LIST_APPLIED, applied);
        }
        com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_VEHICLE_LIST_PKT);
    }

    public void observeMount(byte[] body, int off, int len, boolean on) {
        if (body == null || off < 0 || len <= 0 || off + len > body.length) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_MOUNT_PARSE_BAD);
            return;
        }
        int end = off + len;
        int[] p = new int[] { off };
        long vehicleId = vi(body, p, end);
        long playerId = vi(body, p, end);
        if (p[0] > end || vehicleId <= 0 || playerId <= 0) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_MOUNT_PARSE_BAD);
            return;
        }

        int slot = (int) (playerId & 0xFFL);
        int team = (int) (playerId >>> 24);

        if (slot < 1 || slot > 127 || !isValidTeam(team)) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_MOUNT_PARSE_BAD);
            return;
        }

        noteTeam(slot, team, TEAM_SRC_HANDLE);

        int veh = (int) vehicleId;
        Integer slotKey = Integer.valueOf(slot);
        Integer vehKey = Integer.valueOf(veh);
        if (on) {
            riderOfVehicle.put(vehKey, slotKey);
            vehicleOfRider.put(slotKey, vehKey);
        } else {
            vehicleOfRider.remove(slotKey);
            Integer cur = riderOfVehicle.get(vehKey);
            if (cur != null && cur.intValue() == slot) riderOfVehicle.remove(vehKey);
        }

        if (ownEntityId > 0 && slot == ownEntityId) {
            mountedWire = on;
            com.mg.panel.diag.Diag.hit(on
                    ? com.mg.panel.diag.Slot.ESP_MOUNT_ON_SELF
                    : com.mg.panel.diag.Slot.ESP_MOUNT_OFF_SELF);
        } else {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_MOUNT_REMOTE);
        }
    }

    private void refreshOwnFromEcho(Track t, long now, boolean takePos, boolean takeDir) {
        if (t == null || !t.poseValid) return;
        if (takePos) {
            posX = t.x;
            posY = t.y;
            posZ = t.z;
            ownPosSrc = OWN_SRC_ECHO;
            ownStateMs = now;
        }
        if (takeDir) {
            double yaw = Math.toRadians(t.aimYawDeg);
            double pit = Math.toRadians(t.aimPitchDeg);
            double cp = Math.cos(pit);
            dirX = (float) (Math.sin(yaw) * cp);
            dirY = (float) Math.sin(pit);
            dirZ = (float) (Math.cos(yaw) * cp);
            dirSampleMs = now;
            camAngVelValid = false;
            ownDirSrc = OWN_SRC_ECHO;
        }
        if (!takePos && !takeDir) return;
        com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_OWN_FROM_ECHO);
    }

    public static final int OWN_SRC_NONE = 0;
    public static final int OWN_SRC_2001 = 1;
    public static final int OWN_SRC_2069 = 2;
    public static final int OWN_SRC_2002 = 3;
    public static final int OWN_SRC_ECHO = 4;
    public static final int OWN_SRC_2002Q = 5;

    public static volatile boolean MOUNT_VEHICLE_CAMERA = true;
    private static final long MOUNT_STALE_MS = 400L;

    private volatile int  ownPosSrc = OWN_SRC_NONE;
    private volatile int  ownDirSrc = OWN_SRC_NONE;
    private volatile long ownMs2069 = 0L;
    private volatile long ownMs2002 = 0L;

    private boolean mayWritePos(int src, long now) {
        if (src == OWN_SRC_2001) return true;
        if (now - ownLastUpdateMs <= OWN_STALE_MS) return false;
        if (src == OWN_SRC_2069) return true;
        if (now - ownMs2069 <= MOUNT_STALE_MS) return false;
        if (src == OWN_SRC_2002) return true;
        if (now - ownMs2002 <= MOUNT_STALE_MS) return false;
        return true;                       
    }

    private boolean mayWriteDir(int src, long now) {
        if (src == OWN_SRC_2001) return true;
        if (now - ownLastUpdateMs <= OWN_STALE_MS) return false;
        if (src == OWN_SRC_2069) return true;
        if (now - ownMs2069 <= MOUNT_STALE_MS) return false;
        if (src == OWN_SRC_2002 || src == OWN_SRC_2002Q) return true;
        if (now - ownMs2002q <= MOUNT_STALE_MS) return false;
        return true;                       
    }

    private volatile long ownMs2002q = 0L;

    public boolean ownPosChainFrame() { return ownPosSrc == OWN_SRC_ECHO; }

    private long ownLastUpdateMs = 0L;
    private volatile long ownStateMs = 0L;
    private volatile int ownSamples = 0;
    private volatile int keepaliveParseOk = 0;
    private volatile int keepaliveParseBad = 0;

    private volatile int ownTeam = 0;
    private volatile long ownTeamSeenMs = 0L;
    private volatile long lastMatchResetMs = 0L;

    private static final long TICK_MS = 198L;
    private static final double VEL_GAIN = 1.0;
    private static final long VEL_DT_MIN_MS = 185L;
    private static final long VEL_DT_MAX_MS = 260L;
    private static final double VEL_MAX_U_PER_MS = 13.0;
    private static final double VEL_TELEPORT_UNITS = 20000.0;
    private static final double SUB_TICK_MS = 99.0;

    private static final int OWN_HIST = 96;
    private final long[] histMs = new long[OWN_HIST];
    private final double[] histX = new double[OWN_HIST];
    private final double[] histY = new double[OWN_HIST];
    private volatile int histCount = 0;
    private volatile int histHead = 0;

    private volatile double lagMs = 0;
    private volatile int lagSamples = 0;

    private static final double LAG_MIN_MS = 40.0;
    private static final double LAG_MAX_MS = 900.0;
    private static final double LAG_MATCH_UNITS = 1.2 * EspEngine.UNITS_PER_METRE;
    private static final double LAG_MOVE_UNITS = 3.0 * EspEngine.UNITS_PER_METRE;
    private static final double LAG_ALPHA = 0.12;

    private void pushOwnHistory(long now) {
        histMs[histHead] = now;
        histX[histHead] = posX;
        histY[histHead] = posY;
        histHead = (histHead + 1) % OWN_HIST;
        if (histCount < OWN_HIST) histCount++;
    }

    private void measureLag(double ex, double ey, long now) {
        if (histCount < 8) return;

        double path = 0;
        int prev = -1;
        for (int k = 0; k < histCount; k++) {
            int i = (histHead - 1 - k + OWN_HIST * 2) % OWN_HIST;
            if (prev >= 0) {
                path += Math.hypot(histX[i] - histX[prev], histY[i] - histY[prev]);
            }
            prev = i;
        }
        if (path < LAG_MOVE_UNITS) return;

        int best = -1;
        double bestD = Double.MAX_VALUE;
        for (int k = 0; k < histCount; k++) {
            int i = (histHead - 1 - k + OWN_HIST * 2) % OWN_HIST;
            double age = now - histMs[i];
            if (age < LAG_MIN_MS || age > LAG_MAX_MS) continue;
            double d = Math.hypot(histX[i] - ex, histY[i] - ey);
            if (d < bestD) { bestD = d; best = i; }
        }
        if (best < 0 || bestD > LAG_MATCH_UNITS) return;

        double sample = now - histMs[best];
        if (sample < LAG_MIN_MS || sample > LAG_MAX_MS) return;
        if (lagSamples == 0) lagMs = sample;
        else lagMs += (sample - lagMs) * LAG_ALPHA;
        lagSamples++;
    }

    public double measuredLagMs() {
        if (lagSamples >= 12) return lagMs;
        return (rttMs >= 5) ? rttMs : 0;
    }

    public boolean lagFromEcho() { return lagSamples >= 12; }

    public static final int MAX_HP = 200;

    public static final int ROLE_UNKNOWN = 0;
    public static final int TEAM_SRC_NONE   = 0;
    public static final int TEAM_SRC_HANDLE = 1;
    public static final int TEAM_SRC_DAMAGE = 2;
    public static final int TEAM_SRC_ROSTER = 3;
    public static final int TEAM_SRC_BIND   = 4;

    private static boolean isValidTeam(int b) {
        return b >= 1 && b <= 254;
    }

    public static final int ROLE_SELF = 1;
    public static final int ROLE_TEAM = 2;
    public static final int ROLE_ENEMY = 3;

    public static final double UNITS_PER_METRE = 1000.0;
    private final Map<Integer, Track> entities = new ConcurrentHashMap<>();
    private volatile String calibReadout = "ESP: waiting for mask...";

    public EspEngine() { }

    private static long readVarint(byte[] data, int i, int end) {
        long v = 0; int sh = 0;
        while (i < end) {
            int c = data[i++] & 0xff;
            v |= (long) (c & 0x7f) << sh;
            if ((c & 0x80) == 0) return v;
            sh += 7;
            if (sh > 63) return -1;
        }
        return -1;
    }

    private static int skipVarints(byte[] data, int i, int end, int count) {
        for (int k = 0; k < count; k++) {
            boolean done = false;
            while (i < end) {
                int c = data[i++] & 0xff;
                if ((c & 0x80) == 0) { done = true; break; }
            }
            if (!done) return -1;
        }
        return i;
    }

    private static long[] varints(byte[] data, int off, int end) {
        long[] tmp = new long[32];
        int n = 0;
        int i = off;
        while (i < end) {
            long v = 0;
            int s = 0;
            boolean done = false;
            while (i < end) {
                int c = data[i++] & 0xff;
                v |= (long) (c & 0x7f) << s;
                s += 7;
                if ((c & 0x80) == 0) { done = true; break; }
                if (s > 63) return null;   
            }
            if (!done) return null;
            if (n == tmp.length) {
                long[] t = new long[tmp.length * 2];
                System.arraycopy(tmp, 0, t, 0, n);
                tmp = t;
            }
            tmp[n++] = v;
        }
        long[] out = new long[n];
        System.arraycopy(tmp, 0, out, 0, n);
        return out;
    }

    private static long zz(long v) {
        return com.mg.panel.util.ZigZag.decode(v);
    }

    private static float f32(long u) {
        return Float.intBitsToFloat((int) (u & 0xffffffffL));
    }

    public void observeInputStream(byte[] data, int off) {
        if (maskLocked) return;
        if (off < 0 || off + 24 > data.length) return;
        for (int i = 0; i < 6; i++) {
            int b = data[off + 2 + i] & 0xff;
            maskCounts[i * 256 + b]++;
        }
        maskSamples++;
        if (maskSamples >= 96) {
            evaluateMask();
        }
    }

    private void evaluateMask() {
        int[] k = new int[6];
        boolean strong = true;
        for (int i = 0; i < 6; i++) {
            int best = 0, bestCount = 0, total = 0;
            for (int v = 0; v < 256; v++) {
                int c = maskCounts[i * 256 + v];
                total += c;
                if (c > bestCount) { bestCount = c; best = v; }
            }
            k[i] = best;
            if (total == 0 || bestCount * 100 < total * 90) strong = false;
        }
        if (strong) {
            k2 = k[0]; k3 = k[1]; k4 = k[2]; k5 = k[3]; k6 = k[4]; k7 = k[5];
            maskValid = true;
            if (maskSamples >= 288) {
                maskLocked = true;
            }
        }
    }
    public void observeKeepalive(byte[] data, int off, int plen) {
        if (NativeBridge.DECODE_LEASH && !ConfigStore.decodeArmed(System.currentTimeMillis() / 1000L)) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_LEASH_CLOSED);
            return;
        }
        final boolean kaSrv = NativeBridge.DECODE_LEASH && ConfigStore.keepaliveMapArmed();
        final int vPosX = kaSrv ? ConfigStore.kaPosX() : 0;
        final int vPosZ = kaSrv ? ConfigStore.kaPosZ() : 1;
        final int vPosY = kaSrv ? ConfigStore.kaPosY() : 2;
        final int vAir  = kaSrv ? ConfigStore.kaAirborne() : 11;
        final int vPose = kaSrv ? ConfigStore.kaPose() : 12;
        final int vCamX = kaSrv ? ConfigStore.kaCamX() : 13;
        final int vCamY = kaSrv ? ConfigStore.kaCamY() : 14;
        final int vCamZ = kaSrv ? ConfigStore.kaCamZ() : 15;
        final int vRtt  = kaSrv ? ConfigStore.kaRtt() : 18;
        final int vTick = kaSrv ? ConfigStore.kaTick() : 22;
        final int nBody = kaSrv ? ConfigStore.kaBodyVarints() : 23;

        if (plen < 32 || off < 0 || off + plen > data.length) return;
        int end = off + plen;

        int bodyStart = skipVarints(data, off + 8, end, 1);
        if (bodyStart < 0) {
            keepaliveParseBad++;
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_KEEPALIVE_BAD);
            return;
        }
        long[] v = varints(data, bodyStart, end);
        if (v == null || v.length != nBody) {
            keepaliveParseBad++;
            return;
        }
        keepaliveParseOk++;

        long handle = readVarint(data, off + 8, end);
        int oid = (int) (handle & 0xFFFFFFL);
        if (oid >= 1 && oid <= 127) ownEntityId = oid;
        int otm = (int) (handle >>> 24);
        long now = System.currentTimeMillis();

        if (isValidTeam(otm)) {
            ownTeam = otm;
            ownTeamSeenMs = now;
        }
        posX = (double) zz(v[vPosX]);
        posZ = (double) zz(v[vPosZ]);
        posY = (double) zz(v[vPosY]);
        airborne = v[vAir] != 0;
        stateEnum = (int) v[vPose];

        float ndx = f32(v[vCamX]), ndy = f32(v[vCamY]), ndz = f32(v[vCamZ]);
        computeCameraAngVel(dirX, dirY, dirZ, dirSampleMs, ndx, ndy, ndz, now);
        dirX = ndx;
        dirY = ndy;
        dirZ = ndz;
        dirSampleMs = now;
        tickMs = v[vTick];

        long r = v[vRtt];
        if (r >= 5 && r <= 2000) rttMs = (int) r;

        pushOwnHistory(now);
        ownLastUpdateMs = now;
        ownStateMs = now;
        ownPosSrc = OWN_SRC_2001;
        ownDirSrc = OWN_SRC_2001;

        if (mountedWire) {
            mountedWire = false;
        }
        com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_OWN_FROM_2001);
        ownSamples++;
        if (ownSamples % 10 == 0) updateCalibReadout();
    }

    private static final int MAX_ENTITY_ID = 64;
    private static final int MAX_CHAIN_RECORDS = 64;
    private static final int CHAIN_HEADER = 10;
    private static final int MIN_RECORD_BYTES = 16;
    private static final long MIN_RECORD_X = 500L;
    private static final int CHAIN_MAX_LEN = 1400;

    private ByteBuffer shadowIn;
    private ByteBuffer shadowOut;
    private final int[] sjId = new int[MAX_CHAIN_RECORDS];
    private final long[] sjX = new long[MAX_CHAIN_RECORDS];
    private final long[] sjZ = new long[MAX_CHAIN_RECORDS];
    private final long[] sjY = new long[MAX_CHAIN_RECORDS];
    private final int[] sjBy = new int[MAX_CHAIN_RECORDS];
    private final int[] sjAy = new int[MAX_CHAIN_RECORDS];
    private final int[] sjAp = new int[MAX_CHAIN_RECORDS];
    private final boolean[] sjSelf = new boolean[MAX_CHAIN_RECORDS];
    private int sjCount = -1;

    public void observeChainPacket(byte[] data, int off, int plen) {
        if (NativeBridge.DECODE_LEASH && !ConfigStore.decodeArmed(System.currentTimeMillis() / 1000L)) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_LEASH_CLOSED);
            return;
        }
        final boolean chSrv = NativeBridge.DECODE_LEASH && ConfigStore.chainMaxEntityId() > 0;
        final long chMinRecordX = chSrv ? ConfigStore.chainMinRecordX() : MIN_RECORD_X;
        final int chMaxEntityId = chSrv ? (int) ConfigStore.chainMaxEntityId() : MAX_ENTITY_ID;
        final int chMinRecBytes = chSrv ? ConfigStore.chainMinRecordBytes() : MIN_RECORD_BYTES;
        final int chMaxRecords = chSrv ? ConfigStore.chainMaxRecords() : MAX_CHAIN_RECORDS;
        final int chMaxLen = chSrv ? ConfigStore.chainMaxLen() : CHAIN_MAX_LEN;

        if (plen < 20 || plen > chMaxLen) return;
        if (off < 0 || off + plen > data.length) return;
        if ((data[off + 8] & 0xff) != 0x00) return;
        int b9 = data[off + 9] & 0xff;
        if ((b9 & 1) != 0) return;
        int declared = b9 / 2;
        if (declared < 1 || declared > chMaxRecords) return;
        if (plen < CHAIN_HEADER + declared * chMinRecBytes) return;

        int recStart = skipVarints(data, off + 8, off + plen, 2);
        if (recStart < 0) return;
        long now = System.currentTimeMillis();

        final long ownHandleNow = (isValidTeam(ownTeam) && ownEntityId > 0)
                ? (((long) ownTeam << 24) | (ownEntityId & 0xFFFFFFL))
                : 0L;
        boolean newByHandle = (matchHandle != 0 && ownHandleNow != 0 && ownHandleNow != matchHandle);
        boolean newBySilence = (lastChainMs != 0 && now - lastChainMs > MATCH_GAP_MS);

        if (newByHandle || newBySilence) {
            resetMatch(now);
        }
        if (firstChainMs == 0) firstChainMs = now;
        if (ownHandleNow != 0) matchHandle = ownHandleNow;
        lastChainMs = now;

        com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_CHAIN_PKT);
        if (parseStructured(data, recStart, off + plen, declared, now, chMinRecordX, chMaxEntityId)) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_CHAIN_PARSE_STRUCTURED);
            if (NativeBridge.NATIVE_SHADOW) {
                shadowCompareChain(data, off, plen, now);
            }
            return;
        }
        com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_CHAIN_PARSE_FALLBACK);

        long[] v = varints(data, recStart, off + plen);
        if (v == null || v.length < 4) return;

        int idMax = 0, zmin = 0;
        outer:
        for (int c = 0; c < ID_CEILINGS.length; c++) {
            for (int zi = 0; zi < Z_FLOORS.length; zi++) {
                if (countStarts(v, Z_FLOORS[zi], ID_CEILINGS[c], chMinRecordX) == declared) {
                    idMax = ID_CEILINGS[c];
                    zmin = Z_FLOORS[zi];
                    break outer;
                }
            }
        }
        if (idMax == 0) {
            idMax = ID_CEILINGS[ID_CEILINGS.length - 1];
            zmin = Z_FLOORS[0];
        }

        int found = 0;
        for (int i = 0; i + 3 < v.length; i++) {
            if (v[i] < 1 || v[i] > idMax) continue;
            if (v[i + 1] < chMinRecordX) continue;
            if (v[i + 2] < zmin) continue;

            updateTrack((int) v[i], zz(v[i + 1]), zz(v[i + 2]), zz(v[i + 3]), now);

            if (ownEntityId > 0 && (int) v[i] == ownEntityId) {
                measureLag(zz(v[i + 1]), zz(v[i + 3]), now);
            }

            if (i + 6 < v.length) {
                Track seeded = entities.get((int) v[i]);
                if (seeded != null && !seeded.velValid) {
                    seedVelocity(seeded, v[i + 4], v[i + 5], v[i + 6]);
                }
            }
            if (++found >= declared) break;
        }
    }

    private void shadowCompareChain(byte[] data, int off, int plen, long now) {
        if (!NativeLoader.isReady() || sjCount < 0) { sjCount = -1; return; }
        long nowSec = now / 1000L;
        if (!ConfigStore.decodeArmed(nowSec)) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_CHAIN_NATIVE_UNARMED);
            sjCount = -1;
            return;
        }
        if (shadowIn == null) {
            shadowIn = ByteBuffer.allocateDirect(CHAIN_MAX_LEN);
            shadowOut = ByteBuffer
                    .allocateDirect(2 + MAX_CHAIN_RECORDS * NativeBridge.CHAIN_RECORD_WIRE)
                    .order(ByteOrder.LITTLE_ENDIAN);
        }
        if (plen > shadowIn.capacity()) { sjCount = -1; return; }
        shadowIn.clear();
        shadowIn.put(data, off, plen);
        int n = NativeBridge.chainDecode(
                shadowIn, 0, plen, ownEntityId,
                ConfigStore.chainMaxLen(), ConfigStore.chainMaxRecords(),
                ConfigStore.chainMinRecordBytes(), ConfigStore.chainMinRecordX(),
                ConfigStore.chainMaxEntityId(), ConfigStore.decodeValidUntil(), nowSec,
                shadowOut);
        int slot;
        if (n < 0) {
            slot = com.mg.panel.diag.Slot.ESP_CHAIN_NATIVE_REFUSED;
        } else if (compareShadow(n)) {
            slot = com.mg.panel.diag.Slot.ESP_CHAIN_NATIVE_MATCH;
        } else {
            slot = com.mg.panel.diag.Slot.ESP_CHAIN_NATIVE_DIVERGE;
        }
        com.mg.panel.diag.Diag.hit(slot);
        sjCount = -1;
    }

    private boolean compareShadow(int n) {
        if (n != sjCount) return false;
        final int w = NativeBridge.CHAIN_RECORD_WIRE;
        if ((shadowOut.getShort(0) & 0xFFFF) != sjCount) return false;
        for (int r = 0; r < n; r++) {
            int base = 2 + r * w;
            int id = shadowOut.getInt(base);
            long x = shadowOut.getLong(base + 4);
            long z = shadowOut.getLong(base + 12);
            long y = shadowOut.getLong(base + 20);
            int by = shadowOut.get(base + 52) & 0xFF;
            int ay = shadowOut.get(base + 53) & 0xFF;
            int ap = shadowOut.get(base + 54);          
            boolean self = shadowOut.get(base + 55) != 0;
            if (id != sjId[r] || x != sjX[r] || z != sjZ[r] || y != sjY[r]) return false;
            if (self != sjSelf[r]) return false;
            if (!self && (by != sjBy[r] || ay != sjAy[r] || ap != sjAp[r])) return false;
        }
        return true;
    }

    private static long vi(byte[] d, int[] pos, int end) {
        long v = 0; int sh = 0; int i = pos[0];
        while (i < end) {
            int c = d[i++] & 0xff;
            v |= (long) (c & 0x7f) << sh;
            if ((c & 0x80) == 0) { pos[0] = i; return v; }
            sh += 7;
            if (sh > 63) break;
        }
        pos[0] = end;
        return -1;
    }

    private boolean parseStructured(byte[] d, int start, int end, int declared, long now,
                                    long minRecordX, int maxEntityId) {
        int[] pos = { start };
        int[] ids = new int[declared];
        long[] xs = new long[declared], zs = new long[declared], ys = new long[declared];
        long[] vxs = new long[declared], vzs = new long[declared], vys = new long[declared];
        int[] by = new int[declared], ay = new int[declared], ap = new int[declared];
        int[] md = new int[declared], st = new int[declared];
        boolean[] full = new boolean[declared];
        boolean mdstHigh = false;

        for (int r = 0; r < declared; r++) {
            long id = vi(d, pos, end);
            if (id < 1 || id > maxEntityId) return false;
            long x = vi(d, pos, end);
            long z = vi(d, pos, end);
            long y = vi(d, pos, end);
            if (x < minRecordX) return false;
            ids[r] = (int) id; xs[r] = x; zs[r] = z; ys[r] = y;

            if (ownEntityId > 0 && id == ownEntityId) {
                full[r] = true;
                for (int k = 4; k < 20; k++) {
                    if (vi(d, pos, end) < 0 && pos[0] >= end) return false;
                }
                continue;
            }
            vxs[r] = vi(d, pos, end);
            vzs[r] = vi(d, pos, end);
            vys[r] = vi(d, pos, end);
            if (pos[0] + 3 > end) return false;
            by[r] = d[pos[0]] & 0xff;
            ay[r] = d[pos[0] + 1] & 0xff;
            ap[r] = d[pos[0] + 2];          
            pos[0] += 3;

            md[r] = (int) vi(d, pos, end);
            st[r] = (int) vi(d, pos, end);
            if (md[r] >= 0x80 || st[r] >= 0x80) mdstHigh = true;
            vi(d, pos, end);                 
            vi(d, pos, end);                 
            if (pos[0] > end) return false;
        }

        int left = end - pos[0];
        if (left < 1 || left > 3) return false;

        if (NativeBridge.NATIVE_SHADOW) {
            for (int r = 0; r < declared; r++) {
                sjId[r] = ids[r];
                sjX[r] = xs[r]; sjZ[r] = zs[r]; sjY[r] = ys[r];
                sjBy[r] = by[r]; sjAy[r] = ay[r]; sjAp[r] = ap[r];
                sjSelf[r] = full[r];
            }
            sjCount = declared;
        }

        if (mdstHigh) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_CHAIN_MDST_HIGH);
        }

        for (int r = 0; r < declared; r++) {
            updateTrack(ids[r], zz(xs[r]), zz(zs[r]), zz(ys[r]), now);
            Track t = entities.get(ids[r]);
            if (t == null) continue;

            t.bodyYawDeg = by[r] * YAW_DEG_PER_LSB;
            t.aimYawDeg = ay[r] * YAW_DEG_PER_LSB;
            t.aimPitchDeg = ap[r] * PITCH_DEG_PER_LSB;
            t.mode = md[r];
            t.state = st[r];
            t.poseValid = true;

            if (ownEntityId > 0 && ids[r] == ownEntityId) {
                measureLag(zz(xs[r]), zz(ys[r]), now);
                continue;
            }
            if (!t.velValid) seedVelocity(t, vxs[r], vzs[r], vys[r]);
        }
        return true;
    }

    private static final int[] ID_CEILINGS = { 8, 16, 32, 64 };
    private static final int[] Z_FLOORS = { 500, 0 };

    private static int countStarts(long[] v, int zmin, int idMax, long minRecordX) {
        int n = 0;
        for (int i = 0; i + 3 < v.length; i++) {
            if (v[i] >= 1 && v[i] <= idMax
                    && v[i + 1] >= minRecordX && v[i + 2] >= zmin) n++;
        }
        return n;
    }

    private void updateTrack(int id, long x, long z, long y, long now) {
        if (com.mg.panel.protocol.VisibilityMask.hasMask()
                && !com.mg.panel.protocol.VisibilityMask.isVisible(id)) {
            com.mg.panel.protocol.VisibilityMask.noteStreamedWhileHidden();
        }
        Track t = entities.get(id);
        if (t == null) {
            t = new Track();
            t.x = x; t.z = z; t.y = y;
            t.pendingX = x; t.pendingZ = z; t.pendingY = y;
            t.firstSeenMs = now;
            t.lastMoveMs = now;
            entities.put(id, t);
        } else if (t.pendingTeleport) {
            if (Math.abs(x - t.pendingX) + Math.abs(z - t.pendingZ) < 50000) {
                t.x = t.pendingX; t.z = t.pendingZ; t.y = t.pendingY;
                t.lastMoveMs = now;
            }
            t.pendingTeleport = false;
            double d = Math.abs(x - t.x) + Math.abs(z - t.z);
            if (d <= 50000) {
                if (d > 50) t.lastMoveMs = now;
                t.x = x; t.z = z; t.y = y;
            } else {
                t.pendingTeleport = true;
                t.pendingX = x; t.pendingZ = z; t.pendingY = y;
            }
        } else {
            double d = Math.abs(x - t.x) + Math.abs(z - t.z);
            if (d <= 50000) {
                if (d > 50) t.lastMoveMs = now;
                t.x = x; t.z = z; t.y = y;
            } else {
                t.pendingTeleport = true;
                t.pendingX = x; t.pendingZ = z; t.pendingY = y;
            }
        }
        if (t.dead && now - t.deathMs > 1200L) t.dead = false;
        updateVelocity(t, now);
        t.updateMs = now;
        t.updates++;
        classify(id, t);

        if (t.role == ROLE_ENEMY && !t.dead) {
            double dx = t.x - posX;
            double dy = t.y - posY;
            double dz = t.z - posZ;
            float distMetres = (float) (Math.sqrt(dx * dx + dy * dy + dz * dz) / UNITS_PER_METRE);
            MarkTarget.set(id, t.x, t.z, t.y, distMetres);
        }

        if (t.role == ROLE_SELF && mounted()) {
            refreshOwnFromEcho(t, now,
                    mayWritePos(OWN_SRC_ECHO, now),
                    mayWriteDir(OWN_SRC_ECHO, now));
        }
    }

    private void updateVelocity(Track t, long now) {
        long dt = now - t.prevMs;
        if (t.prevMs != 0L && dt >= VEL_DT_MIN_MS && dt <= VEL_DT_MAX_MS) {
            double dx = t.x - t.prevX;
            double dy = t.y - t.prevY;
            double dz = t.z - t.prevZ;
            if (Math.abs(dx) > VEL_TELEPORT_UNITS || Math.abs(dy) > VEL_TELEPORT_UNITS
                    || Math.abs(dz) > VEL_TELEPORT_UNITS) {
                t.vx = 0; t.vy = 0; t.vz = 0;
                t.velValid = false;
            } else {
                double nvx = dx / dt * VEL_GAIN;
                double nvy = dy / dt * VEL_GAIN;
                double nvz = dz / dt * VEL_GAIN;
                if (Math.sqrt(nvx * nvx + nvy * nvy) <= VEL_MAX_U_PER_MS) {
                    t.vx = nvx; t.vy = nvy; t.vz = nvz;
                    t.velValid = true;
                }
            }
        } else if (t.prevMs != 0L && dt > VEL_DT_MAX_MS) {
            t.velValid = false;
        }
        t.prevX = t.x; t.prevY = t.y; t.prevZ = t.z;
        t.prevMs = now;
    }

    private static void seedVelocity(Track t, long rawVx, long rawVz, long rawVy) {
        if (t.velValid) return;            
        double vx = zz(rawVx) / SUB_TICK_MS;
        double vz = zz(rawVz) / SUB_TICK_MS;
        double vy = zz(rawVy) / SUB_TICK_MS;
        if (Math.sqrt(vx * vx + vy * vy) > VEL_MAX_U_PER_MS) return;
        t.vx = vx; t.vy = vy; t.vz = vz;
        t.velValid = true;
    }

    private void classify(int id, Track t) {
        final boolean ownTeamUsable = isValidTeam(ownTeam) && ownTeamSeenMs >= lastMatchResetMs;

        if (ownEntityId > 0 && t == entities.get(ownEntityId)) {
            t.role = ROLE_SELF;
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_CLS_R1_SELF);
            return;
        }

        if (t.teamSrc < TEAM_SRC_BIND) {
            int s = pri.squadFor(id);
            if (isValidTeam(s)) {
                noteTeam(id, s, TEAM_SRC_BIND);
            } else if (t.teamSrc < TEAM_SRC_ROSTER) {
                s = roster.squad(id);
                if (isValidTeam(s)) noteTeam(id, s, TEAM_SRC_ROSTER);
            }
        }

        if (ownTeamUsable && isValidTeam(t.team)) {
            t.teamKnown = true;
            t.role = (t.team == ownTeam) ? ROLE_TEAM : ROLE_ENEMY;
            com.mg.panel.diag.Diag.hit(t.role == ROLE_TEAM ? com.mg.panel.diag.Slot.ESP_CLS_R2_TEAM : com.mg.panel.diag.Slot.ESP_CLS_R2_ENEMY);
            return;
        }
        if (!ownTeamUsable) com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_CLS_R2_NO_OWN_TEAM);

        if (ownEntityId <= 0) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_CLS_NO_OWN_ID);
            return;
        }

        if (ownSquadKnown() >= MAX_SQUAD) {
            t.role = ROLE_ENEMY;
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_CLS_R3_CLOSURE_ENEMY);
            return;
        }

        if (firstChainMs != 0 && t.firstSeenMs != 0
                && t.firstSeenMs - firstChainMs > LATE_ARRIVAL_MS) {
            t.role = ROLE_ENEMY;
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_CLS_R4_LATE_ENEMY);
            return;
        }

        t.role = ROLE_ENEMY;
        com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_CLS_R6_DEFAULT_ENEMY);
    }

    private static final float YAW_DEG_PER_LSB = 360.0f / 256.0f;
    public static volatile float PITCH_DEG_PER_LSB = 1.29f;
    private static final int MAX_SQUAD = 4;
    private static final long LATE_ARRIVAL_MS = 20000L;
    private static final long MATCH_GAP_MS = 30000L;

    private volatile long firstChainMs = 0L;
    private volatile long lastChainMs = 0L;
    private volatile long matchHandle = 0L;

    public void observeHandleEvent(byte[] data, int off, int plen) {
        if (plen < 14 || plen > 20) return;
        if (off < 0 || off + plen > data.length) return;
        int h0 = data[off + 8] & 0xff;
        if (h0 < 0x80) return;
        if ((data[off + 9] & 0xff) != 0x80 || (data[off + 10] & 0xff) != 0x80) return;
        int tt = data[off + 11] & 0xff;
        if (tt == 0 || (tt & 0x07) != 0) return;
        long[] v = varints(data, off + 8, off + plen);
        if (v == null || v.length < 1 || v.length > 4) return;
        int id = (int) (v[0] & 0xFFFFFF);
        int team = (int) (v[0] >>> 24);
        if (id < 1 || id > 127 || team < 1) return;
        noteTeam(id, team, TEAM_SRC_HANDLE);
    }

    private long spDamageTotal;
    private long spDamageEvents;

    public void observeDamage(byte[] data, int off, int plen) {
        if (plen < 20 || plen > 40) return;
        if (off < 0 || off + 12 > data.length || off + plen > data.length) return;
        int h0 = data[off + 8] & 0xff;
        if (h0 < 0x80) return;
        if ((data[off + 9] & 0xff) != 0x80 || (data[off + 10] & 0xff) != 0x80) return;
        int tt = data[off + 11] & 0xff;
        if (tt == 0 || (tt & 0x07) != 0) return;
        long[] v = varints(data, off + 8, off + plen);
        if (v == null || v.length != 8) return;

        int victim = (int) (v[0] & 0xFFFFFF), vTeam = (int) (v[0] >>> 24);
        int attacker = (int) (v[1] & 0xFFFFFF), aTeam = (int) (v[1] >>> 24);
        int damage = (int) v[5];
        int spDamage = (int) v[4];
        if (spDamage < 0 || spDamage > MAX_HP) spDamage = 0;
        if (victim < 1 || victim > 127 || attacker < 1 || attacker > 127) return;

        if (damage <= 0 || damage > MAX_HP) {
            if (spDamage > 0 && damage == 0) {
                noteTeam(victim, vTeam, TEAM_SRC_DAMAGE);
                noteTeam(attacker, aTeam, TEAM_SRC_DAMAGE);
                spDamageEvents++;
                spDamageTotal += spDamage;
            }
            return;
        }
        spDamageTotal += spDamage;
        if (spDamage > 0) spDamageEvents++;

        noteTeam(victim, vTeam, TEAM_SRC_DAMAGE);
        noteTeam(attacker, aTeam, TEAM_SRC_DAMAGE);
        damageEvents++;

        Track t = entities.get(victim);
        if (t == null) { t = new Track(); entities.put(victim, t); }
        long now = System.currentTimeMillis();
        pri.onDamage(victim, damage, now);

        t.hp -= damage;
        if (t.hp <= 0) {
            t.hp = MAX_HP;          
            t.dead = true;
            t.deathMs = now;
            kills++;
        }
        t.lastDamageMs = now;
    }

    private void noteTeam(int id, int team, int src) {
        if (id < 1 || id > 127) return;
        if (!isValidTeam(team)) return;
        Track t = entities.get(id);
        if (t == null) { t = new Track(); entities.put(id, t); }
        if (src < t.teamSrc) return;
        t.team = team;
        t.teamSrc = src;
        switch (src) {
            case TEAM_SRC_BIND:   com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_TEAM_SRC_BIND); break;
            case TEAM_SRC_ROSTER: com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_TEAM_SRC_ROSTER); break;
            case TEAM_SRC_DAMAGE: com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_TEAM_SRC_DAMAGE); break;
            case TEAM_SRC_HANDLE: com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_TEAM_SRC_HANDLE); break;
            default: break;
        }
        if (!isValidTeam(ownTeam)) return;   
        t.teamKnown = true;
        t.role = (id == ownEntityId) ? ROLE_SELF
                : (team == ownTeam ? ROLE_TEAM : ROLE_ENEMY);
    }

    private void resetMatch(long now) {
        com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_MATCH_RESET);
        entities.clear();
        ownTeam = 0;
        ownTeamSeenMs = 0L;
        ownEntityId = -1;
        matchHandle = 0L;
        lastMatchResetMs = now;
        mountedWire = false;
        riderOfVehicle.clear();
        vehicleOfRider.clear();
        ownPosSrc = OWN_SRC_NONE;
        ownDirSrc = OWN_SRC_NONE;
        ownMs2069 = 0L;
        ownMs2002 = 0L;
        ownMs2002q = 0L;
        pri.reset();
        roster.reset();
        firstChainMs = now;
        lastChainMs = now;
        ownSamples = 0;
        lagSamples = 0;
        lagMs = 0;
        histCount = 0;
        histHead = 0;
        MarkTarget.clear();
    }
    public String teamLine() {
        int known = 0, b = 0, r = 0, d = 0, h = 0, unk = 0;
        for (Track t : entities.values()) {
            if (isValidTeam(t.team)) {
                known++;
                switch (t.teamSrc) {
                    case TEAM_SRC_BIND:   b++; break;
                    case TEAM_SRC_ROSTER: r++; break;
                    case TEAM_SRC_DAMAGE: d++; break;
                    case TEAM_SRC_HANDLE: h++; break;
                    default: break;
                }
            } else {
                unk++;
            }
        }
        long age = (lastMatchResetMs == 0L) ? 0L
                : (System.currentTimeMillis() - lastMatchResetMs) / 1000L;
        return String.format(
                "TEAM own=%d known=%d/%d src=118:%d/101:%d/dmg:%d/hnd:%d unk=%d reset=+%ds",
                ownTeam, known, entities.size(), b, r, d, h, unk, age);
    }

    private int ownSquadKnown() {
        int n = 0;
        for (Track t : entities.values()) {
            if (t.team == ownTeam && t.team > 0) n++;
        }
        return n;
    }

    private volatile int ownEntityId = -1;

    public int ownEntityId() {
        return ownEntityId;
    }
    private volatile int damageEvents = 0;
    private volatile int kills = 0;

    private final PriTracker pri = new PriTracker();

    public PriTracker pri() { return pri; }

    private static final int PRI_BATCH = 256;

    public void observePriSync(byte[] body, int off, int len) {
        final long now = System.currentTimeMillis();
        final int[] n = { 0 };
        final long[] owners = new long[PRI_BATCH];
        final int[] varIds = new int[PRI_BATCH];
        final long[] values = new long[PRI_BATCH];
        boolean ok = com.mg.panel.decode.body.PriSync.decode(body, off, len, true,
                new com.mg.panel.decode.body.PriSync.Sink() {
                    @Override
                    public void onProperty(long owner, int varId, long value) {
                        if (n[0] >= PRI_BATCH) return;   
                        owners[n[0]] = owner;
                        varIds[n[0]] = varId;
                        values[n[0]] = value;
                        n[0]++;
                    }
                });
        if (!ok) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_PRI_DECODE_REFUSED);
            return;                                   
        }
        for (int i = 0; i < n[0]; i++) {
            pri.onProperty(owners[i], varIds[i], values[i], now);
        }
    }

    private static final int EQUIP_SCAN = 10;

    public void observeEquipment(byte[] body, int off, int len) {
        if (body == null || off < 0 || len < 4 || off + len > body.length) return;
        com.mg.panel.decode.body.WireReader r =
                new com.mg.panel.decode.body.WireReader(body, off, len);
        long handleRaw = r.u();
        if (r.bad) return;
        int handle = (int) (handleRaw & 0xFFFFFFL);
        long[] vals = new long[EQUIP_SCAN];
        int n = 0;
        while (n < EQUIP_SCAN && r.hasMore()) {
            long v = r.u();
            if (r.bad) break;
            vals[n++] = v;
        }
        if (n > 0) pri.onEquipment(handle, vals, n, System.currentTimeMillis());
    }

    private final MatchRoster roster = new MatchRoster();

    public MatchRoster roster() { return roster; }

    public void observeBindPri(byte[] body, int off, int len) {
        com.mg.panel.decode.body.WireReader r =
                new com.mg.panel.decode.body.WireReader(body, off, len);
        long header = r.u();
        int count = (int) (header >> 1);
        if (r.bad || count < 1 || count > 256) return;
        for (int i = 0; i < count && !r.bad; i++) {
            long owner = r.u();
            int type = r.rawByte();
            long ent = r.u();
            if (r.bad) return;
            pri.onBind(owner, type, ent);
        }
    }

    public boolean maskReady() { return maskValid; }

    public double posX() { return posX; }
    public double posZ() { return posZ; }
    public double posY() { return posY; }

    public float dirX() { return dirX; }
    public float dirY() { return dirY; }
    public float dirZ() { return dirZ; }

    public double yawRad() { return Math.atan2(dirX, dirZ); }
    public double pitchRad() { return Math.asin(Math.max(-1.0, Math.min(1.0, dirY))); }

    private volatile long dirSampleMs = 0L;
    private volatile float camAngVelX, camAngVelY, camAngVelZ;
    private volatile boolean camAngVelValid = false;

    public float camPanDegPerSec() {
        if (!camAngVelValid) return -1f;
        double m = Math.sqrt((double) camAngVelX * camAngVelX
                + (double) camAngVelY * camAngVelY
                + (double) camAngVelZ * camAngVelZ);
        return (float) Math.toDegrees(m) * 1000f;   
    }

    public long camSampleAgeMs(long now) {
        return dirSampleMs == 0L ? -1L : (now - dirSampleMs);
    }

    private static final long CAM_DT_MIN_MS = 60L;
    private static final long CAM_DT_MAX_MS = 160L;
    private static final double CAM_CUT_RAD = Math.toRadians(80.0);

    private void computeCameraAngVel(float px, float py, float pz, long pMs,
                                     float nx, float ny, float nz, long nMs) {
        long dt = nMs - pMs;
        if (pMs == 0L || dt < CAM_DT_MIN_MS || dt > CAM_DT_MAX_MS) {
            camAngVelValid = false;
            return;
        }
        double pm = Math.sqrt((double) px * px + (double) py * py + (double) pz * pz);
        double nm = Math.sqrt((double) nx * nx + (double) ny * ny + (double) nz * nz);
        if (pm < 1e-6 || nm < 1e-6) { camAngVelValid = false; return; }
        double pxn = px / pm, pyn = py / pm, pzn = pz / pm;
        double nxn = nx / nm, nyn = ny / nm, nzn = nz / nm;

        double crx = pyn * nzn - pzn * nyn;
        double cry = pzn * nxn - pxn * nzn;
        double crz = pxn * nyn - pyn * nxn;
        double sinMag = Math.sqrt(crx * crx + cry * cry + crz * crz);
        double dot = pxn * nxn + pyn * nyn + pzn * nzn;
        double ang = Math.atan2(sinMag, dot);
        if (ang > CAM_CUT_RAD) { camAngVelValid = false; return; }   
        if (sinMag < 1e-7) {
            camAngVelX = 0f; camAngVelY = 0f; camAngVelZ = 0f;
            camAngVelValid = true;
            return;
        }
        double speed = ang / dt;          
        double inv = speed / sinMag;      
        camAngVelX = (float) (crx * inv);
        camAngVelY = (float) (cry * inv);
        camAngVelZ = (float) (crz * inv);
        camAngVelValid = true;
    }

    public boolean extrapolatedDir(long now, double leadMs, double maxDeg, float[] out) {
        if (out == null || out.length < 3) return false;
        float cx = dirX, cy = dirY, cz = dirZ;   
        out[0] = cx; out[1] = cy; out[2] = cz;
        if (!camAngVelValid || dirSampleMs == 0L) return false;
        double ahead = (double) (now - dirSampleMs) + leadMs;
        if (ahead <= 0) return false;
        double wx = camAngVelX, wy = camAngVelY, wz = camAngVelZ;
        double wmag = Math.sqrt(wx * wx + wy * wy + wz * wz);
        if (wmag < 1e-9) return false;           
        double theta = wmag * ahead;             
        double maxRad = Math.toRadians(maxDeg);
        if (maxRad > 0 && theta > maxRad) theta = maxRad;
        if (theta < 1e-6) return false;
        double cm = Math.sqrt((double) cx * cx + (double) cy * cy + (double) cz * cz);
        if (cm < 1e-6) return false;
        double fx = cx / cm, fy = cy / cm, fz = cz / cm;
        double ax = wx / wmag, ay = wy / wmag, az = wz / wmag;

        double ct = Math.cos(theta), st = Math.sin(theta);
        double dotAF = ax * fx + ay * fy + az * fz;
        double krx = ay * fz - az * fy;
        double kry = az * fx - ax * fz;
        double krz = ax * fy - ay * fx;
        double rx = fx * ct + krx * st + ax * dotAF * (1 - ct);
        double ry = fy * ct + kry * st + ay * dotAF * (1 - ct);
        double rz = fz * ct + krz * st + az * dotAF * (1 - ct);
        double rm = Math.sqrt(rx * rx + ry * ry + rz * rz);
        if (rm < 1e-6) return false;
        out[0] = (float) (rx / rm);
        out[1] = (float) (ry / rm);
        out[2] = (float) (rz / rm);
        return true;
    }

    public long dirSampleMs() {
        return dirSampleMs;
    }

    public double camPitchDeg() {
        double y = dirY;
        if (y > 1.0) y = 1.0;
        else if (y < -1.0) y = -1.0;
        return Math.toDegrees(Math.asin(y));
    }

    public long ownStateMs() { return ownStateMs; }

    public void observeVehicleState(int cmd, byte[] body, int off, int len) {
        com.mg.panel.decode.body.VehicleSync.Result r =
                com.mg.panel.decode.body.VehicleSync.parse(cmd, body, off, len);
        if (r == null) {
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.ESP_VEHICLE_PARSE_REFUSED);
            return;                                
        }
        long now = System.currentTimeMillis();
        final int src = (cmd == 2069) ? OWN_SRC_2069 : OWN_SRC_2002;
        if (src == OWN_SRC_2069) ownMs2069 = now; else ownMs2002 = now;

        if (mayWritePos(src, now)) {
            posX = (double) r.x;
            posZ = (double) r.up;
            posY = (double) r.z;
            ownPosSrc = src;
            ownStateMs = now;
        }

        if (r.hasAim) {
            float m = (float) Math.sqrt(
                    r.aimX * r.aimX + r.aimUp * r.aimUp + r.aimZ * r.aimZ);
            if (m > 1e-4f && mayWriteDir(src, now)) {
                dirX = r.aimX / m;
                dirY = r.aimUp / m;
                dirZ = r.aimZ / m;
                dirSampleMs = now;
                ownDirSrc = src;
                camAngVelValid = false;
            }
        } else {
            if (MOUNT_VEHICLE_CAMERA && mayWriteDir(src, now)) {
                float fx = 2f * (r.qx * r.qz + r.qw * r.qy);
                float fz = 1f - 2f * (r.qx * r.qx + r.qy * r.qy);
                float h = (float) Math.sqrt(fx * fx + fz * fz);
                if (h > 1e-4f) {
                    dirX = fx / h;
                    dirZ = fz / h;
                    dirY = 0f;
                    dirSampleMs = now;
                    ownDirSrc = OWN_SRC_2002Q;
                    ownMs2002q = now;
                }
            }
            if (ownPosSrc == src) camAngVelValid = false;
        }
        com.mg.panel.diag.Diag.hit(cmd == 2069 ? com.mg.panel.diag.Slot.ESP_OWN_FROM_2069 : com.mg.panel.diag.Slot.ESP_OWN_FROM_2002);
    }
    public String ownSourceLine() {
        long now = System.currentTimeMillis();
        StringBuilder sb = new StringBuilder(96);
        sb.append("pos=").append(srcName(ownPosSrc))
          .append(" dir=").append(srcName(ownDirSrc))
          .append(" age=").append(ownStateMs == 0L ? -1L : (now - ownStateMs)).append("ms");
        if (mounted()) sb.append(" MNT");
        if (ownPosSrc == OWN_SRC_NONE && ownDirSrc == OWN_SRC_NONE) {
            sb.append("  NO OWN STATE");
        } else if (mounted() && ownPosSrc == OWN_SRC_ECHO && ownDirSrc == OWN_SRC_ECHO) {
            sb.append("  NO CARRIER -- echo only");
        }
        int rej = com.mg.panel.decode.body.VehicleSync.rejected();
        int vop = com.mg.panel.decode.body.VehicleSync.opVarintReads();
        if (rej > 0) sb.append("  rej=").append(rej);
        if (vop > 0) sb.append("  OP>=0x80 READ AS VARINT x").append(vop);
        return sb.toString();
    }

    private static String srcName(int src) {
        switch (src) {
            case OWN_SRC_2001: return "2001";
            case OWN_SRC_2069: return "2069";
            case OWN_SRC_2002: return "2002";
            case OWN_SRC_2002Q: return "2002q(heading!)";
            case OWN_SRC_ECHO: return "echo";
            default:           return "none";
        }
    }

    public Map<Integer, Track> entities() { return entities; }

    public void roleCounts(long ms, int[] out) {
        if (out == null || out.length < 3) return;
        out[0] = 0; out[1] = 0; out[2] = 0;
        long now = System.currentTimeMillis();
        for (Map.Entry<Integer, Track> e : entities.entrySet()) {
            Track t = e.getValue();
            if (now - t.updateMs >= ms) continue;
            if (t.dead) continue;
            int id = e.getKey();
            if (ownEntityId > 0 && id == ownEntityId) continue;   
            if (t.role == ROLE_SELF) continue;
            if (t.role == ROLE_TEAM) out[1]++;
            else if (t.role == ROLE_ENEMY) out[0]++;
            else out[2]++;
        }
    }

    public int activeEntityCount(long ms) {
        long now = System.currentTimeMillis();
        int n = 0;
        for (Track t : entities.values()) {
            if (now - t.updateMs < ms) n++;
        }
        return n;
    }

    public String calibrationReadout() {
        return calibReadout;
    }

    private void updateCalibReadout() {
        StringBuilder sb = new StringBuilder();
        if (!maskValid) {
            sb.append("ESP LEARN (").append(maskSamples).append(")");
        } else {
            sb.append("ESP READY");
            if (maskLocked) sb.append(" (locked)");
        }
        sb.append(String.format("\nPOS %.0f,%.0f Z=%.0f", posX, posY, posZ));
        sb.append('\n').append(teamLine());
        sb.append(String.format("\nDIR %.3f,%.3f,%.3f yaw=%.0f\u00b0 pitch=%.0f\u00b0",
                dirX, dirY, dirZ,
                Math.toDegrees(yawRad()), Math.toDegrees(pitchRad())));
        if (airborne) sb.append(" AIR");
        long now = System.currentTimeMillis();
        int active = activeEntityCount(3000);
        int moving = 0;
        for (Track t : entities.values()) {
            if (now - t.updateMs < 3000 && now - t.lastMoveMs < 1500) moving++;
        }
        sb.append(String.format("\nSELF e%d  DMG %d  KILLS %d",
                ownEntityId, damageEvents, kills));
        sb.append("\nENT ").append(active).append(" live, ").append(moving).append(" moving")
          .append(" (ka ok/bad ").append(keepaliveParseOk).append("/").append(keepaliveParseBad).append(")");
        int shown = 0;
        for (Map.Entry<Integer, Track> e : entities.entrySet()) {
            if (shown >= 4) break;
            Track t = e.getValue();
            if (now - t.updateMs >= 3000) continue;
            double dx = t.x - posX;
            double dy = t.y - posY;
            double dist = Math.sqrt(dx * dx + dy * dy);
            double brg = Math.toDegrees(Math.atan2(dx, dy));
            if (brg < 0) brg += 360;
            String st = (now - t.lastMoveMs < 1500) ? "MOV" : "still";
            String tag = t.role == ROLE_SELF ? "S" : (t.role == ROLE_TEAM ? "T"
                    : (t.role == ROLE_ENEMY ? "E" : "?"));
            sb.append(String.format("\n%s%02d %s %.0fm @%.0f\u00b0 hp%d%s",
                    tag, e.getKey(), st, dist / UNITS_PER_METRE, brg, t.hp,
                    t.dead ? " DEAD" : ""));
            shown++;
        }
        calibReadout = sb.toString();
    }
}