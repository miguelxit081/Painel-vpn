package com.mg.panel;

import android.content.Context;
import android.provider.Settings;

import org.json.JSONObject;
import org.json.JSONException;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Validação compatível com o gerador SWB Fake Lag:
 * Realtime Database /KeysUsers e campos key, status, dias, validade,
 * dispositivos e device.
 */
public final class FakeLagKeyAuth {
    private static final String DATABASE =
            "https://fake-lag-a463f-default-rtdb.firebaseio.com";
    private static final String PATH = "/KeysUsers";
    private static final long LIFETIME_TIMESTAMP = 4102444800000L;
    private static final int CONNECT_TIMEOUT = 15000;
    private static final int READ_TIMEOUT = 15000;

    private FakeLagKeyAuth() { }

    public static final class Result {
        public final boolean success;
        public final String message;
        public final boolean offerTelegram;

        private Result(boolean ok, String msg, boolean telegram) {
            success = ok;
            message = msg;
            offerTelegram = telegram;
        }

        static Result ok() { return new Result(true, "OK", false); }
        static Result fail(String msg, boolean telegram) {
            return new Result(false, msg, telegram);
        }
    }

    public static Result activateOrValidate(Context context, String inputKey) {
        if (context == null || inputKey == null || inputKey.trim().isEmpty()) {
            return Result.fail("Key inválida.", true);
        }

        HttpURLConnection conn = null;
        try {
            String key = inputKey.trim();
            // Evita orderBy/equalTo, que exige .indexOn nas regras do RTDB
            // e estava retornando HTTP 400 no banco do gerador.
            String queryUrl = DATABASE + PATH + ".json";
            HttpResult query = request(queryUrl, "GET", null, null, false);
            if (query.code == 401 || query.code == 403) {
                return Result.fail("Firebase negou o acesso. Verifique as regras de leitura do banco.", false);
            }
            if (query.code < 200 || query.code >= 300) {
                return Result.fail("Erro ao consultar o Firebase (HTTP " + query.code + ").", false);
            }

            if (query.body == null || query.body.trim().isEmpty()
                    || "null".equals(query.body.trim())) {
                return Result.fail("Key não encontrada no Fake Lag.", true);
            }
            JSONObject matches = new JSONObject(query.body);
            String recordId = null;
            for (java.util.Iterator<String> it = matches.keys(); it.hasNext();) {
                String id = it.next();
                JSONObject candidate = matches.optJSONObject(id);
                if (candidate != null && key.equals(candidate.optString("key", ""))) {
                    recordId = id;
                    break;
                }
            }
            if (recordId == null) return Result.fail("Key não encontrada no Fake Lag.", true);

            String recordUrl = DATABASE + PATH + "/" + recordId + ".json";
            HttpResult current = request(recordUrl, "GET", null, null, true);
            if (current.code == 401 || current.code == 403) {
                return Result.fail("Firebase negou a leitura da key. Confira as regras do Realtime Database.", false);
            }
            if (current.code < 200 || current.code >= 300) {
                return Result.fail("Não foi possível ler a key (HTTP " + current.code + ").", false);
            }
            if (current.etag == null || current.etag.trim().isEmpty()) {
                return Result.fail("O Firebase não retornou ETag para validar a ativação com segurança.", false);
            }

            JSONObject record = new JSONObject(current.body);
            String status = record.optString("status", "").trim().toLowerCase(Locale.US);
            if ("pausada".equals(status)) return Result.fail("Esta key está pausada.", true);
            if ("banida".equals(status)) return Result.fail("Esta key foi banida.", true);
            if (!status.isEmpty() && !"ativada".equals(status)
                    && !"ativa".equals(status) && !"ativado".equals(status)) {
                return Result.fail("Status da key não reconhecido: " + status, false);
            }

            long now = System.currentTimeMillis();
            long dias = parseLong(record.optString("dias", "0"));
            long validade = parseLong(record.optString("validade", "0"));
            boolean activated = "ativada".equals(status) || "ativa".equals(status)
                    || "ativado".equals(status) || dias > 1000000000000L;

            if (activated && dias > 1000000000000L && dias <= now) {
                return Result.fail("A validade desta key expirou.", true);
            }

            // "Livre" no gerador significa sem limite de aparelhos.
            String deviceLimitRaw = record.optString("dispositivos", "Livre").trim();
            int deviceLimit = 0;
            if (!deviceLimitRaw.isEmpty() && !"livre".equalsIgnoreCase(deviceLimitRaw)) {
                try { deviceLimit = Integer.parseInt(deviceLimitRaw); }
                catch (NumberFormatException ignored) {
                    return Result.fail("Limite de dispositivos inválido nesta key.", false);
                }
                if (deviceLimit < 1) return Result.fail("Limite de dispositivos inválido nesta key.", false);
            }

            String androidId = Settings.Secure.getString(
                    context.getContentResolver(), Settings.Secure.ANDROID_ID);
            if (androidId == null || androidId.trim().isEmpty()) {
                return Result.fail("Não foi possível identificar este dispositivo.", false);
            }

            String deviceField = record.optString("device", "").trim();
            List<String> devices = splitDevices(deviceField);
            if (deviceLimit > 0 && !devices.contains(androidId)) {
                if (devices.size() >= deviceLimit) {
                    return Result.fail("Esta key já atingiu o limite de " + deviceLimit + " dispositivo(s).", true);
                }
                devices.add(androidId);
            }

            boolean needsWrite = false;
            if (!activated) {
                long expiry;
                if (validade <= 0 || validade >= 1000) {
                    expiry = LIFETIME_TIMESTAMP;
                } else {
                    expiry = now + validade * 24L * 60L * 60L * 1000L;
                }
                record.put("status", "ativada");
                record.put("dias", String.valueOf(expiry));
                needsWrite = true;
            } else if (dias <= 0) {
                // Compatibilidade com registros antigos do gerador que só marcaram status.
                long expiry = (validade <= 0 || validade >= 1000)
                        ? LIFETIME_TIMESTAMP
                        : now + validade * 24L * 60L * 60L * 1000L;
                record.put("dias", String.valueOf(expiry));
                needsWrite = true;
            }

            if (deviceLimit > 0) {
                String updatedDevices = joinDevices(devices);
                if (!updatedDevices.equals(deviceField)) {
                    record.put("device", updatedDevices);
                    needsWrite = true;
                }
            }

            if (needsWrite) {
                HttpResult update = request(recordUrl, "PUT", record.toString(), current.etag, false);
                if (update.code == 412) {
                    return Result.fail("A key foi alterada ao mesmo tempo. Tente novamente.", false);
                }
                if (update.code == 401 || update.code == 403) {
                    return Result.fail("Firebase negou a gravação. Ative a permissão de escrita para o app.", false);
                }
                if (update.code < 200 || update.code >= 300) {
                    return Result.fail("Não foi possível salvar a ativação no Firebase (HTTP " + update.code + ").", false);
                }
            }

            return Result.ok();
        } catch (Exception e) {
            String detail = e.getMessage();
            if (detail == null || detail.trim().isEmpty()) detail = e.getClass().getSimpleName();
            return Result.fail("Falha ao conectar/validar no Firebase: " + detail, false);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static HttpResult request(String address, String method, String body,
                                      String etag, boolean requestEtag) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(address).openConnection();
        conn.setRequestMethod(method);
        conn.setConnectTimeout(CONNECT_TIMEOUT);
        conn.setReadTimeout(READ_TIMEOUT);
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("User-Agent", "MG-WIRE-FakeLag/1.0");
        if (requestEtag) conn.setRequestProperty("X-Firebase-ETag", "true");
        if (etag != null) conn.setRequestProperty("if-match", etag);
        if (body != null) {
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            OutputStream out = conn.getOutputStream();
            out.write(body.getBytes(StandardCharsets.UTF_8));
            out.flush();
            out.close();
        }
        int code = conn.getResponseCode();
        InputStream in = (code >= 200 && code < 400) ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(in);
        String responseEtag = conn.getHeaderField("ETag");
        conn.disconnect();
        return new HttpResult(code, response, responseEtag);
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        int count;
        while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
        in.close();
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    private static String enc(String value) throws Exception {
        return URLEncoder.encode(value, "UTF-8");
    }

    private static long parseLong(String value) {
        try { return Long.parseLong(value == null ? "0" : value.trim()); }
        catch (Exception ignored) { return 0L; }
    }

    private static List<String> splitDevices(String value) {
        List<String> out = new ArrayList<String>();
        if (value == null || value.trim().isEmpty()) return out;
        String[] parts = value.split("[,;|]");
        for (String part : parts) {
            String v = part.trim();
            if (!v.isEmpty() && !out.contains(v)) out.add(v);
        }
        return out;
    }

    private static String joinDevices(List<String> values) {
        StringBuilder out = new StringBuilder();
        for (String value : values) {
            if (out.length() > 0) out.append(',');
            out.append(value);
        }
        return out.toString();
    }

    private static final class HttpResult {
        final int code;
        final String body;
        final String etag;
        HttpResult(int c, String b, String e) { code = c; body = b; etag = e; }
    }
}
