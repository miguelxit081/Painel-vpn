package com.mg.panel;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity {
    private static final String PREFS = "hypers_firebase_prefs";
    private static final String KEY_TOKEN = "auth_token";
    private static final String KEY_USER = "auth_user";
    private static final String DISCORD_URL = "https://discord.gg/CMM2nJJjZD";
    private static final String WHATSAPP_URL = "https://whatsapp.com/channel/0029VbENUxF1SWsvxdbuEy0Q";
    private EditText keyInput;
    private TextView status;
    private Button login;
    private View dot;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        try { if (getActionBar() != null) getActionBar().hide(); } catch (Exception ignored) { }
        keyInput = findViewById(R.id.et_license_key);
        status = findViewById(R.id.tv_login_status);
        login = findViewById(R.id.btn_activate);
        dot = findViewById(R.id.dot_login);
        View discord = findViewById(R.id.ll_discord);
        if (discord != null) discord.setOnClickListener(v -> openDiscord());
        View whatsapp = findViewById(R.id.ll_whatsapp);
        if (whatsapp != null) whatsapp.setOnClickListener(v -> openWhatsApp());
        if (keyInput != null) keyInput.setSaveEnabled(false);
        if (login != null) login.setOnClickListener(v -> doOnlineLogin());

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String saved = prefs.getString(KEY_USER, "");
        if (saved != null && !saved.trim().isEmpty()) validateStoredKey(saved);
    }

    private void doOnlineLogin() {
        final String key = keyInput == null ? "" : keyInput.getText().toString().trim();
        if (key.isEmpty()) { setStatus("Digite sua key!", R.drawable.dot_warn); return; }
        setBusy(true);
        setStatus("Conectando ao Firebase Fake Lag...", R.drawable.dot_on);
        new AsyncTask<Void, Void, FakeLagKeyAuth.Result>() {
            @Override protected FakeLagKeyAuth.Result doInBackground(Void... v) {
                return FakeLagKeyAuth.activateOrValidate(LoginActivity.this, key);
            }
            @Override protected void onPostExecute(FakeLagKeyAuth.Result r) {
                setBusy(false);
                if (r != null && r.success) saveAndGo(key);
                else {
                    String msg = r == null ? "Falha ao validar a key." : r.message;
                    setStatus(msg, R.drawable.dot_warn);
                    if (r != null && r.offerTelegram) showKeyDialog(msg);
                }
            }
        }.execute();
    }

    private void validateStoredKey(final String key) {
        setBusy(true);
        setStatus("Verificando sua key no Firebase...", R.drawable.dot_on);
        new AsyncTask<Void, Void, FakeLagKeyAuth.Result>() {
            @Override protected FakeLagKeyAuth.Result doInBackground(Void... v) {
                return FakeLagKeyAuth.activateOrValidate(LoginActivity.this, key);
            }
            @Override protected void onPostExecute(FakeLagKeyAuth.Result r) {
                setBusy(false);
                if (r != null && r.success) saveAndGo(key);
                else {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_TOKEN).remove(KEY_USER).apply();
                    setStatus((r == null ? "Não foi possível validar." : r.message) + " Digite sua key novamente.", R.drawable.dot_warn);
                }
            }
        }.execute();
    }

    private void saveAndGo(String key) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_TOKEN, "KEY_USER|" + key).putString(KEY_USER, key).apply();
        setStatus("Login autorizado!", R.drawable.dot_on);
        openMainPage();
    }
    private void setBusy(boolean b) {
        if (login != null) login.setEnabled(!b);
        if (keyInput != null) keyInput.setEnabled(!b);
    }
    private void setStatus(String s, int drawable) {
        if (status != null) status.setText(s);
        if (dot != null) dot.setBackgroundResource(drawable);
    }
    private void showKeyDialog(String reason) {
        new AlertDialog.Builder(this).setTitle("Obter key")
                .setMessage(reason + "\\n\\nEntre no Discord para obter uma key.")
                .setPositiveButton("ABRIR DISCORD", (d,w) -> openDiscord())
                .setNegativeButton("FECHAR", null).show();
    }

    private void openMainPage() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void openDiscord() {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(DISCORD_URL))); }
        catch (Throwable ignored) { Toast.makeText(this, R.string.login_link_error, Toast.LENGTH_SHORT).show(); }
    }

    private void openWhatsApp() {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(WHATSAPP_URL))); }
        catch (Throwable ignored) { Toast.makeText(this, R.string.login_link_error, Toast.LENGTH_SHORT).show(); }
    }
}
