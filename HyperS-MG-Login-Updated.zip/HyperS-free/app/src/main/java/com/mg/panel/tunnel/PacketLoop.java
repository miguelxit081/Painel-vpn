package com.mg.panel.tunnel;

import com.mg.panel.dev.DevLogger;
import com.mg.panel.filter.FilterDecision;
import com.mg.panel.filter.FilterEngine;
import com.mg.panel.protocol.GamePacketTaxonomy;
import com.mg.panel.filter.PacketClassifier;
import com.mg.panel.filter.PacketContext;
import com.mg.panel.decode.frame.Direction;
import com.mg.panel.protocol.PacketPipeline;
import com.mg.panel.decode.frame.UdpPacket;
import com.mg.panel.freeze.FreezeController;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class PacketLoop {

    private static final boolean ICMP_ECHO_REPLY_ENABLED = true;

    private final VpnEngine engine;
    private final FilterEngine filterEngine;
    private final UdpSessionManager sessions;
    private final DevLogger logger;

    public PacketLoop(VpnEngine engine, FilterEngine filterEngine, UdpSessionManager sessions, DevLogger logger) {
        this.engine = engine;
        this.filterEngine = filterEngine;
        this.sessions = sessions;
        this.logger = logger;
    }

    public void loop(FileInputStream in, FileOutputStream out) throws Exception {
        byte[] buf = new byte[0xffff];

        while (engine.isRun && engine.isActive) {
            int len = in.read(buf);
            if (len < 0) break;
            if (len < 20) continue;
            engine.bIn.addAndGet(len);

            int version = (buf[0] >> 4) & 0xf;
            if (version != 4) {
                logger.logProtocolDrop("DROP_NON_IPV4", buf, 0, len, 0, 0, 0,
                        "version=" + version + " ip_len=" + len + " route=" + engine.activeRouteModeName());
                continue;
            }
            int proto = buf[9] & 0xff;
            int ihl = (buf[0] & 0xf) * 4;

            if (len < ihl + 8) continue;

            int dip = PacketBuilder.ri(buf, 16);
            int sp = PacketBuilder.rs(buf, ihl);
            int dp = PacketBuilder.rs(buf, ihl + 2);

            if (proto == 1 && ICMP_ECHO_REPLY_ENABLED
                    && PacketBuilder.replyIcmpEchoRequest(buf, len, ihl, dip, sp, dp, out, logger,
                    engine.activeRouteModeName())) {
                continue;
            }

            if (proto == 6) {
                engine.tcpProxy().handlePacket(buf, len);
                continue;
            }

            if (proto != 17) {
                logger.logProtocolDrop("DROP_NON_UDP", buf, ihl, len - ihl, sp, dp, dip,
                        "proto=" + PacketBuilder.protoName(proto)
                                + " ip_len=" + len
                                + " route=" + engine.activeRouteModeName());
                continue;
            }

            int plen = PacketBuilder.rs(buf, ihl + 4) - 8;
            int off = ihl + 8;

            if (plen < 0 || off + plen > len) continue;

            engine.outUdpSeen.incrementAndGet();
            com.mg.panel.diag.Diag.hit(com.mg.panel.diag.Slot.TUNNEL_PKT_OUT);

            int teleType = PacketClassifier.classify(buf, off, plen);

            GamePacketTaxonomy.observeOutbound(buf, off, plen, System.currentTimeMillis(), dip, dp);

            if (plen == 24) {
                engine.esp().observeInputStream(buf, off);
            } else if (plen >= 32 && plen <= 96
                    && off + 14 <= buf.length
                    && (buf[off + 9] & 0xff) == 0x80 && (buf[off + 10] & 0xff) == 0x80
                    && (buf[off + 8] & 0x80) != 0) {
                engine.esp().observeKeepalive(buf, off, plen);
            }

            int cmd = PacketContext.CMD_UNRESOLVED;
            PacketPipeline pipeline = engine.pipeline();
            UdpPacket parsed = pipeline.observeAndParse(buf, off, plen, Direction.OUTBOUND);
            if (parsed != null) {
                if (parsed.isCrcValid()) {
                    cmd = parsed.cmd();
                    FreezeController.observeCommand(cmd, null, false);
                    com.mg.panel.protocol.ScopeState.observeOutbound(cmd);
                    if (com.mg.panel.decode.body.VehicleSync
                            .isVehicleCarrier(cmd)) {
                        engine.esp().observeVehicleState(cmd, parsed.buffer(),
                                parsed.payloadOffset(), parsed.payloadLength());
                    }
                }
                com.mg.panel.protocol.SessionTimeline.observeUdp(parsed, true);
            }
            engine.capture().setLayoutSolved(pipeline.isReady());

            PacketContext ctx = new PacketContext(buf, len, ihl, proto, dip, sp, dp, plen, off,
                    teleType, cmd);

            FilterDecision d = filterEngine.onOutbound(ctx);
            final int recLen = ctx.outLength();
            if (d == FilterDecision.PASS && ctx.wasRewritten()) {
                engine.capture().recordOutbound(recLen, dip, sp, dp, teleType,
                        com.mg.panel.dev.capture.CaptureEvent.REWRITE, buf, off);
            } else {
                engine.capture().recordOutbound(recLen, dip, sp, dp, teleType,
                        toCaptureDecision(d), buf, off);
            }
            if (d == FilterDecision.PASS) {
                sessions.send(ctx, out);
            } else if (d == FilterDecision.DROP) {
                engine.pDrop.incrementAndGet();
            }
        }
    }

    private static com.mg.panel.dev.capture.CaptureRecord.Decision toCaptureDecision(FilterDecision d) {
        if (d == FilterDecision.DROP) return com.mg.panel.dev.capture.CaptureRecord.Decision.DROP;
        if (d == FilterDecision.HOLD) return com.mg.panel.dev.capture.CaptureRecord.Decision.HOLD;
        return com.mg.panel.dev.capture.CaptureRecord.Decision.PASS;
    }
}
