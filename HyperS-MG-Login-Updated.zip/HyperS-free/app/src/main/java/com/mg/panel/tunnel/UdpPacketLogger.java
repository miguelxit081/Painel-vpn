package com.mg.panel.tunnel;

import android.os.Environment;
import android.util.Log;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class UdpPacketLogger {
    private static final String TAG = "UdpPacketLogger";
    private static FileWriter fileWriter = null;
    private static boolean isLogging = false;

    public static synchronized void startLogging() {
        if (isLogging) return;
        try {
            File docsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
            File dir = new File(docsDir, "UdpCaptures");
            if (!dir.exists()) {
                dir.mkdirs();
            }
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            File file = new File(dir, "udp_dump_" + timeStamp + ".txt");
            fileWriter = new FileWriter(file, true);
            isLogging = true;
            
            fileWriter.write("=== UDP CAPTURE LOG STARTED AT " + timeStamp + " ===\n\n");
            fileWriter.flush();
            Log.d(TAG, "Readable UDP Capture started: " + file.getAbsolutePath());
        } catch (IOException e) {
            Log.e(TAG, "Error starting UDP logging", e);
        }
    }

    public static synchronized void logPacket(byte[] data, int offset, int length) {
        if (!isLogging || fileWriter == null) return;
        try {
            StringBuilder sb = new StringBuilder();
            sb.append(String.format(Locale.US, "[PACKET LENGTH: %d bytes]\n", length));
            
            StringBuilder hexPart = new StringBuilder();
            StringBuilder asciiPart = new StringBuilder();

            for (int i = 0; i < length; i++) {
                int b = data[offset + i] & 0xFF;
                hexPart.append(String.format("%02X ", b));

                if (b >= 32 && b <= 126) {
                    asciiPart.append((char) b);
                } else {
                    asciiPart.append('.');
                }

                if ((i + 1) % 16 == 0 || i == length - 1) {
                    sb.append(String.format("%-48s | %s\n", hexPart.toString(), asciiPart.toString()));
                    hexPart.setLength(0);
                    asciiPart.setLength(0);
                }
            }
            sb.append("--------------------------------------------------\n\n");
            fileWriter.write(sb.toString());
            fileWriter.flush();
        } catch (IOException e) {
            Log.e(TAG, "Error writing packet data", e);
        }
    }

    public static synchronized void stopLogging() {
        if (!isLogging) return;
        isLogging = false;
        try {
            if (fileWriter != null) {
                fileWriter.write("=== UDP CAPTURE LOG ENDED ===\n");
                fileWriter.close();
                fileWriter = null;
            }
            Log.d(TAG, "UDP Capture stopped and saved.");
        } catch (IOException e) {
            Log.e(TAG, "Error stopping UDP logging", e);
        }
    }

    public static boolean isLogging() {
        return isLogging;
    }
}
