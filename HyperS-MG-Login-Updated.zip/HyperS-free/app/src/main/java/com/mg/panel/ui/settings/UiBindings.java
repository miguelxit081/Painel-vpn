package com.mg.panel.ui.settings;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.SeekBar;
import android.widget.TextView;

import com.mg.panel.config.EspConfig;
import com.mg.panel.config.Prefs;
import com.mg.panel.R;

public final class UiBindings {

    private final Activity activity;
    private final AppearanceBroadcaster broadcaster;

    private final TextView cbFloatGhost, cbFloatFreeze, cbFloatTele;
    private final TextView tvFloatGhostStatus, tvFloatFreezeStatus, tvFloatTeleStatus;
    private final TextView cbDevMode, tvDevModeStatus;
    private TextView cbEsp, tvEspStatus, cbRadar, tvRadarStatus, cbEspLine, tvEspLineStatus, cbEspDebug, tvEspDebugStatus, cbEspTune, tvEspTuneStatus, cbAimSetup, tvAimSetupStatus;
    private TextView cbAimLag, tvAimLagStatus, cbAutoFreeze, tvAutoFreezeStatus, cbScopeFreeze, tvScopeFreezeStatus;
    private TextView cbFreezeModeGroup;
    private TextView cbEspSkeleton, tvEspSkeletonStatus, cbEspDistText, tvEspDistTextStatus, cbEspNameText, tvEspNameTextStatus, cbEspHpText, tvEspHpTextStatus;
    private final TextView tvFloatSizeValue, tvFloatAlphaValue;
    private final SeekBar seekFloatSize, seekFloatAlpha;
    private final ViewGroup mainContent;
    private final View groupTeleOptions;

    private View btnColorBlack, btnColorWhite, btnColorRed;
    private View btnColorYellow, btnColorBlue, btnColorGreen, btnColorPurple;
    private TextView tvEspColorLabel;
    private View btnSkeletonColorBlack, btnSkeletonColorWhite, btnSkeletonColorRed, btnSkeletonColorYellow, btnSkeletonColorBlue, btnSkeletonColorGreen, btnSkeletonColorPurple;
    private TextView tvSkeletonColorLabel;
    private View btnDistColorBlack, btnDistColorWhite, btnDistColorRed, btnDistColorYellow, btnDistColorBlue, btnDistColorGreen, btnDistColorPurple;
    private TextView tvDistColorLabel;
    private View btnNameColorBlack, btnNameColorWhite, btnNameColorRed, btnNameColorYellow, btnNameColorBlue, btnNameColorGreen, btnNameColorPurple;
    private TextView tvNameColorLabel;
    private View btnHpColorBlack, btnHpColorWhite, btnHpColorRed, btnHpColorYellow, btnHpColorBlue, btnHpColorGreen, btnHpColorPurple;
    private TextView tvHpColorLabel;

    private static final int[] COLOR_VALUES = {
            Color.argb(235,   0,   0,   0),
            Color.argb(235, 255, 255, 255),
            Color.argb(235, 255,  64,  64),
            Color.argb(235, 255, 220,   0),
            Color.argb(235,  60, 130, 255),
            Color.argb(235,  60, 220,  90),
            Color.argb(235, 180,  80, 255),
    };
    private static final String[] COLOR_NAMES = {
            "Black", "White", "Red", "Yellow", "Blue", "Green", "Purple"
    };

    private static int getResId(Activity act, String name) {
        return act.getResources().getIdentifier(name, "id", act.getPackageName());
    }

    public UiBindings(Activity activity, AppearanceBroadcaster broadcaster) {
        this.activity = activity;
        this.broadcaster = broadcaster;

        cbFloatGhost      = (TextView) activity.findViewById(getResId(activity, "cb_float_ghost"));
        cbFloatFreeze     = (TextView) activity.findViewById(getResId(activity, "cb_float_freeze"));
        cbFloatTele       = (TextView) activity.findViewById(getResId(activity, "cb_float_tele"));
        tvFloatGhostStatus   = (TextView) activity.findViewById(getResId(activity, "tv_float_ghost_status"));
        tvFloatFreezeStatus  = (TextView) activity.findViewById(getResId(activity, "tv_float_freeze_status"));
        tvFloatTeleStatus    = (TextView) activity.findViewById(getResId(activity, "tv_float_tele_status"));
        cbDevMode            = (TextView) activity.findViewById(getResId(activity, "cb_dev_mode"));
        tvDevModeStatus      = (TextView) activity.findViewById(getResId(activity, "tv_dev_mode_status"));

        tvFloatSizeValue = (TextView) activity.findViewById(getResId(activity, "tv_float_size_value"));
        tvFloatAlphaValue = (TextView) activity.findViewById(getResId(activity, "tv_float_alpha_value"));
        seekFloatSize = (SeekBar) activity.findViewById(getResId(activity, "seek_float_size"));
        seekFloatAlpha = (SeekBar) activity.findViewById(getResId(activity, "seek_float_alpha"));

        cbEsp = (TextView) activity.findViewById(getResId(activity, "cb_esp"));
        tvEspStatus = (TextView) activity.findViewById(getResId(activity, "tv_esp_status"));
        cbRadar = (TextView) activity.findViewById(getResId(activity, "cb_radar"));
        tvRadarStatus = (TextView) activity.findViewById(getResId(activity, "tv_radar_status"));
        cbEspLine = (TextView) activity.findViewById(getResId(activity, "cb_esp_line"));
        tvEspLineStatus = (TextView) activity.findViewById(getResId(activity, "tv_esp_line_status"));
        cbEspSkeleton = (TextView) activity.findViewById(getResId(activity, "cb_esp_skeleton"));
        tvEspSkeletonStatus = (TextView) activity.findViewById(getResId(activity, "tv_esp_skeleton_status"));
        cbEspDistText = (TextView) activity.findViewById(getResId(activity, "cb_esp_dist_text"));
        tvEspDistTextStatus = (TextView) activity.findViewById(getResId(activity, "tv_esp_dist_text_status"));
        cbEspNameText = (TextView) activity.findViewById(getResId(activity, "cb_esp_name_text"));
        tvEspNameTextStatus = (TextView) activity.findViewById(getResId(activity, "tv_esp_name_text_status"));
        cbEspHpText = (TextView) activity.findViewById(getResId(activity, "cb_esp_hp_text"));
        tvEspHpTextStatus = (TextView) activity.findViewById(getResId(activity, "tv_esp_hp_text_status"));
        cbEspDebug = (TextView) activity.findViewById(getResId(activity, "cb_espdebug"));
        tvEspDebugStatus = (TextView) activity.findViewById(getResId(activity, "tv_espdebug_status"));
        cbEspTune = (TextView) activity.findViewById(getResId(activity, "cb_esptune"));
        tvEspTuneStatus = (TextView) activity.findViewById(getResId(activity, "tv_esptune_status"));
        cbAimSetup = (TextView) activity.findViewById(getResId(activity, "cb_aimsetup"));
        tvAimSetupStatus = (TextView) activity.findViewById(getResId(activity, "tv_aimsetup_status"));
        cbAimLag       = (TextView) activity.findViewById(getResId(activity, "cb_aim_lag"));
        tvAimLagStatus = (TextView) activity.findViewById(getResId(activity, "tv_aim_lag_status"));
        cbAutoFreeze       = (TextView) activity.findViewById(getResId(activity, "cb_auto_freeze"));
        tvAutoFreezeStatus = (TextView) activity.findViewById(getResId(activity, "tv_auto_freeze_status"));
        cbScopeFreeze       = (TextView) activity.findViewById(getResId(activity, "cb_scope_freeze"));
        tvScopeFreezeStatus = (TextView) activity.findViewById(getResId(activity, "tv_scope_freeze_status"));

        mainContent = (ViewGroup) activity.findViewById(getResId(activity, "main_content"));
        groupTeleOptions = activity.findViewById(getResId(activity, "group_tele_options"));

        btnColorBlack  = activity.findViewById(getResId(activity, "btn_color_black"));
        btnColorWhite  = activity.findViewById(getResId(activity, "btn_color_white"));
        btnColorRed    = activity.findViewById(getResId(activity, "btn_color_red"));
        btnColorYellow = activity.findViewById(getResId(activity, "btn_color_yellow"));
        btnColorBlue   = activity.findViewById(getResId(activity, "btn_color_blue"));
        btnColorGreen  = activity.findViewById(getResId(activity, "btn_color_green"));
        btnColorPurple = activity.findViewById(getResId(activity, "btn_color_purple"));
        tvEspColorLabel = (TextView) activity.findViewById(getResId(activity, "tv_esp_color_label"));

        btnSkeletonColorBlack  = activity.findViewById(getResId(activity, "btn_skeleton_color_black"));
        btnSkeletonColorWhite  = activity.findViewById(getResId(activity, "btn_skeleton_color_white"));
        btnSkeletonColorRed    = activity.findViewById(getResId(activity, "btn_skeleton_color_red"));
        btnSkeletonColorYellow = activity.findViewById(getResId(activity, "btn_skeleton_color_yellow"));
        btnSkeletonColorBlue   = activity.findViewById(getResId(activity, "btn_skeleton_color_blue"));
        btnSkeletonColorGreen  = activity.findViewById(getResId(activity, "btn_skeleton_color_green"));
        btnSkeletonColorPurple = activity.findViewById(getResId(activity, "btn_skeleton_color_purple"));
        tvSkeletonColorLabel   = (TextView) activity.findViewById(getResId(activity, "tv_skeleton_color_label"));

        btnDistColorBlack  = activity.findViewById(getResId(activity, "btn_dist_color_black"));
        btnDistColorWhite  = activity.findViewById(getResId(activity, "btn_dist_color_white"));
        btnDistColorRed    = activity.findViewById(getResId(activity, "btn_dist_color_red"));
        btnDistColorYellow = activity.findViewById(getResId(activity, "btn_dist_color_yellow"));
        btnDistColorBlue   = activity.findViewById(getResId(activity, "btn_dist_color_blue"));
        btnDistColorGreen  = activity.findViewById(getResId(activity, "btn_dist_color_green"));
        btnDistColorPurple = activity.findViewById(getResId(activity, "btn_dist_color_purple"));
        tvDistColorLabel   = (TextView) activity.findViewById(getResId(activity, "tv_dist_color_label"));

        btnNameColorBlack  = activity.findViewById(getResId(activity, "btn_name_color_black"));
        btnNameColorWhite  = activity.findViewById(getResId(activity, "btn_name_color_white"));
        btnNameColorRed    = activity.findViewById(getResId(activity, "btn_name_color_red"));
        btnNameColorYellow = activity.findViewById(getResId(activity, "btn_name_color_yellow"));
        btnNameColorBlue   = activity.findViewById(getResId(activity, "btn_name_color_blue"));
        btnNameColorGreen  = activity.findViewById(getResId(activity, "btn_name_color_green"));
        btnNameColorPurple = activity.findViewById(getResId(activity, "btn_name_color_purple"));
        tvNameColorLabel   = (TextView) activity.findViewById(getResId(activity, "tv_name_color_label"));

        btnHpColorBlack  = activity.findViewById(getResId(activity, "btn_hp_color_black"));
        btnHpColorWhite  = activity.findViewById(getResId(activity, "btn_hp_color_white"));
        btnHpColorRed    = activity.findViewById(getResId(activity, "btn_hp_color_red"));
        btnHpColorYellow = activity.findViewById(getResId(activity, "btn_hp_color_yellow"));
        btnHpColorBlue   = activity.findViewById(getResId(activity, "btn_hp_color_blue"));
        btnHpColorGreen  = activity.findViewById(getResId(activity, "btn_hp_color_green"));
        btnHpColorPurple = activity.findViewById(getResId(activity, "btn_hp_color_purple"));
        tvHpColorLabel   = (TextView) activity.findViewById(getResId(activity, "tv_hp_color_label"));
    }

    public void setupAll() {
        setupFloatingToggle(cbFloatFreeze,  tvFloatFreezeStatus,  Prefs.KEY_FREEZE);
        setupFloatingToggle(cbFloatGhost,   tvFloatGhostStatus,   Prefs.KEY_GHOST);
        setupFloatingToggle(cbFloatTele,    tvFloatTeleStatus,    Prefs.KEY_TELE);
        setupFloatSizeSeek();
        setupFloatAlphaSeek();
        setupFloatingToggle(cbDevMode, tvDevModeStatus, Prefs.KEY_DEV_MODE);
        setupFloatingToggle(cbEsp,          tvEspStatus,          Prefs.KEY_ESP_BOXES);
        setupFloatingToggle(cbRadar,        tvRadarStatus,        Prefs.KEY_ESP_RADAR);
        setupFloatingToggle(cbEspLine,      tvEspLineStatus,      Prefs.KEY_ESP_LINE);
        setupFloatingToggle(cbEspSkeleton,  tvEspSkeletonStatus,  Prefs.KEY_ESP_SKELETON);
        setupFloatingToggle(cbEspDistText,  tvEspDistTextStatus,  Prefs.KEY_ESP_DIST_TEXT);
        setupFloatingToggle(cbEspNameText,  tvEspNameTextStatus,  Prefs.KEY_ESP_NAME_TEXT);
        setupFloatingToggle(cbEspHpText,    tvEspHpTextStatus,    Prefs.KEY_ESP_HP_TEXT);
        setupFloatingToggle(cbEspDebug,     tvEspDebugStatus,     Prefs.KEY_ESP_DEBUG);
        setupFloatingToggle(cbEspTune,  tvEspTuneStatus,  Prefs.KEY_ESP_TUNE);
        setupFloatingToggle(cbAimLag,      tvAimLagStatus,      Prefs.KEY_AIM_LAG);
        setupFloatingToggle(cbAutoFreeze,  tvAutoFreezeStatus,  Prefs.KEY_AUTO_FREEZE);
        setupFloatingToggle(cbScopeFreeze, tvScopeFreezeStatus, Prefs.KEY_SCOPE_FREEZE);
        setupFreezeModeSelector();
        setupColorPicker();
        setupSkeletonColorPicker();
        setupDistColorPicker();
        setupNameColorPicker();
        setupHpColorPicker();
        updateConditionalGroups(false);
        animateMainEntrance();
    }

    private interface ColorApplier { void apply(int argb); }

    private void wireColorPicker(View[] swatches, TextView label,
                                 String prefKey, int defaultArgb,
                                 ColorApplier applier) {
        int saved = Prefs.get(activity).getInt(prefKey, defaultArgb);
        applier.apply(saved);
        setColorLabel(label, saved);
        for (int i = 0; i < swatches.length; i++) {
            final View sw = swatches[i];
            if (sw == null) continue;
            final int cv = COLOR_VALUES[i];
            sw.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Prefs.get(activity).edit().putInt(prefKey, cv).commit();
                    applier.apply(cv);
                    setColorLabel(label, cv);
                    broadcaster.send();
                    v.animate().cancel();
                    v.setScaleX(0.85f); v.setScaleY(0.85f);
                    v.animate().scaleX(1f).scaleY(1f).setDuration(140L).start();
                }
            });
        }
    }

    private void setColorLabel(TextView tv, int argb) {
        if (tv == null) return;
        String name = "Custom";
        for (int i = 0; i < COLOR_VALUES.length; i++) {
            if (COLOR_VALUES[i] == argb) { name = COLOR_NAMES[i]; break; }
        }
        tv.setText("Selected: " + name);
    }

    private void setupColorPicker() {
        wireColorPicker(
            new View[]{btnColorBlack, btnColorWhite, btnColorRed, btnColorYellow, btnColorBlue, btnColorGreen, btnColorPurple},
            tvEspColorLabel, Prefs.KEY_ESP_BOX_COLOR, Color.argb(235, 255, 64, 64),
            new ColorApplier() { @Override public void apply(int a) { EspConfig.BOX_COLOR_ARGB = a; } });
    }

    private void setupSkeletonColorPicker() {
        wireColorPicker(
            new View[]{btnSkeletonColorBlack, btnSkeletonColorWhite, btnSkeletonColorRed, btnSkeletonColorYellow, btnSkeletonColorBlue, btnSkeletonColorGreen, btnSkeletonColorPurple},
            tvSkeletonColorLabel, Prefs.KEY_ESP_SKELETON_COLOR, Color.argb(235, 255, 255, 255),
            new ColorApplier() { @Override public void apply(int a) { EspConfig.SKELETON_COLOR_ARGB = a; } });
    }

    private void setupDistColorPicker() {
        wireColorPicker(
            new View[]{btnDistColorBlack, btnDistColorWhite, btnDistColorRed, btnDistColorYellow, btnDistColorBlue, btnDistColorGreen, btnDistColorPurple},
            tvDistColorLabel, Prefs.KEY_ESP_DIST_COLOR, Color.argb(235, 255, 255, 255),
            new ColorApplier() { @Override public void apply(int a) { EspConfig.DIST_COLOR_ARGB = a; } });
    }

    private void setupNameColorPicker() {
        wireColorPicker(
            new View[]{btnNameColorBlack, btnNameColorWhite, btnNameColorRed, btnNameColorYellow, btnNameColorBlue, btnNameColorGreen, btnNameColorPurple},
            tvNameColorLabel, Prefs.KEY_ESP_NAME_COLOR, Color.argb(235, 255, 255, 255),
            new ColorApplier() { @Override public void apply(int a) { EspConfig.NAME_COLOR_ARGB = a; } });
    }

    private void setupHpColorPicker() {
        wireColorPicker(
            new View[]{btnHpColorBlack, btnHpColorWhite, btnHpColorRed, btnHpColorYellow, btnHpColorBlue, btnHpColorGreen, btnHpColorPurple},
            tvHpColorLabel, Prefs.KEY_ESP_HP_COLOR, Color.argb(235, 255, 255, 255),
            new ColorApplier() { @Override public void apply(int a) { EspConfig.HP_COLOR_ARGB = a; } });
    }

    private void setupFloatSizeSeek() {
        bindSeek(seekFloatSize, tvFloatSizeValue,
                AppearanceBroadcaster.FLOAT_SIZE_MIN, AppearanceBroadcaster.FLOAT_SIZE_MAX,
                Prefs.KEY_FLOAT_SIZE, "%", broadcaster.getFloatSizePercent(), null);
    }

    private void setupFloatAlphaSeek() {
        bindSeek(seekFloatAlpha, tvFloatAlphaValue,
                AppearanceBroadcaster.FLOAT_ALPHA_MIN, AppearanceBroadcaster.FLOAT_ALPHA_MAX,
                Prefs.KEY_FLOAT_ALPHA, "%", broadcaster.getFloatAlphaPercent(), null);
    }

    private void bindSeek(final SeekBar seek, final TextView value, final int min, final int max,
                          final String key, final String suffix, final int saved, final Runnable onChanged) {
        if (seek == null || value == null) return;
        seek.setMax(max - min);
        seek.setProgress(saved - min);
        value.setText(saved + suffix);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int v = min + progress;
                Prefs.get(activity).edit().putInt(key, v).commit();
                value.setText(v + suffix);
                if (onChanged != null) onChanged.run();
                broadcaster.send();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
    }

    private void setupFloatingToggle(final TextView toggle, final TextView status, final String key) {
        if (toggle == null) return;
        boolean defaultOn = !Prefs.KEY_DEV_MODE.equals(key)
                && !Prefs.KEY_ESP_TUNE.equals(key)
                && !Prefs.KEY_AIM_SETUP.equals(key)
                && !Prefs.KEY_ESP_DEBUG.equals(key)
                && !Prefs.KEY_TELE.equals(key)
                && !Prefs.KEY_ESP_LINE.equals(key)
                && !Prefs.KEY_AIM_LAG.equals(key)
                && !Prefs.KEY_AUTO_FREEZE.equals(key)
                && !Prefs.KEY_SCOPE_FREEZE.equals(key);
        boolean isOn = Prefs.get(activity).getBoolean(key, defaultOn);
        applyToggleState(toggle, status, isOn);
        View.OnClickListener flip = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean current = toggle.getTag() != null && (Boolean) toggle.getTag();
                boolean next = !current;
                animateToggleState(toggle, status, next);
                Prefs.get(activity).edit().putBoolean(key, next).commit();
                broadcaster.send();
                updateConditionalGroups(true);
            }
        };
        toggle.setOnClickListener(flip);
        View row = (toggle.getParent() instanceof View) ? (View) toggle.getParent() : null;
        if (row != null) row.setOnClickListener(flip);
    }

    private void applyToggleState(TextView toggle, TextView status, boolean isOn) {
        int bgRes = 0;
        try {
            bgRes = isOn ? R.drawable.bg_switch_custom_on : R.drawable.bg_switch_custom_off;
        } catch (Exception e) {}
        if (toggle == null) return;
        toggle.setTag(isOn);
        toggle.setText("");
        if (bgRes != 0) {
            toggle.setBackgroundResource(bgRes);
        }
    }

    private void setupFreezeModeSelector() {
        final android.widget.RadioGroup rg =
                (android.widget.RadioGroup) activity.findViewById(getResId(activity, "rg_freeze_mode"));
        if (rg == null) return;

        String saved = Prefs.get(activity).getString(Prefs.KEY_FREEZE_MODE, "fire");
        int checkId;
        int idScope = getResId(activity, "rb_freeze_scope");
        int idBoth = getResId(activity, "rb_freeze_both");
        int idFire = getResId(activity, "rb_freeze_fire");

        switch (saved) {
            case "scope": checkId = idScope; break;
            case "both":  checkId = idBoth;  break;
            default:      checkId = idFire;  break;
        }
        if (checkId != 0) rg.check(checkId);

        rg.setOnCheckedChangeListener(new android.widget.RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.RadioGroup group, int checkedId) {
                String mode;
                if (checkedId == getResId(activity, "rb_freeze_scope")) {
                    mode = "scope";
                } else if (checkedId == getResId(activity, "rb_freeze_both")) {
                    mode = "both";
                } else {
                    mode = "fire";
                }
                Prefs.get(activity).edit().putString(Prefs.KEY_FREEZE_MODE, mode).commit();
                broadcaster.send();
            }
        });
    }

    private void animateToggleState(final TextView toggle, final TextView status,
                                    final boolean isOn) {
        if (toggle == null) return;
        // Record the target immediately so a fast second tap reverses cleanly.
        toggle.setTag(isOn);
        toggle.animate().cancel();
        toggle.animate()
                .alpha(0.35f)
                .scaleX(0.90f)
                .scaleY(0.90f)
                .setDuration(90L)
                .setInterpolator(new android.view.animation.DecelerateInterpolator())
                .withEndAction(new Runnable() {
                    @Override public void run() {
                        applyToggleState(toggle, status, isOn);
                        toggle.setAlpha(0.35f);
                        toggle.setScaleX(0.90f);
                        toggle.setScaleY(0.90f);
                        toggle.animate()
                                .alpha(1f)
                                .scaleX(1.06f)
                                .scaleY(1.06f)
                                .setDuration(170L)
                                .setInterpolator(new OvershootInterpolator(1.1f))
                                .withEndAction(new Runnable() {
                                    @Override public void run() {
                                        toggle.animate().scaleX(1f).scaleY(1f)
                                                .setDuration(80L)
                                                .setInterpolator(new android.view.animation.DecelerateInterpolator())
                                                .start();
                                    }
                                })
                                .start();
                    }
                })
                .start();
    }
    private void updateConditionalGroups(boolean animate) {}

    private void animateMainEntrance() {
        if (mainContent == null) return;
        for (int i = 0; i < mainContent.getChildCount(); i++) {
            View child = mainContent.getChildAt(i);
            child.setAlpha(0f);
            child.setTranslationY(28f);
            child.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setStartDelay(45L * i)
                    .setDuration(260L)
                    .start();
        }
    }
}
