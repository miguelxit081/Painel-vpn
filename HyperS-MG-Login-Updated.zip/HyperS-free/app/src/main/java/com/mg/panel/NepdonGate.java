package com.mg.panel;

import android.app.Activity;
import android.content.Context;


/** Local access gate. A real device cap must still be enforced server-side. */
public final class NepdonGate {
    public static final int MAX_DEVICES = 10000;
    private static final String PREFS = "nepdon_wire_access";
    private static final String LOGGED_IN = "logged_in";

    private static final int[] USERNAME_XOR = {
            20, 31, 10, 30, 21, 20, 109, 106, 106
    };
    private static final int USERNAME_KEY = 0x5A;

    private NepdonGate() { }

    public static boolean isUsernameValid(String value) {
        if (value == null || value.length() != USERNAME_XOR.length) return false;
        int diff = 0;
        for (int i = 0; i < USERNAME_XOR.length; i++) {
            diff |= value.charAt(i) ^ (USERNAME_XOR[i] ^ USERNAME_KEY);
        }
        return diff == 0;
    }

    public static boolean isLoggedIn(Context context) {
        return context != null
                && context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(LOGGED_IN, false);
    }

    public static void markLoggedIn(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(LOGGED_IN, true).apply();
    }

}
