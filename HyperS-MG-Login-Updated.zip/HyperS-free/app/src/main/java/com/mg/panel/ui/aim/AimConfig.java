package com.mg.panel.ui.aim;

public final class AimConfig {

    private AimConfig() { }

    public static final float DEF_PX_PER_DEG = 10.0f;
    public static volatile float PX_PER_DEG = DEF_PX_PER_DEG;
    public static final float PX_PER_DEG_MIN = 1f, PX_PER_DEG_MAX = 60f;

    public static final float DEF_MAX_TRAVEL_PX = 100f;
    public static volatile float MAX_TRAVEL_PX = DEF_MAX_TRAVEL_PX;
    public static final float MAX_TRAVEL_MIN = 20f, MAX_TRAVEL_MAX = 400f;


    public static final float DEF_SWIPE_X_FRAC = 0.72f;
    public static volatile float SWIPE_X_FRAC = DEF_SWIPE_X_FRAC;
    public static final float DEF_SWIPE_Y_FRAC = 0.45f;
    public static volatile float SWIPE_Y_FRAC = DEF_SWIPE_Y_FRAC;
    public static final float FRAC_MIN = 0.05f, FRAC_MAX = 0.95f;

    public static volatile boolean PLANT_ON_FIRE = true;


    public static volatile boolean AIM_ENABLED = true;

    public static volatile boolean AIM_ROTATION_ENABLED = true;

    public static volatile float AIM_ROTATION_MAX_STEP_DEG = 4.0f;
    public static final float AIM_ROTATION_STEP_MIN = 0.5f;
    public static final float AIM_ROTATION_STEP_MAX = 20.0f;

    public static volatile boolean TEST_MODE = true;

    public static final float DEF_TEST_HOLD_MS = 5000f;
    public static volatile int TEST_HOLD_MS = (int) DEF_TEST_HOLD_MS;
    public static final float HOLD_MS_MIN = 500f, HOLD_MS_MAX = 20000f;

    public static final long TARGET_MAX_AGE_MS = 250L;

    public static final float DEADZONE_DEG = 0.15f;

    public static volatile float AIM_H_STANDING_M = 1.75f;
    public static final float AIM_H_MIN = 1.40f, AIM_H_MAX = 2.10f;

    public static volatile float AIM_CROUCH_RATIO = 0.60f;

    public static volatile float AIM_ANCHOR_FRAC = 0.95f; // HEAD (skull crown)
    public static final float AIM_FRAC_MIN = 0.30f, AIM_FRAC_MAX = 1.00f;

    public static volatile float AIM_PIPELINE_MS = 0f;
    public static final float AIM_PIPELINE_MIN = 0f, AIM_PIPELINE_MAX = 600f;

    public static volatile float AIM_MAX_SRC_AGE_MS = 260f;

    public static volatile boolean AIM_POSTURE_GATE = false;

    public static volatile boolean AIM_TEST_TRACK = true;

    public static volatile float AIM_SCOPED_GAIN = 6.0f; 
    public static volatile float AIM_STEER_TAU_MS = 40f; // snappier head lock
    public static final float STEER_TAU_MIN = 10f, STEER_TAU_MAX = 400f;
    public static final float SCOPED_GAIN_MIN = 0.5f, SCOPED_GAIN_MAX = 20f;

    public static volatile float AIM_BASIS_STALE_MS = 1200f;

    public static float clamp(float v, float lo, float hi) {
        if (v != v) return lo;
        return v < lo ? lo : (v > hi ? hi : v);
    }

    public static final int PART_HEAD  = 0;
    public static final int PART_NECK  = 1;
    public static final int PART_CHEST = 2;

    public static final float ANCHOR_HEAD  = 0.95f;
    public static final float ANCHOR_NECK  = 0.82f;
    public static final float ANCHOR_CHEST = 0.55f;

    public static final float BOX_HEAD  = 0.96f;
    public static final float BOX_NECK  = 0.88f;
    public static final float BOX_CHEST = 0.55f;

    public static volatile int AIM_TARGET_PART = PART_HEAD;

    public static float anchorForPart(int part) {
        switch (part) {
            case PART_NECK:  return ANCHOR_NECK;
            case PART_CHEST: return ANCHOR_CHEST;
            default:         return ANCHOR_HEAD;
        }
    }

    public static float boxFracForPart(int part) {
        switch (part) {
            case PART_NECK:  return BOX_NECK;
            case PART_CHEST: return BOX_CHEST;
            default:         return BOX_HEAD;
        }
    }

    public static String partLabel(int part) {
        switch (part) {
            case PART_NECK:  return "NECK";
            case PART_CHEST: return "CHEST";
            default:         return "HEAD";
        }
    }
}
