package com.mg.panel.ui.aim;

public final class Posture {

    private Posture() { }

    public static final int POSE_STANDING   = 0;
    public static final int POSE_CROUCHING  = 1;
    public static final int POSE_DASHING    = 2;
    public static final int POSE_CREEPING   = 3;
    public static final int POSE_SWIMDASH   = 4;
    public static final int POSE_SKYDIVING  = 5;
    public static final int POSE_CROSSOVER  = 6;
    public static final int POSE_CLIMBOVER  = 7;
    public static final int POSE_KNOCKDOWN  = 8;
    public static final int POSE_SWIMSURF   = 9;
    public static final int POSE_HIGHFALL   = 10;
    public static final int POSE_LOWFALL    = 11;

    public static final int OK              = 0;
    public static final int REFUSE_POSE     = 1;  
    public static final int REFUSE_KNOCKED  = 2;   // downed: body is horizontal
    public static final int REFUSE_AIRBORNE = 3;  
    public static final int REFUSE_SWIM     = 4;   // root is submerged
    public static final int REFUSE_MOUNTED  = 5;   // attached to a vehicle

    private static boolean mountedMode(int mode) {
        return mode == 3      // ONBOARD
                || mode == 7  // ONSTROP (zipline)
                || mode == 9  // JETFLY
                || mode == 10 // GLIDING
                || mode == 11 // ONGRAPPLINGHOOK
                || mode == 12; // SKATEBOARDING
    }

    public static int verdict(int pose, int mode, boolean inVehicle) {

        if (inVehicle) return REFUSE_MOUNTED;
        if (!AimConfig.AIM_POSTURE_GATE) return OK;
        if (mountedMode(mode)) return REFUSE_MOUNTED;
        switch (pose) {
            case POSE_STANDING:
            case POSE_DASHING:
            case POSE_CROUCHING:
                return OK;
            case POSE_KNOCKDOWN:
                return REFUSE_KNOCKED;
            case POSE_SKYDIVING:
            case POSE_HIGHFALL:
            case POSE_LOWFALL:
                return REFUSE_AIRBORNE;
            case POSE_SWIMDASH:
            case POSE_SWIMSURF:
                return REFUSE_SWIM;
            default:

                return REFUSE_POSE;
        }
    }

    public static float heightM(int pose) {
        if (pose == POSE_CROUCHING) {
            return AimConfig.AIM_H_STANDING_M * AimConfig.AIM_CROUCH_RATIO;
        }
        return AimConfig.AIM_H_STANDING_M;
    }

    public static float anchorM(int pose) {
        return heightM(pose) * AimConfig.AIM_ANCHOR_FRAC;
    }

    public static String name(int pose) {
        switch (pose) {
            case POSE_STANDING:  return "stand";
            case POSE_CROUCHING: return "crouch";
            case POSE_DASHING:   return "dash";
            case POSE_CREEPING:  return "creep";
            case POSE_KNOCKDOWN: return "knocked";
            case POSE_SKYDIVING: return "skydive";
            case POSE_HIGHFALL:  return "hifall";
            case POSE_LOWFALL:   return "lofall";
            case POSE_SWIMDASH:  return "swimdash";
            case POSE_SWIMSURF:  return "swim";
            case POSE_CROSSOVER: return "crossover";
            case POSE_CLIMBOVER: return "climb";
            default:             return "p" + pose;
        }
    }
}
