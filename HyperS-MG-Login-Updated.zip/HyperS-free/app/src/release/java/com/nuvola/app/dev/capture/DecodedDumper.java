package com.mg.panel.dev.capture;

import java.io.File;
import java.util.List;

/** RELEASE no-op stub. Real decoded dumper is DEBUG-ONLY (docs/SECURITY_MODEL.md). */
public final class DecodedDumper {
    public DecodedDumper(List<CaptureRecord> records, long droppedByCap) { }
    public File dump(File dir) { return null; }
}
