package com.mg.panel.dev.capture;

import java.io.File;
import java.util.List;

/** RELEASE no-op stub. Real analyzer is DEBUG-ONLY (docs/SECURITY_MODEL.md). */
public final class FreezeDiffAnalyzer {
    public FreezeDiffAnalyzer(List<CaptureRecord> records, long droppedByCap) { }
    public File analyze(File dir) { return null; }
}
