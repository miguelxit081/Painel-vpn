from PIL import Image
from pathlib import Path

root = Path('/home/ubuntu/HyperS_work/HyperS')
src = Image.open(root / 'app/src/main/res/drawable-nodpi/nepdon_logo_launcher_safe.png').convert('RGBA')
canvas = Image.new('RGBA', src.size, (5, 5, 5, 255))
# Adaptive icons apply an additional mask/crop. Keep generous breathing room.
side = int(src.width * 0.68)
art = src.resize((side, side), Image.Resampling.LANCZOS)
canvas.alpha_composite(art, ((src.width - side)//2, (src.height - side)//2))
out = root / 'app/src/main/res/drawable-nodpi/nepdon_logo_launcher_inset.png'
canvas.save(out, optimize=True)
# Legacy icon buckets were all rectangular and therefore appeared zoomed/cropped.
for density in ('mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi'):
    d = root / f'app/src/main/res/mipmap-{density}'
    for name in ('ic_launcher.png','ic_launcher_foreground.png','ic_launcher_round.png'):
        canvas.save(d / name, optimize=True)
print(out)
